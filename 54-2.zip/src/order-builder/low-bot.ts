import { ClobClient, CreateOrderOptions, OrderType, Side, UserMarketOrderV2, TickSize, AssetType, BalanceAllowanceResponse, UserOrderV2 } from "@polymarket/clob-client-v2";
import * as fs from "fs";
import * as path from "path";
import { WebSocketOrderBook, TokenPrice } from "../providers/websocketOrderbook";
import { ENV } from "../config/env";
import logger from "../utils/appLogger";
import { spawnRedeemAutoWorker } from "../redeem/spawnRedeemWorker";
import { recordCycleEndedForRedeemTracking, recordCycleStartedForRedeemTracking } from "../utils/pnlRedeemTracking";
import {
    slugForCurrentUpDownMarket,
    fetchTokenIdsForSlug,
    cycleStartUnixFromSlug,
    marketDurationSecondsFromSlug,
} from "../utils/marketSlug";

type SimpleStateRow = {
    previousUpPrice: number | null; // Previous cycle's UP token price
    lastUpdatedIso: string;
    /** Previous tick asks (used to detect rising into action-point band). */
    prevUpAsk?: number | null;
    prevDownAsk?: number | null;
    /** Previous tick bids (used to detect falling into reversal-guard band). */
    prevUpBid?: number | null;
    prevDownBid?: number | null;
    // Holdings tracking (for redemption)
    conditionId?: string;
    slug?: string;
    market?: string;
    upIdx?: number;
    downIdx?: number;
    /**
     * Development-mode "action points" state machine (no real orders).
     */
    /** Current holding share side */
    currentHoldingSide?: "UP" | "DOWN";
    /** Virtual shares bought this cycle (for dev sell simulation) */
    cycleShares?: number;

    boughtLowTokens: boolean;

    /** GTC buy order IDs placed at cycle start (UP and DOWN @ LOW_BUY_PRICE). */
    lowDualUpOrderId?: string;
    lowDualDownOrderId?: string;

    /** After a successful sell, stay idle until the next cycle (slug changes). */
    idleUntilNextCycleSlug?: string;
    /** Throttle countdown logs while idling (bucketed by 10 seconds remaining). */
    lastIdleCountdownBucket?: number;
};

type SimpleStateFile = Record<string, SimpleStateRow>;

type SimpleConfig = {
    markets: string[]; // e.g. ["btc"] → `btc-updown-5m-{unix}` (interval from CRYPTO_UPDOWN_INTERVAL; legacy ET hourly slugs still parsed)
    tickSize: CreateOrderOptions["tickSize"];
    negRisk: boolean;
    priceBuffer: number; // Price buffer in cents for order execution (e.g., 0.03 = 3 cents)
    fireAndForget: boolean; // Don't wait for order confirmation (fire-and-forget)
    // Risk management
    minBalanceUsdc: number; // Minimum balance before stopping
};

interface MarketMetadata {
    tickSize: number;
    tickSizeStr: string;
    negRisk: boolean;
    feeRateBps: number;
    conditionId?: string;
    timestamp: number;
}

const STATE_FILE = "src/data/bot-state.json";

function statePath(): string {
    return path.resolve(process.cwd(), STATE_FILE);
}

function emptyRow(): SimpleStateRow {
    return {
        previousUpPrice: null,
        lastUpdatedIso: new Date().toISOString(),
        prevUpAsk: null,
        prevDownAsk: null,
        prevUpBid: null,
        prevDownBid: null,
        cycleShares: 0,
        boughtLowTokens: false,
        lowDualUpOrderId: undefined,
        lowDualDownOrderId: undefined,
        idleUntilNextCycleSlug: undefined,
        lastIdleCountdownBucket: undefined,
    };
}

function loadState(): SimpleStateFile {
    const p = statePath();
    try {
        if (fs.existsSync(p)) {
            const raw = fs.readFileSync(p, "utf8").trim();
            if (!raw) return {};
            const parsed = JSON.parse(raw);

            // Normalize state
            const normalized: SimpleStateFile = {};
            for (const [k, v] of Object.entries(parsed)) {
                if (typeof v !== "object" || !v) continue;
                const row = v as any;
                normalized[k] = {
                    previousUpPrice: typeof row.previousUpPrice === "number" ? row.previousUpPrice : null,
                    lastUpdatedIso: String(row.lastUpdatedIso ?? new Date().toISOString()),
                    prevUpAsk: row.prevUpAsk == null ? null : (Number.isFinite(Number(row.prevUpAsk)) ? Number(row.prevUpAsk) : null),
                    prevDownAsk: row.prevDownAsk == null ? null : (Number.isFinite(Number(row.prevDownAsk)) ? Number(row.prevDownAsk) : null),
                    prevUpBid: row.prevUpBid == null ? null : (Number.isFinite(Number(row.prevUpBid)) ? Number(row.prevUpBid) : null),
                    prevDownBid: row.prevDownBid == null ? null : (Number.isFinite(Number(row.prevDownBid)) ? Number(row.prevDownBid) : null),
                    conditionId: typeof row.conditionId === "string" ? row.conditionId : undefined,
                    slug: typeof row.slug === "string" ? row.slug : undefined,
                    market: typeof row.market === "string" ? row.market : undefined,
                    upIdx: Number.isFinite(Number(row.upIdx)) ? Number(row.upIdx) : undefined,
                    downIdx: Number.isFinite(Number(row.downIdx)) ? Number(row.downIdx) : undefined,
                    currentHoldingSide: row.currentHoldingSide === "UP" || row.currentHoldingSide === "DOWN" ? row.currentHoldingSide : undefined,
                    cycleShares: Number.isFinite(Number(row.cycleShares)) ? Number(row.cycleShares) : 0,
                    boughtLowTokens: row.boughtLowTokens ?? false,
                    lowDualUpOrderId: typeof row.lowDualUpOrderId === "string" ? row.lowDualUpOrderId : undefined,
                    lowDualDownOrderId: typeof row.lowDualDownOrderId === "string" ? row.lowDualDownOrderId : undefined,
                    idleUntilNextCycleSlug: typeof row.idleUntilNextCycleSlug === "string" ? row.idleUntilNextCycleSlug : undefined,
                    lastIdleCountdownBucket: Number.isFinite(Number(row.lastIdleCountdownBucket)) ? Number(row.lastIdleCountdownBucket) : undefined,
                };
            }
            return normalized;
        }
    } catch (e) {
        logger.error(`Failed to read state: ${e instanceof Error ? e.message : String(e)}`);
    }
    return {};
}

// Debounced state save
let saveStateTimer: NodeJS.Timeout | null = null;
function saveState(state: SimpleStateFile): void {
    if (saveStateTimer) {
        clearTimeout(saveStateTimer);
    }
    saveStateTimer = setTimeout(() => {
        try {
            const p = statePath();
            fs.mkdirSync(path.dirname(p), { recursive: true });
            fs.writeFileSync(p, JSON.stringify(state, null, 2));
        } catch (e) {
            logger.error(`Failed to save state: ${e instanceof Error ? e.message : String(e)}`);
        }
        saveStateTimer = null;
    }, 500); // Debounce saves by 500ms
}


const LOW_BUY_PRICE = ENV.low.buyPrice;
const LOW_SELL_PRICE = ENV.low.sellPrice;
const LOW_BUY_AMOUNT = ENV.low.buyAmount;

/** Normalized post-order response (CLOB may use camelCase or snake_case). */
type OrderResponseLike = {
    success?: boolean;
    orderID?: string;
    order_id?: string;
    makingAmount?: string | number;
    takingAmount?: string | number;
    errorMsg?: string;
    error?: string;
};

export class LowBot {
    private lastSlugByMarket: Record<string, string> = {};
    private tokenIdsByMarket: Record<
        string,
        { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    > = {};

    private state: SimpleStateFile = loadState();
    private isStopped: boolean = false;
    private wsOrderBook: WebSocketOrderBook | null = null;
    private useWebSocket: boolean = true; // Toggle to use WebSocket or API

    // Limit order second side strategy tracking
    private tokenCountsByMarket: Map<string, { upTokenCount: number; downTokenCount: number }> = new Map(); // Track token counts per market
    private pausedMarkets: Set<string> = new Set(); // Track paused markets (reached max tokens per side)

    private initializationPromise: Promise<void> | null = null;
    /** Unix-ms timestamp of the last `cancelAll()` call – prevents duplicate calls when
     *  multiple markets roll over near-simultaneously. */
    private lastCancelAllMs = 0;
    /** Interval handles stored so they can be cleared on stop(). */
    private intervals: NodeJS.Timeout[] = [];
    /** Per-market lock to prevent concurrent reinitializeMarketForNewCycle calls. */
    private reinitLocks: Set<string> = new Set();
    /** One order flow at a time per market (avoids duplicate action points / rapid sells on burst ticks). */
    private orderInFlightByMarket: Set<string> = new Set();

    private marketCache: Map<string, MarketMetadata> = new Map();
    private CACHE_TTL = 1000 * 60 * 5; // 5 minutes

    constructor(private client: ClobClient, private cfg: SimpleConfig) {
        // Initialize WebSocket orderbook (store promise for later awaiting)
        this.initializationPromise = this.initializeWebSocket();
    }

    static async fromEnv(client: ClobClient): Promise<LowBot> {
        const bot = new LowBot(client, {
            markets: ["btc"], tickSize: "0.01" as CreateOrderOptions["tickSize"],
            negRisk: false, priceBuffer: 0.03, fireAndForget: false, minBalanceUsdc: 1,
        });
        await bot.initializationPromise; // Await Polymarket WebSocket initialization

        return bot;
    }

    async initializeWebSocket(): Promise<void> {
        if (!this.useWebSocket) {
            logger.error("WebSocket disabled in config");
            return;
        }
        try {
            this.wsOrderBook = new WebSocketOrderBook("market", [], null);
            await this.wsOrderBook.connect();
            logger.info("WebSocket orderbook initialized");
        } catch (e) {
            logger.error(`Failed to initialize WebSocket: ${e instanceof Error ? e.message : String(e)}`);
            throw e;
        }
    }

    getCacheStats(): { size: number; items: string[] } {
        return {
            size: this.marketCache.size,
            items: Array.from(this.marketCache.keys()),
        };
    }

    clearCache(): void {
        this.marketCache.clear();
        console.log('🗑️  Market cache cleared');
    }

    async start(): Promise<void> {
        if (this.isStopped) {
            logger.error("Bot is stopped, cannot start");
            return;
        }

        if (!this.wsOrderBook) {
            logger.error("Fatal error: WebSocket orderbook not initialized - cannot start bot");
            return;
        }

        logger.info(`Starting LowBot for markets: ${this.cfg.markets.join(", ")}`);
        await this.initializeMarkets();
    }

    stop(): void {
        this.isStopped = true;

        // Clear all periodic timers
        for (const t of this.intervals) clearInterval(t);
        this.intervals = [];

        // Generate final summaries unconditionally (no time-gate at shutdown)
        logger.info("\n🛑 Generating final prediction summaries...");
        // this.flushPredictionSummaries(true);

        if (this.wsOrderBook) {
            this.wsOrderBook.disconnect();
        }
        logger.info("LowBot stopped");
    }

    private async initializeMarkets(): Promise<void> {
        await Promise.all(this.cfg.markets.map((m) => this.initializeMarket(m)));
    }

    private async initializeMarket(market: string): Promise<void> {
        try {
            const slug = slugForCurrentUpDownMarket(market);
            logger.info(`Initializing market ${market} with slug ${slug}`);
            const tokenIds = await fetchTokenIdsForSlug(slug);
            this.tokenIdsByMarket[market] = { slug, ...tokenIds };
            this.lastSlugByMarket[market] = slug;

            // Subscribe to WebSocket prices for these tokens
            if (this.wsOrderBook) {
                this.wsOrderBook.subscribeToTokenIds([tokenIds.upTokenId, tokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(tokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(tokenIds.downTokenId, "Down");

                // Set up price update callbacks - trigger trading logic on price updates
                this.wsOrderBook.onPriceUpdate(tokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(tokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "NO");
                });
            }

            // Kickstart one tick immediately so Action Point #1 fires as close to cycle start as possible,
            // instead of waiting for the first WS update to arrive.
            this.kickstartCycleTick(market, slug, tokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            const slug = slugForCurrentUpDownMarket(market);
            logger.error(`⚠️  Market ${market} not available yet (${slug}): ${errorMsg}. Will retry on next price update.`);
            // Don't throw - allow the bot to continue and retry later
        }
    }

    private kickstartCycleTick(
        market: string,
        slug: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    ): void {
        if (!this.wsOrderBook) return;
        if (this.isStopped) return;

        // Fire-and-forget, short polling window (WS often lags a couple seconds at boundary).
        void (async () => {
            const maxAttempts = 40; // ~2s at 50ms
            const delayMs = 50;
            for (let i = 0; i < maxAttempts; i++) {
                if (this.isStopped) return;
                const up = this.wsOrderBook?.getPrice(tokenIds.upTokenId);
                const down = this.wsOrderBook?.getPrice(tokenIds.downTokenId);
                const upAsk = up?.bestAsk;
                const downAsk = down?.bestAsk;
                if (
                    upAsk != null &&
                    downAsk != null &&
                    Number.isFinite(upAsk) &&
                    Number.isFinite(downAsk)
                ) {
                    const upBid = up?.bestBid != null && Number.isFinite(up.bestBid) ? up.bestBid : null;
                    const downBid = down?.bestBid != null && Number.isFinite(down.bestBid) ? down.bestBid : null;
                    const timeRemaining = this.getTimeRemainingForSlug(slug);
                    await this.executeTrade(
                        market,
                        slug,
                        upAsk,
                        downAsk,
                        upBid,
                        downBid,
                        up?.tickSize || this.cfg.tickSize,
                        down?.tickSize || this.cfg.tickSize,
                        {
                            upTokenId: tokenIds.upTokenId,
                            downTokenId: tokenIds.downTokenId,
                            conditionId: tokenIds.conditionId,
                            upIdx: tokenIds.upIdx,
                            downIdx: tokenIds.downIdx,
                        },
                        timeRemaining
                    );
                    return;
                }
                await new Promise((r) => setTimeout(r, delayMs));
            }
        })().catch((e) => {
            logger.error(
                `kickstartCycleTick error [${market}] slug=${slug}: ${e instanceof Error ? e.message : String(e)}`
            );
        });
    }

    async getTickSize(tokenId: string): Promise<number> {
        const metadata = await this.getMarketMetadata(tokenId);
        return metadata.tickSize;
    }

    roundToTickSize(price: number, tickSize: number): number {
        return Math.round(price / tickSize) * tickSize;
    }

    private async getOrderOptions(tokenId: string): Promise<{ tickSize: any; negRisk: boolean }> {
        const metadata = await this.getMarketMetadata(tokenId);
        return {
            tickSize: metadata.tickSizeStr as any,
            negRisk: metadata.negRisk,
        };
    }

    async getMarketMetadata(tokenId: string): Promise<MarketMetadata> {
        const cached = this.marketCache.get(tokenId);
        const now = Date.now();

        if (cached && (now - cached.timestamp) < this.CACHE_TTL) {
            return cached;
        }

        try {
            const [tickSizeData, negRisk, feeRateBps] = await Promise.all([
                this.client.getTickSize(tokenId).catch(() => ({ minimum_tick_size: '0.01' })),
                this.client.getNegRisk(tokenId).catch(() => false),
                this.client.getFeeRateBps(tokenId).catch(() => 0),
            ]);

            const tickSizeStr = (tickSizeData as any)?.minimum_tick_size || tickSizeData || '0.01';
            const tickSize = parseFloat(tickSizeStr);

            const metadata: MarketMetadata = {
                tickSize,
                tickSizeStr,
                negRisk,
                feeRateBps,
                timestamp: now,
            };

            this.marketCache.set(tokenId, metadata);

            return metadata;
        } catch (error) {
            console.log(`⚠️  Could not fetch market metadata for ${tokenId}, using defaults`);
            const defaultMetadata: MarketMetadata = {
                tickSize: 0.01,
                tickSizeStr: '0.01',
                negRisk: false,
                feeRateBps: 0,
                timestamp: now,
            };
            this.marketCache.set(tokenId, defaultMetadata);
            return defaultMetadata;
        }
    }

    private async placeGtcBuyLimit(
        tokenId: string,
        shares: number,
        tickSize: string,
        negRisk: boolean
    ): Promise<{ ok: boolean; orderID?: string; makingAmount: number; takingAmount: number }> {
        const userOrder: UserOrderV2 = {
            tokenID: tokenId,
            price: LOW_BUY_PRICE,
            size: shares,
            side: Side.BUY,
        };

        const response = await this.client.createAndPostOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk },
            OrderType.GTC
        );

        const r = response as OrderResponseLike;
        const orderID = r.orderID ?? r.order_id;
        const success = Boolean(r.success);
        if (orderID) {
            logger.info(`[low-bot] GTC buy placed token=${tokenId.slice(0, 8)}… orderID=${orderID} success=${success}`);
            return {
                ok: true,
                orderID,
                makingAmount: parseFloat(String(r.makingAmount ?? "0")) || 0,
                takingAmount: parseFloat(String(r.takingAmount ?? "0")) || 0,
            };
        }
        logger.error(`[low-bot] GTC buy failed: ${JSON.stringify(response)}`);
        return { ok: false, makingAmount: 0, takingAmount: 0 };
    }

    private async cancelOrderSafe(orderID: string): Promise<void> {
        try {
            await this.client.cancelOrder({ orderID });
        } catch (e) {
            logger.warn(`[low-bot] cancelOrder ${orderID}: ${e instanceof Error ? e.message : String(e)}`);
        }
    }

    private async getOrderMatchedShares(orderID: string): Promise<number> {
        try {
            const o = (await this.client.getOrder(orderID)) as { size_matched?: string };
            const m = parseFloat(String(o.size_matched ?? "0"));
            return Number.isFinite(m) && m > 0 ? m : 0;
        } catch (e) {
            logger.warn(`[low-bot] getOrder ${orderID}: ${e instanceof Error ? e.message : String(e)}`);
            return 0;
        }
    }

    private async placeDualBuyOrdersAtCycleStart(
        market: string,
        row: SimpleStateRow,
        stateKey: string,
        tokenIds: { upTokenId: string; downTokenId: string },
        upTickSize: string,
        downTickSize: string
    ): Promise<void> {
        const upOpts = await this.getOrderOptions(tokenIds.upTokenId);
        const downOpts = await this.getOrderOptions(tokenIds.downTokenId);

        const upRes = await this.placeGtcBuyLimit(
            tokenIds.upTokenId,
            LOW_BUY_AMOUNT,
            String(upOpts.tickSize),
            upOpts.negRisk
        );
        const downRes = await this.placeGtcBuyLimit(
            tokenIds.downTokenId,
            LOW_BUY_AMOUNT,
            String(downOpts.tickSize),
            downOpts.negRisk
        );

        if (upRes.ok && upRes.orderID && downRes.ok && downRes.orderID) {
            row.lowDualUpOrderId = upRes.orderID;
            row.lowDualDownOrderId = downRes.orderID;
            this.state[stateKey] = row;
            saveState(this.state);
            logger.info(
                `[low-bot] Dual cycle-start GTC buys @ ${LOW_BUY_PRICE} [${market}] UP=${upRes.orderID} DOWN=${downRes.orderID} size=${LOW_BUY_AMOUNT}`
            );
            return;
        }

        if (upRes.orderID) await this.cancelOrderSafe(upRes.orderID);
        if (downRes.orderID) await this.cancelOrderSafe(downRes.orderID);
        logger.error(
            `[low-bot] Dual GTC buy placement incomplete [${market}]: up=${Boolean(upRes.orderID)} down=${Boolean(downRes.orderID)}`
        );
    }

    private async sellShares(
        leg: "YES" | "NO",
        tokenIds: { upTokenId: string; downTokenId: string },
        shares: number,
        upTickSize: string,
        downTickSize: string
    ): Promise<{ ok: boolean; makingAmount: number; takingAmount: number }> {
        const tokenID = leg === "YES" ? tokenIds.upTokenId : tokenIds.downTokenId;
        const tickSize = leg === "YES" ? upTickSize : downTickSize;
        const opts = await this.getOrderOptions(tokenID);

        logger.info(`[low-bot] Sell ${leg} ${shares} shares @ ${LOW_SELL_PRICE} (FAK)`);
        const userOrder: UserMarketOrderV2 = {
            tokenID,
            side: Side.SELL,
            amount: shares,
            orderType: OrderType.FAK,
            price: LOW_SELL_PRICE,
        };

        const response = await this.client.createAndPostMarketOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk: opts.negRisk },
            OrderType.FAK
        );

        const r = response as OrderResponseLike;
        if (r.success) {
            logger.info(`[low-bot] Sell filled orderID=${r.orderID ?? r.order_id}`);
            return {
                ok: true,
                makingAmount: parseFloat(String(r.makingAmount ?? "0")) || 0,
                takingAmount: parseFloat(String(r.takingAmount ?? "0")) || 0,
            };
        }
        logger.error(`[low-bot] Sell failed: ${JSON.stringify(response)}`);
        return { ok: false, makingAmount: 0, takingAmount: 0 };
    }

    /**
     * Poll resting dual GTC buys; when at least one leg matches, cancel the other leg and sell matched size @ LOW_SELL_PRICE.
     */
    private async monitorLowDualBuysAndAct(
        market: string,
        slug: string,
        row: SimpleStateRow,
        stateKey: string,
        tokenIds: { upTokenId: string; downTokenId: string },
        upTickSize: string,
        downTickSize: string
    ): Promise<void> {
        const upId = row.lowDualUpOrderId!;
        const downId = row.lowDualDownOrderId!;

        const upM = await this.getOrderMatchedShares(upId);
        const downM = await this.getOrderMatchedShares(downId);

        if (upM <= 0 && downM <= 0) {
            return;
        }

        row.lowDualUpOrderId = undefined;
        row.lowDualDownOrderId = undefined;
        this.state[stateKey] = row;
        saveState(this.state);

        const finishIdle = (): void => {
            row.boughtLowTokens = false;
            row.currentHoldingSide = undefined;
            row.cycleShares = 0;
            row.idleUntilNextCycleSlug = slug;
            row.lastIdleCountdownBucket = undefined;
            this.state[stateKey] = row;
            saveState(this.state);
            logger.info(`[low-bot] Sold matched leg(s); idle until next market [${market}]`);
        };

        if (upM > 0 && downM > 0) {
            await this.cancelOrderSafe(downId);
            await this.cancelOrderSafe(upId);
            const okUp = (await this.sellShares("YES", tokenIds, upM, upTickSize, downTickSize)).ok;
            const okDown = (await this.sellShares("NO", tokenIds, downM, upTickSize, downTickSize)).ok;
            if (okUp && okDown) finishIdle();
            else if (!okUp) {
                row.boughtLowTokens = true;
                row.currentHoldingSide = "UP";
                row.cycleShares = upM;
                this.state[stateKey] = row;
                saveState(this.state);
            } else {
                row.boughtLowTokens = true;
                row.currentHoldingSide = "DOWN";
                row.cycleShares = downM;
                this.state[stateKey] = row;
                saveState(this.state);
            }
            return;
        }

        if (upM > 0) {
            await this.cancelOrderSafe(downId);
            const { ok } = await this.sellShares("YES", tokenIds, upM, upTickSize, downTickSize);
            if (ok) finishIdle();
            else {
                row.boughtLowTokens = true;
                row.currentHoldingSide = "UP";
                row.cycleShares = upM;
                this.state[stateKey] = row;
                saveState(this.state);
            }
            return;
        }

        await this.cancelOrderSafe(upId);
        const { ok } = await this.sellShares("NO", tokenIds, downM, upTickSize, downTickSize);
        if (ok) finishIdle();
        else {
            row.boughtLowTokens = true;
            row.currentHoldingSide = "DOWN";
            row.cycleShares = downM;
            this.state[stateKey] = row;
            saveState(this.state);
        }
    }

    private async handlePriceUpdate(
        market: string,
        tokenIds: { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        price: TokenPrice,
        _leg: "YES" | "NO"
    ): Promise<void> {
        if (this.isStopped) return;
        if (!price.bestAsk || !Number.isFinite(price.bestAsk)) return; // Use bestAsk

        // Defer heavy processing to prevent blocking WebSocket message loop
        queueMicrotask(() => {
            void (async () => {
                // Get slug for current 4h UTC window (or legacy cached slug)
                const slug = this.getSlugForMarket(market);
                if (!slug) {
                    // Market not initialized yet - initialize it
                    void this.initializeMarket(market);
                    return;
                }

                // Check if we have cached tokenIds for this market, and if slug matches
                let currentTokenIds = tokenIds;
                const cachedTokenIds = this.tokenIdsByMarket[market];
                if (cachedTokenIds && cachedTokenIds.slug === slug) {
                    // Use cached tokenIds if slug matches
                    currentTokenIds = cachedTokenIds;
                }
                // If slug doesn't match, we'll handle re-initialization in the market cycle check below

                // Get both prices (we need UP ask price for comparison) - fast cache lookup
                const upPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                const downPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                // Use bestAsk price for limit orders (required for order placement)
                if (!upPrice?.bestAsk || !downPrice?.bestAsk ||
                    !Number.isFinite(upPrice.bestAsk) || !Number.isFinite(downPrice.bestAsk)) {
                    return; // Wait for both ask prices
                }

                let upAsk: number = upPrice.bestAsk;
                let downAsk: number = downPrice.bestAsk;
                let upBid: number | null =
                    upPrice.bestBid != null && Number.isFinite(upPrice.bestBid) ? upPrice.bestBid : null;
                let downBid: number | null =
                    downPrice.bestBid != null && Number.isFinite(downPrice.bestBid) ? downPrice.bestBid : null;

                // Check for market cycle change (new hour / slug)
                // Initialize lastSlugByMarket if not set (first time)
                if (!this.lastSlugByMarket[market]) {
                    this.lastSlugByMarket[market] = slug;
                }

                const prevSlug = this.lastSlugByMarket[market];
                if (prevSlug && prevSlug !== slug) {
                    // Do not log here: UP+DOWN WS ticks (and burst updates) all hit this branch
                    // before reinit finishes — logging only inside reinitializeMarketForNewCycle after lock.
                    await this.reinitializeMarketForNewCycle(market, prevSlug, slug);

                    // Refresh tokenIds after re-init
                    const refreshed = this.tokenIdsByMarket[market];
                    if (!refreshed || refreshed.slug !== slug) return;
                    currentTokenIds = refreshed;

                    const newUpPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                    const newDownPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                    if (!newUpPrice?.bestAsk || !newDownPrice?.bestAsk ||
                        !Number.isFinite(newUpPrice.bestAsk) || !Number.isFinite(newDownPrice.bestAsk)) {
                        return;
                    }
                    upAsk = newUpPrice.bestAsk;
                    downAsk = newDownPrice.bestAsk;
                    upBid =
                        newUpPrice.bestBid != null && Number.isFinite(newUpPrice.bestBid)
                            ? newUpPrice.bestBid
                            : null;
                    downBid =
                        newDownPrice.bestBid != null && Number.isFinite(newDownPrice.bestBid)
                            ? newDownPrice.bestBid
                            : null;
                }

                const timeRemaining = this.getTimeRemainingForSlug(slug);

                await this.executeTrade(
                    market,
                    slug,
                    upAsk,
                    downAsk,
                    upBid,
                    downBid,
                    upPrice.tickSize || this.cfg.tickSize,
                    downPrice.tickSize || this.cfg.tickSize,
                    currentTokenIds,
                    timeRemaining
                );

                saveState(this.state);
            })().catch((e) => {
                logger.error(`handlePriceUpdate error [${market}]: ${e instanceof Error ? e.message : String(e)}`);
            });
        });
    }

    private getSlugForMarket(market: string): string {
        return slugForCurrentUpDownMarket(market);
    }

    private async reinitializeMarketForNewCycle(market: string, prevSlug: string, newSlug: string): Promise<void> {
        if (this.reinitLocks.has(market)) return;
        this.reinitLocks.add(market);

        const priorRow = this.state[market];
        const prevConditionId =
            typeof priorRow?.conditionId === "string" && /^0x[a-fA-F0-9]{64}$/.test(priorRow.conditionId.trim())
                ? priorRow.conditionId.trim()
                : undefined;

        logger.info(`🔄 New market cycle [${market}]: ${prevSlug} → ${newSlug}`);

        // Track prior cycle in logs/pnl.json as not_redeemed (updated to redeemed when redeem succeeds).
        if (prevConditionId) {
            setImmediate(() => {
                recordCycleEndedForRedeemTracking({
                    conditionId: prevConditionId,
                    slug: prevSlug,
                    market,
                });
            });
        }

        // Redeem previous market in a separate Node process (no await) — does not block trading or WS handling.
        if (ENV.redeem.autoAfterCycle && prevConditionId) {
            setImmediate(() => {
                try {
                    spawnRedeemAutoWorker(prevConditionId, prevSlug);
                    logger.info(`[redeem] Spawned worker for prior condition (slug=${prevSlug})`);
                } catch (e) {
                    logger.error(
                        `[redeem] Failed to spawn worker: ${e instanceof Error ? e.message : String(e)}`
                    );
                }
            });
        }

        // Cancel all open GTC orders (resting second-leg limits from the previous cycle) once per
        // rollover event, even when multiple markets tick simultaneously.
        const now = Date.now();
        if (now - this.lastCancelAllMs > 60_000) {
            this.lastCancelAllMs = now;
            try {
                await this.client.cancelAll();
                logger.info(`🗑️  Cancelled all open GTC orders at cycle boundary`);
            } catch (e) {
                logger.error(`cancelAll failed at cycle boundary: ${e instanceof Error ? e.message : String(e)}`);
            }
        }

        // Reset token counts and paused state for previous market
        const prevScoreKey = `${market}-${prevSlug}`;
        this.tokenCountsByMarket.delete(prevScoreKey);
        this.pausedMarkets.delete(prevScoreKey);

        try {
            const newTokenIds = await fetchTokenIdsForSlug(newSlug);
            this.tokenIdsByMarket[market] = { slug: newSlug, ...newTokenIds };

            // Update WebSocket subscriptions for new tokens
            if (this.wsOrderBook) {
                // Subscribe to new tokens
                this.wsOrderBook.subscribeToTokenIds([newTokenIds.upTokenId, newTokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(newTokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(newTokenIds.downTokenId, "Down");

                // Update callbacks with new token IDs
                this.wsOrderBook.onPriceUpdate(newTokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(newTokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "NO");
                });         
            }

            this.lastSlugByMarket[market] = newSlug;

            logger.info(`✅ Market ${market} re-initialized with new token IDs for cycle ${newSlug}`);

            // Kickstart one tick immediately to reduce delay on Action Point #1 at boundary.
            this.kickstartCycleTick(market, newSlug, newTokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            logger.error(`⚠️  Failed to re-initialize market ${market} with new slug ${newSlug}: ${errorMsg}. Will retry on next check.`);
        } finally {
            this.reinitLocks.delete(market);
        }
    }

    private async executeTrade(
        market: string,
        slug: string,
        _upAsk: number,
        _downAsk: number,
        _upBid: number | null,
        _downBid: number | null,
        upTickSize: string,
        downTickSize: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        timeRemainingSeconds: number,
    ): Promise<void> {
        const stateKey = market;
        if (this.orderInFlightByMarket.has(stateKey)) return;
        this.orderInFlightByMarket.add(stateKey);

        try {
            const row: SimpleStateRow = this.state[stateKey] ?? emptyRow();

            // Reset per-cycle state when slug changes (new market window)
            if (row.slug !== slug) {
                row.slug = slug;
                row.market = market;
                row.conditionId = tokenIds.conditionId;
                row.upIdx = tokenIds.upIdx;
                row.downIdx = tokenIds.downIdx;
                row.currentHoldingSide = undefined;
                row.cycleShares = 0;
                row.idleUntilNextCycleSlug = undefined;
                row.lastIdleCountdownBucket = undefined;
                row.lowDualUpOrderId = undefined;
                row.lowDualDownOrderId = undefined;
                row.lastUpdatedIso = new Date().toISOString();
                row.prevUpAsk = null;
                row.prevDownAsk = null;
                row.prevUpBid = null;
                row.prevDownBid = null;
                row.boughtLowTokens = false;

                logger.info(`🆕 New cycle state reset [${market}] slug=${slug}`);

                // Record cycle start immediately so users can redeem even if the bot is stopped mid-cycle.
                // Fire-and-forget: never blocks trading loop.
                const cid = row.conditionId;
                if (typeof cid === "string" && /^0x[a-fA-F0-9]{64}$/.test(cid)) {
                    setImmediate(() => {
                        recordCycleStartedForRedeemTracking({ conditionId: cid, slug, market });
                    });
                }
            }

            // After a successful sell, do nothing until the next cycle starts (slug changes).
            // While idling, emit a countdown log every 10 seconds.
            if (row.idleUntilNextCycleSlug === slug) {
                const remaining = Math.max(0, Math.floor(timeRemainingSeconds));
                const bucket = Math.floor(remaining / 10);
                if (row.lastIdleCountdownBucket !== bucket) {
                    row.lastIdleCountdownBucket = bucket;
                    this.state[stateKey] = row;
                    saveState(this.state);
                    logger.info(`[low-bot] Idle until next cycle [${market}] ${remaining}s left`);
                }
                return;
            }

            // Retry sell if a matched leg failed to exit on the previous attempt (dual IDs already cleared).
            if (
                row.boughtLowTokens &&
                row.currentHoldingSide &&
                !row.lowDualUpOrderId &&
                !row.lowDualDownOrderId
            ) {
                const shares = row.cycleShares ?? LOW_BUY_AMOUNT;
                const leg = row.currentHoldingSide === "UP" ? "YES" : "NO";
                const { ok } = await this.sellShares(leg, tokenIds, shares, upTickSize, downTickSize);
                if (ok) {
                    row.boughtLowTokens = false;
                    row.currentHoldingSide = undefined;
                    row.cycleShares = 0;
                    row.idleUntilNextCycleSlug = slug;
                    row.lastIdleCountdownBucket = undefined;
                }
                this.state[stateKey] = row;
                saveState(this.state);
                return;
            }

            if (row.lowDualUpOrderId && row.lowDualDownOrderId) {
                await this.monitorLowDualBuysAndAct(market, slug, row, stateKey, tokenIds, upTickSize, downTickSize);
                return;
            }

            if (!row.boughtLowTokens) {
                await this.placeDualBuyOrdersAtCycleStart(
                    market,
                    row,
                    stateKey,
                    tokenIds,
                    upTickSize,
                    downTickSize
                );
            }
        }
        finally {
            this.orderInFlightByMarket.delete(stateKey);
        }
    }

    private getTimeRemainingForSlug(slug: string): number {
        const startTs = cycleStartUnixFromSlug(slug);
        const durationSec = marketDurationSecondsFromSlug(slug);
        if (startTs == null || !Number.isFinite(startTs) || durationSec == null) return Infinity;
        return startTs + durationSec - Math.floor(Date.now() / 1000);
    }
}
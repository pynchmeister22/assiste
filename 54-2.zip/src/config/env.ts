import * as dotenv from "dotenv";
import { ethers } from "ethers";
import { logger } from '../utils/appLogger';

dotenv.config();

function envString(name: string, fallback?: string): string | undefined {
    const v = process.env[name];
    const t = typeof v === "string" ? v.trim() : "";
    if (t) return t;
    return fallback;
}

function envNumber(name: string, fallback: number): number {
    const raw = envString(name);
    if (!raw) return fallback;
    const n = Number(raw);
    return Number.isFinite(n) ? n : fallback;
}

function envBool(name: string, fallback: boolean = false): boolean {
    const raw = envString(name);
    if (!raw) return fallback;
    return raw.toLowerCase() === "true";
}

function envJson<T>(name: string, fallback: T): T {
    const raw = envString(name);
    if (!raw) return fallback;
    try {
        return JSON.parse(raw) as T;
    } catch {
        return fallback;
    }
}

/** Polymarket crypto up/down slug segment, e.g. `btc-updown-5m-1777786200`. */
export type CryptoUpDownIntervalTag = "5m" | "15m" | "4h";

function parseCryptoUpDownInterval(): { tag: CryptoUpDownIntervalTag; seconds: number } {
    const raw = (envString("CRYPTO_UPDOWN_INTERVAL", "5m") ?? "5m").toLowerCase();
    if (raw === "5m" || raw === "5min") return { tag: "5m", seconds: 5 * 60 };
    if (raw === "15m" || raw === "15min") return { tag: "15m", seconds: 15 * 60 };
    if (raw === "4h" || raw === "4hr" || raw === "4hours") return { tag: "4h", seconds: 4 * 60 * 60 };
    logger.warn(`Invalid CRYPTO_UPDOWN_INTERVAL="${raw}" — using 5m (expected 5m | 15m | 4h)`);
    return { tag: "5m", seconds: 5 * 60 };
}

function normalizeTimeLinesJst(raw: unknown): number[][] {
    const fallback: number[][] = [[17, 1], [1, 7], [14, 17], [7, 14]];
    if (!Array.isArray(raw)) return fallback;

    const out: number[][] = [];
    for (const item of raw) {
        if (!Array.isArray(item) || item.length < 2) continue;
        const a = Number(item[0]);
        const b = Number(item[1]);
        if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
        const start = Math.max(0, Math.min(23, Math.floor(a)));
        const end = Math.max(0, Math.min(23, Math.floor(b)));
        out.push([start, end]);
    }

    return out.length === 4 ? out : fallback;
}

function normalizeTimeLineConfig(raw: unknown): number[][] {
    // [[delayMinutes, actionLimit, actionMultiplier], ...] for [GOLDERN, GOOD, MIDDLE, POOR]
    const fallback: number[][] = [[0, 8, 2], [0, 8, 2], [2, 8, 1], [3, 8, 1]];
    if (!Array.isArray(raw)) return fallback;

    const out: number[][] = [];
    for (const item of raw) {
        if (!Array.isArray(item) || item.length < 2) continue;
        const delayMinRaw = Number(item[0]);
        const limitRaw = Number(item[1]);
        const multRaw = item.length >= 3 ? Number(item[2]) : NaN;
        if (!Number.isFinite(delayMinRaw) || !Number.isFinite(limitRaw)) continue;
        const delayMin = Math.max(0, Math.min(60, Math.floor(delayMinRaw)));
        const limit = Math.max(0, Math.min(100, Math.floor(limitRaw)));
        const mult = Number.isFinite(multRaw) ? Math.max(0.01, Math.min(100, multRaw)) : 1;
        out.push([delayMin, limit, mult]);
    }

    return out.length === 4 ? out : fallback;
}

// Validate Ethereum address
const isValidEthereumAddress = (address: string): boolean => {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
}

// Validate Ethereum private key
const isValidEvmPrivateKey = (raw: string): boolean => {
    const s = raw.trim();
    const hex = s.startsWith('0x') ? s.slice(2) : s;
    if (!/^[a-fA-F0-9]{64}$/.test(hex)) {
        return false;
    }
    if (/^0{64}$/.test(hex)) {
        return false;
    }
    try {
        new ethers.Wallet(`0x${hex}`);
        return true;
    } catch {
        return false;
    }
};

// Validate required environment variables
const validateRequiredEnv = (): void => {
    // This module is imported by both the main bot and spawned worker processes.
    // Keep validation everywhere, but only log it for the main bot to avoid cycle-boundary spam.
    if ((process.env.POLYBOT_ROLE || "bot") === "bot") {
        logger.info('🔍 Validating required environment variables...');
    }
    const required = [
        'PRIVATE_KEY',
        'CLOB_HTTP_URL',
        'CLOB_WS_URL',
        'PUSD_CONTRACT_ADDRESS',
        'RPC_URL',
        'WITHDRAW_AMOUNT',
        'WITHDRAW_ADDRESS',
        'AUTO_WITHDRAW',
        'WITHDRAW_POINT',
        'LOW_BUY_PRICE',
        'LOW_SELL_PRICE',
        'LOW_BUY_AMOUNT',
    ];

    const missing: string[] = [];
    for (const key of required) {
        const val = process.env[key];
        if (val === undefined || val === null || (typeof val === 'string' && val.trim() === '')) {
            missing.push(key);
        }
    }

    if (missing.length > 0) {
        logger.error('\n❌ Configuration Error: Missing required environment variables\n');
        logger.error(`Missing variables: ${missing.join(', ')}\n`);
        if (missing.includes('PRIVATE_KEY')) {
            logger.error('⚠️  PRIVATE_KEY must be set to your wallet secret (64 hex chars, optional 0x).\n');
        }
        throw new Error(
            `Missing required environment variables: ${missing.join(', ')}`
        );
    }
};

// Validate private key
const validatePrivateKey = (): void => {
    const raw = process.env.PRIVATE_KEY;
    if (!raw?.trim()) {
        return;
    }
    const pk = raw.trim();
    if (!isValidEvmPrivateKey(pk)) {
        logger.error('\n❌ Invalid PRIVATE_KEY — bot startup aborted\n');
        logger.error('Expected: 64 hexadecimal characters (optionally prefixed with 0x).');
        logger.error('Got length (after trim): ' + pk.replace(/^0x/i, '').length + ' hex chars\n');
        logger.error('💡 Export your account key from MetaMask / your wallet and paste into .env');
        logger.error('   Do not use your address — use the private key only.\n');
        throw new Error(
            'Invalid PRIVATE_KEY: must be a valid Ethereum-compatible private key'
        );
    }
}

// Validate addresses
const validateAddresses = (): void => {
    if (process.env.PROXY_WALLET && !isValidEthereumAddress(process.env.PROXY_WALLET)) {
        logger.error('\n❌ Invalid Wallet Address\n');
        logger.error(`Your PROXY_WALLET: ${process.env.PROXY_WALLET}`);
        logger.error('Expected format:    0x followed by 40 hexadecimal characters\n');
        logger.error('Example: 0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb0\n');
        logger.error('💡 Tips:');
        logger.error('   • Copy your wallet address from MetaMask');
        logger.error('   • Make sure it starts with 0x');
        logger.error('   • Should be exactly 42 characters long\n');
        throw new Error(
            `Invalid PROXY_WALLET address format: ${process.env.PROXY_WALLET}`
        );
    }

    if (
        process.env.PUSD_CONTRACT_ADDRESS &&
        !isValidEthereumAddress(process.env.PUSD_CONTRACT_ADDRESS)
    ) {
        logger.error('\n❌ Invalid USDC Contract Address\n');
        logger.error(`Current value: ${process.env.PUSD_CONTRACT_ADDRESS}`);
        logger.error('Default value: 0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174\n');
        logger.error('⚠️  Unless you know what you\'re doing, use the default value!\n');
        throw new Error(
            `Invalid PUSD_CONTRACT_ADDRESS format: ${process.env.PUSD_CONTRACT_ADDRESS}`
        );
    }
};

// Run all validations
validateRequiredEnv();
validateAddresses();
validatePrivateKey();


export const ENV = {
    PROXY_WALLET: process.env.PROXY_WALLET as string,
    PRIVATE_KEY: (process.env.PRIVATE_KEY as string).trim(),
    CLOB_HTTP_URL: process.env.CLOB_HTTP_URL as string,
    CLOB_WS_URL: process.env.CLOB_WS_URL as string,
    PUSD_CONTRACT_ADDRESS: process.env.PUSD_CONTRACT_ADDRESS as string,
    RPC_URL: process.env.RPC_URL as string,
    NETWORK_RETRY_LIMIT: parseInt(process.env.NETWORK_RETRY_LIMIT as string) || 3,
    REQUEST_TIMEOUT_MS: parseInt(process.env.REQUEST_TIMEOUT_MS as string) || 10000,
    WITHDRAW_AMOUNT: parseFloat(process.env.WITHDRAW_AMOUNT as string) || 30,
    WITHDRAW_ADDRESS: process.env.WITHDRAW_ADDRESS as string || '0x0000000000000000000000000000000000000000',
    AUTO_WITHDRAW: envBool("AUTO_WITHDRAW", true),
    WITHDRAW_POINT: parseInt(process.env.WITHDRAW_POINT as string) || 300,
    TIME_LINES_JST: normalizeTimeLinesJst(envJson("TIME_LINES_JST", [[17, 1], [1, 7], [14, 17], [7, 14]])),
    TIME_LINE_CONFIG: normalizeTimeLineConfig(envJson("TIME_LINE_CONFIG", [[0, 8, 2], [0, 8, 2], [2, 8, 1], [3, 8, 1]])),
    bot: {
        minUsdcBalance: envNumber("BOT_MIN_USDC_BALANCE", 1),
        waitForNextMarketStart: envBool("TRADING_WAIT_FOR_NEXT_MARKET_START", true),
    },
    /**
     * Auto-redeem runs in a separate process (see spawnRedeemWorker) so it never blocks the bot.
     * Off by default; enable REDEEM_AUTO_AFTER_CYCLE=true when you want rollover-triggered redeem.
     */
    redeem: {
        autoAfterCycle: envBool("REDEEM_AUTO_AFTER_CYCLE", false),
        autoRetryMs: envNumber("REDEEM_AUTO_RETRY_MS", 60_000),
        autoMaxAttempts: envNumber("REDEEM_AUTO_MAX_ATTEMPTS", 120),
    },
    low: {
        buyPrice: parseFloat(process.env.LOW_BUY_PRICE as string) || 0.01,
        sellPrice: parseFloat(process.env.LOW_SELL_PRICE as string) || 0.02,
        buyAmount: parseFloat(process.env.LOW_BUY_AMOUNT as string) || 100,
    },
    /** Crypto up/down window for `slugForCurrentUpDownMarket` (default 5m, e.g. `btc-updown-5m-1777786200`). */
    cryptoUpDown: (() => {
        const { tag, seconds } = parseCryptoUpDownInterval();
        return { intervalTag: tag, intervalSeconds: seconds };
    })(),
}
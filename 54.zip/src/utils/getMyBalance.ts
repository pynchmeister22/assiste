import { ethers } from 'ethers';
import { config } from '../config';

const RPC_URL = config.rpcUrl;
const PUSD_CONTRACT_ADDRESS = config.contracts.pusd;

const USDC_ABI = ['function balanceOf(address owner) view returns (uint256)'];

const getMyBalance = async (address: string): Promise<number> => {
    const rpcProvider = new ethers.providers.JsonRpcProvider(RPC_URL);
    const usdcContract = new ethers.Contract(PUSD_CONTRACT_ADDRESS, USDC_ABI, rpcProvider);
    const balance_usdc = await usdcContract.balanceOf(address);
    const balance_usdc_real = ethers.utils.formatUnits(balance_usdc, 6);
    return parseFloat(balance_usdc_real);
}

export default getMyBalance;
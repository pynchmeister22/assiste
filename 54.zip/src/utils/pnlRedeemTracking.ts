import {
  BTC_5M_MARKETS_FILE,
  btc5mMapKey,
  isBtc5mMarketSlug,
  readBtc5mMarketsMap,
  type Btc5mMarketEntry,
  upsertBtc5mMarketEntry,
  writeBtc5mMarketsMap,
} from '../btc-5m-market-log.js';

/** Redeem lifecycle for a 5m cycle row (keyed by conditionId) — view over `btc-5m-markets.json`. */
export type RedeemStatus = 'active_in_cycle' | 'not_redeemed' | 'redeemed' | 'nothing_to_redeem';

export interface PnlCycleEntry {
  conditionId: string;
  slug: string;
  market: string;
  cycleStartedAtIso?: string;
  cycleEndedAtIso?: string;
  redeemStatus: RedeemStatus;
  redeemedAtIso?: string;
  transactionHash?: string;
  balanceAfterUsdc?: string;
  redeemSource?: 'auto' | 'manual' | 'batch' | 'pnl_pending';
  nothingToRedeemNote?: string;
  updatedAtIso: string;
}

const nowIso = () => new Date().toISOString();

function entryToPnl(e: Btc5mMarketEntry): PnlCycleEntry {
  return {
    conditionId: e.conditionId,
    slug: e.slug,
    market: e.market,
    cycleStartedAtIso: e.cycleStartedAtIso,
    cycleEndedAtIso: e.cycleEndedAtIso,
    redeemStatus: e.redeemStatus as RedeemStatus,
    redeemedAtIso: e.redeemedAtIso,
    transactionHash: e.transactionHash,
    balanceAfterUsdc: e.balanceAfterUsdc,
    redeemSource: e.redeemSource,
    nothingToRedeemNote: e.nothingToRedeemNote,
    updatedAtIso: e.updatedAtIso,
  };
}

function mutateBtc5mFile(fn: (map: Record<string, Btc5mMarketEntry>) => void): void {
  for (let i = 0; i < 5; i++) {
    try {
      const map = readBtc5mMarketsMap(BTC_5M_MARKETS_FILE);
      fn(map);
      writeBtc5mMarketsMap(map, BTC_5M_MARKETS_FILE);
      return;
    } catch {
      /* retry — concurrent writers or transient FS errors */
    }
  }
}

/** All rows in `logs/btc-5m-markets.json` with `redeemStatus === "not_redeemed"`, oldest cycle end first. */
export function getNotRedeemedCycleEntries(): PnlCycleEntry[] {
  const map = readBtc5mMarketsMap(BTC_5M_MARKETS_FILE);
  return Object.values(map)
    .filter((e) => e && e.redeemStatus === 'not_redeemed')
    .map(entryToPnl)
    .sort((a, b) => {
      const ak = a.cycleEndedAtIso ?? a.cycleStartedAtIso ?? '';
      const bk = b.cycleEndedAtIso ?? b.cycleStartedAtIso ?? '';
      return ak.localeCompare(bk);
    });
}

/** Ensure a BTC 5m row exists (same as main bot market log). No-op if slug is not a BTC 5m pattern. */
export function recordCycleStartedForRedeemTracking(params: {
  conditionId: string;
  slug: string;
  market: string;
}): void {
  const { conditionId, slug } = params;
  if (!isBtc5mMarketSlug(slug)) return;
  try {
    upsertBtc5mMarketEntry(conditionId, slug);
  } catch {
    /* non-fatal */
  }
}

/** Mark this condition’s cycle as ended in the log (for redeem queue). */
export function recordCycleEndedForRedeemTracking(params: {
  conditionId: string;
  slug: string;
  market: string;
}): void {
  const { conditionId, slug } = params;
  if (!isBtc5mMarketSlug(slug)) return;
  const t = nowIso();
  try {
    upsertBtc5mMarketEntry(conditionId, slug);
    mutateBtc5mFile((map) => {
      const key = btc5mMapKey(conditionId);
      const prev = map[key];
      if (!prev || prev.redeemStatus === 'redeemed') return;
      prev.cycleEndedAtIso = t;
      prev.updatedAtIso = t;
      if (prev.redeemStatus === 'active_in_cycle') {
        prev.redeemStatus = 'not_redeemed';
        delete prev.nothingToRedeemNote;
      }
    });
  } catch {
    /* non-fatal */
  }
}

/**
 * After a successful on-chain redeem (CLI auto/manual or batch).
 * Updates `logs/btc-5m-markets.json` only (no `pnl.json`).
 */
export function markCycleRedeemed(params: {
  conditionId: string;
  transactionHash?: string;
  balanceAfterUsdc?: string;
  source: 'auto' | 'manual' | 'batch' | 'pnl_pending';
  slug?: string;
  market?: string;
}): void {
  const t = nowIso();
  const { conditionId, transactionHash, balanceAfterUsdc, source, slug } = params;
  try {
    if (slug && isBtc5mMarketSlug(slug)) {
      upsertBtc5mMarketEntry(conditionId, slug);
    }
    mutateBtc5mFile((map) => {
      const key = btc5mMapKey(conditionId);
      const prev = map[key];
      if (!prev) return;
      if (prev.redeemStatus === 'redeemed') return;
      prev.redeemStatus = 'redeemed';
      prev.redeemedAtIso = t;
      prev.transactionHash = transactionHash ?? prev.transactionHash;
      prev.balanceAfterUsdc = balanceAfterUsdc ?? prev.balanceAfterUsdc;
      prev.redeemSource = source;
      prev.updatedAtIso = t;
      delete prev.nothingToRedeemNote;
    });
  } catch {
    /* non-fatal */
  }
}

/**
 * Redeem worker / flow determined there was nothing to redeem for this condition.
 */
export function markCycleNothingToRedeem(params: { conditionId: string; slug?: string; note?: string }): void {
  const t = nowIso();
  const { conditionId, slug, note } = params;
  try {
    if (slug && isBtc5mMarketSlug(slug)) {
      upsertBtc5mMarketEntry(conditionId, slug);
    }
    mutateBtc5mFile((map) => {
      const key = btc5mMapKey(conditionId);
      const prev = map[key];
      if (!prev) return;
      if (prev.redeemStatus === 'redeemed') return;
      prev.redeemStatus = 'nothing_to_redeem';
      prev.nothingToRedeemNote = note;
      prev.updatedAtIso = t;
    });
  } catch {
    /* non-fatal */
  }
}

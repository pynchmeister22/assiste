import axios from 'axios';
import { config } from './config.js';

export type TradeOutcome = 'YES' | 'NO' | 'UNKNOWN';

export interface Trade {
    txHash: string;
    timestamp: number;
    /**
     * Primary market key for this bot: prefer CTF **condition id** (`0x` + 64 hex) when the API provides it.
     * May also be a Gamma **numeric** market id or a slug depending on the data source.
     */
    market: string;
    /**
     * Polymarket Gamma **numeric** market id when the activity API exposes it separately (string of digits).
     */
    gammaMarketId?: string;
    /** From activity API when present (e.g. `btc-updown-5m-…`) — used if Gamma resolve fails. */
    slug?: string;
    tokenId: string;
    side: 'BUY' | 'SELL';
    price: number;
    size: number;
    outcome: TradeOutcome;
}

export class TradeMonitor {
    private lastProcessedTimestamp: number = 0;
    private processedTradeIds: Set<string> = new Set();

    async initialize(): Promise<void> {
        this.lastProcessedTimestamp = Date.now();
        console.log(`📊 Monitor initialized at ${new Date(this.lastProcessedTimestamp).toISOString()}`);
        console.log(`   Will copy trades that occur AFTER this time`);
    }

    private async fetchTradesFromDataApi(): Promise<Trade[]> {
        try {
            const startSeconds = Math.floor(this.lastProcessedTimestamp / 1000) + 1;
            const response = await axios.get(
                'https://data-api.polymarket.com/activity',
                {
                    params: {
                        user: config.targetWallet.toLocaleLowerCase(),
                        type: 'TRADE',
                        limit: 100,
                        sortBy: 'TIMESTAMP',
                        sortDirection: 'DESC',
                        start: startSeconds,
                    },
                    headers: {
                        'Accept': 'application/json',
                    }
                }
            );

            if (Array.isArray(response.data)) {
                return response.data.map(this.parseDataApiTrade.bind(this));
            }

            return [];
        } catch (error: any) {
            console.log(`⚠️  Could not fetch trades: ${error.message || 'Unknown error'}`);
            return [];
        }
    }

    private parseDataApiTrade(apiTrade: any): Trade {
        const conditionId = typeof apiTrade.conditionId === 'string' ? apiTrade.conditionId : '';
        const rawMarket = apiTrade.market;
        const rawMarketStr = typeof rawMarket === 'string' ? rawMarket : '';
        const gammaMarketId =
            /^\d+$/.test(rawMarketStr)
                ? rawMarketStr
                : typeof apiTrade.marketId === 'string' && /^\d+$/.test(apiTrade.marketId)
                  ? apiTrade.marketId
                  : typeof apiTrade.marketId === 'number'
                    ? String(apiTrade.marketId)
                    : undefined;

        const slug =
            typeof apiTrade.slug === 'string'
                ? apiTrade.slug
                : typeof apiTrade.eventSlug === 'string'
                  ? apiTrade.eventSlug
                  : typeof apiTrade.marketSlug === 'string'
                    ? apiTrade.marketSlug
                    : undefined;

        return {
            txHash: apiTrade.transactionHash || apiTrade.id || `trade-${apiTrade.timestamp}`,
            timestamp: apiTrade.timestamp * 1000,
            market: conditionId || rawMarketStr,
            gammaMarketId,
            slug,
            tokenId: apiTrade.asset,
            side: apiTrade.side.toUpperCase() as 'BUY' | 'SELL',
            price: parseFloat(apiTrade.price),
            size: parseFloat(apiTrade.usdcSize || apiTrade.size),
            outcome: this.normalizeOutcome(apiTrade.outcome),
        };
    }

    private normalizeOutcome(value: any): TradeOutcome {
        const normalized = String(value ?? '').trim().toUpperCase();
        if (normalized === 'YES' || normalized === 'NO') {
            return normalized;
        }
        return 'UNKNOWN';
    }

    async pollForNewTrades(callback: (trade: Trade) => Promise<void>): Promise<void> {
        try {
            const trades = await this.fetchTradesFromDataApi();

            if (trades.length === 0) {
                return;
            }

            const sortedTrades = trades.sort((a, b) => a.timestamp - b.timestamp);

            let newTradesCount = 0;

            for (const trade of sortedTrades) {
                const tradeId = trade.txHash;

                if (this.processedTradeIds.has(tradeId)) {
                    continue;
                }

                if (trade.timestamp <= this.lastProcessedTimestamp) {
                    continue;
                }

                this.processedTradeIds.add(tradeId);
                this.lastProcessedTimestamp = Math.max(this.lastProcessedTimestamp, trade.timestamp);
                newTradesCount++;

                await callback(trade);
            }

            if (newTradesCount > 0) {
                console.log(`🔍 Processed ${newTradesCount} new trade(s)`);
            }
        } catch (error: any) {
            console.error(`❌ Error polling for trades:`, error.message);
        }
    }

    pruneProcessedHashes(): void {
        if (this.processedTradeIds.size > 10000) {
            const entries = Array.from(this.processedTradeIds);
            this.processedTradeIds = new Set(entries.slice(-5000));
        }
    }
}
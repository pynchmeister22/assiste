import { config, validateConfig } from './config.js';
import { TradeMonitor } from './monitor.js';
import { WebSocketMonitor } from './websocket-monitor.js';
import type { Trade } from './monitor.js';
import { TradeExecutor } from './trader.js';
import { RiskManager } from './risk-manager.js';
import { PositionTracker } from './positions.js';
import createClobClient from './createClobClient.js';
import { appendTradeLedgerEntry, toTradeLedgerEntry } from './trade-ledger.js';
import { resolveMarketForTrade, summarizeGammaMarket } from './gamma-market-service.js';
import { appendUniqueMarketSnapshot, loadMarketLogDedupFromDisk } from './market-detection-log.js';
import {
    isBtc5mMarketSlug,
    readBtc5mMarketsMap,
    findPreviousBtc5mCycleForSlug,
    upsertBtc5mMarketEntry,
} from './btc-5m-market-log.js';
import type { ResolveMarketResult } from './gamma-market-service.js';
import { spawnRedeemAutoWorker } from './redeem/spawnRedeemWorker.js';

class PolymarketCopyBot {
    private monitor: TradeMonitor;
    private wsMonitor?: WebSocketMonitor;
    /** Set in `initialize()` after `await createClobClient()` (constructors cannot be async). */
    private executor!: TradeExecutor;
    private positions: PositionTracker;
    private risk: RiskManager;
    private isRunning: boolean = false;
    private processedTrades: Set<string> = new Set();
    private botStartTime: number = 0;
    private readonly maxProcessedTrades = 10000;
    private stats = {
        tradesDetected: 0,
        tradesCopied: 0,
        tradesFailed: 0,
        totalVolume: 0,
    };

    constructor() {
        this.monitor = new TradeMonitor();
        this.positions = new PositionTracker();
        this.risk = new RiskManager(this.positions);
    }

    async initialize(): Promise<void> {
        console.log('🤖 Polymarket Copy Trading Bot');
        console.log('================================');
        console.log(`Target wallet: ${config.targetWallet}`);
        console.log(`Position multiplier: ${config.trading.positionSizeMultiplier * 100}%`);
        console.log(`Max trade size: ${config.trading.maxTradeSize} USDC`);
        console.log(`Order type: ${config.trading.orderType}`);
        console.log(`WebSocket: ${config.monitoring.useWebSocket ? 'Enabled' : 'Disabled'}`);
        if (config.risk.maxSessionNotional > 0 || config.risk.maxPerMarketNotional > 0) {
            console.log(`Risk caps: session=${config.risk.maxSessionNotional || '∞'} USDC, per-market=${config.risk.maxPerMarketNotional || '∞'} USDC`);
        }
        console.log(`Auth mode: EOA (signature type 0)`);
        console.log(`Copy trading: BTC 5m only (slug pattern btc-updown-5m-*)`);
        console.log('================================\n');

        validateConfig();
        loadMarketLogDedupFromDisk();

        this.botStartTime = Date.now();
        console.log(`⏰ Bot start time: ${new Date(this.botStartTime).toISOString()}`);
        console.log('   (Only trades after this time will be copied)\n');

        const clobClient = await createClobClient();
        this.executor = new TradeExecutor(clobClient);

        await this.monitor.initialize();
        await this.executor.initialize();
        // await this.reconcilePositions();

        if (config.monitoring.useWebSocket) {
            this.wsMonitor = new WebSocketMonitor();
            try {
                const wsAuth = this.executor.getWsAuth();
                const channel = config.monitoring.useUserChannel ? 'user' : 'market';
                await this.wsMonitor.initialize(this.handleNewTrade.bind(this), channel, wsAuth);
                console.log(`✅ WebSocket monitor initialized (${channel} channel)\n`);

                if (channel === 'market' && config.monitoring.wsAssetIds.length > 0) {
                    for (const assetId of config.monitoring.wsAssetIds) {
                        await this.wsMonitor!.subscribeToMarket(assetId);
                    }
                }

                if (channel === 'user' && config.monitoring.wsMarketIds.length > 0) {
                    for (const marketId of config.monitoring.wsMarketIds) {
                    await this.wsMonitor!.subscribeToCondition(marketId);
                    }
                }
            } catch (error) {
                console.error('⚠️  WebSocket initialization failed, falling back to REST API only');
                console.error('   Error:', error);
                this.wsMonitor = undefined;
            }
        }
    }

    async start(): Promise<void> {
        this.isRunning = true;
        const monitoringMethods = [];
        if (this.wsMonitor) monitoringMethods.push('WebSocket');
        monitoringMethods.push('REST API');
    
        console.log(`🚀 Bot started! Monitoring via: ${monitoringMethods.join(' + ')}\n`);
    
        while (this.isRunning) {
            try {
                await this.monitor.pollForNewTrades(this.handleNewTrade.bind(this));
                this.monitor.pruneProcessedHashes();
            } catch (error) {
                console.error('Error in monitoring loop:', error);
            }

            await this.sleep(config.monitoring.pollInterval);
        }
    }

    private async handleNewTrade(trade: Trade): Promise<void> {
        if (trade.timestamp && trade.timestamp < this.botStartTime) {
            return;
        }

        const tradeKeys = this.getTradeKeys(trade);
        if (tradeKeys.some((key) => this.processedTrades.has(key))) {
            return;
        }

        for (const key of tradeKeys) {
            this.processedTrades.add(key);
        }
        this.pruneProcessedTrades();
        this.stats.tradesDetected++;
        const tradeTimeIso = new Date(trade.timestamp).toISOString();

        let marketResolve: ResolveMarketResult | undefined;
        try {
            marketResolve = await resolveMarketForTrade(trade);
            const resolved = marketResolve;
            if (resolved.market) {
                const slug = resolved.market.slug;
                const conditionId = String(resolved.market.conditionId ?? trade.market ?? '');
                if (isBtc5mMarketSlug(slug) && conditionId) {
                    const r = upsertBtc5mMarketEntry(conditionId, String(slug));
                    if (r.created) {
                        // Deterministic: read the log and redeem the previous 5m cycle by time adjacency.
                        const map = readBtc5mMarketsMap();
                        const prev = findPreviousBtc5mCycleForSlug(map, String(slug));
                        if (prev) {
                            console.log(
                                `   🔁 Spawning non-blocking redeem worker for previous cycle ${prev.conditionId.slice(0, 14)}… (${prev.slug})`,
                            );
                            spawnRedeemAutoWorker(prev.conditionId, prev.slug);
                        } else if (r.rolledOverFrom.length > 0) {
                            // Fallback: older status-based list (kept for safety).
                            for (const p of r.rolledOverFrom) {
                                console.log(
                                    `   🔁 Spawning non-blocking redeem worker for previous cycle ${p.conditionId.slice(0, 14)}… (${p.slug})`,
                                );
                                spawnRedeemAutoWorker(p.conditionId, p.slug);
                            }
                        } else {
                            console.log('   ℹ️  No previous BTC 5m cycle found to redeem');
                        }
                    }
                    if (r.ok && typeof resolved.market.question === 'string') {
                        console.log(
                            `   📎 BTC 5m market: ${resolved.market.question}${r.created ? ' (logged to btc-5m-markets.json)' : ' (btc-5m log updated)'}`,
                        );
                    }
                    if (!r.ok) {
                        const snapshot = summarizeGammaMarket(resolved.market);
                        const wrote = appendUniqueMarketSnapshot(snapshot);
                        if (typeof resolved.market.question === 'string') {
                            console.log(`   📎 Market: ${resolved.market.question}${wrote ? '' : ' (already in market log)'}`);
                        }
                    }
                } else {
                    const snapshot = summarizeGammaMarket(resolved.market);
                    const wrote = appendUniqueMarketSnapshot(snapshot);
                    if (typeof resolved.market.question === 'string') {
                        console.log(`   📎 Market: ${resolved.market.question}${wrote ? '' : ' (already in market log)'}`);
                    }
                }
            } else if (resolved.error) {
                console.log(`   ⚠️  Market metadata: ${resolved.error}`);
            }
        } catch (e: any) {
            console.log(`   ⚠️  Market metadata logging failed: ${e?.message || e}`);
        }

        if (trade.side === 'SELL') {
            console.log('⚠️  Skipping SELL trade (BUY-only safeguard enabled)');
            return;
        }

        const slugForCopy =
            (marketResolve?.market &&
                typeof marketResolve.market.slug === 'string' &&
                marketResolve.market.slug.trim()) ||
            trade.slug?.trim();
        const isBtc5mForCopy = isBtc5mMarketSlug(slugForCopy);
        if (!isBtc5mForCopy) {
            const resolvedQuestion =
                marketResolve?.market && typeof marketResolve.market.question === 'string'
                    ? marketResolve.market.question
                    : undefined;
            const resolvedSlug =
                marketResolve?.market && typeof marketResolve.market.slug === 'string'
                    ? marketResolve.market.slug
                    : trade.slug;
            const label = resolvedSlug || resolvedQuestion || trade.market;
            console.log(`🎯 Trade detected (non-BTC5m) ${tradeTimeIso} market=${label}`);
            return;
        }

        console.log('\n' + '='.repeat(50));
        console.log(`🎯 BTC 5m TRADE DETECTED`);
        console.log(`   Time: ${tradeTimeIso}`);
        console.log(`   Market: ${trade.market}`);
        if (slugForCopy) {
            console.log(`   Slug: ${slugForCopy}`);
        }
        console.log(`   Side: ${trade.side} ${trade.outcome}`);
        console.log(`   Size: ${trade.size} pUSD @ ${trade.price.toFixed(3)}`);
        console.log(`   Token ID: ${trade.tokenId}`);
        if (trade.gammaMarketId) {
            console.log(`   Gamma market id: ${trade.gammaMarketId}`);
        }
        console.log('='.repeat(50));

        if (this.wsMonitor) {
            await this.wsMonitor.subscribeToMarket(trade.tokenId);
        }

        const copyNotional = this.executor.calculateCopySize(trade.size);
        const riskCheck = this.risk.checkTrade(trade, copyNotional);
        if (!riskCheck.allowed) {
            console.log(`⚠️  Risk check blocked trade: ${riskCheck.reason}`);
            return;
        }

        try {
            const result = await this.executor.executeCopyTrade(trade, copyNotional);
            this.risk.recordFill({
                trade,
                notional: result.copyNotional,
                shares: result.copyShares,
                price: result.price,
                side: result.side,
            });
            this.stats.tradesCopied++;
            this.stats.totalVolume += result.copyNotional;
            appendTradeLedgerEntry(toTradeLedgerEntry(trade, result));
            console.log(`✅ Successfully copied trade!`);
            console.log(`📊 Session Stats: ${this.stats.tradesCopied}/${this.stats.tradesDetected} copied, ${this.stats.tradesFailed} failed`);
        } catch (error: any) {
            this.stats.tradesFailed++;
            console.log(`❌ Failed to copy trade`);
            if (error?.message) {
                console.log(`   Reason: ${error.message}`);
            }
            console.log(`📊 Session Stats: ${this.stats.tradesCopied}/${this.stats.tradesDetected} copied, ${this.stats.tradesFailed} failed`);
        }
    }

    // private async reconcilePositions(): Promise<void> {
    //     try {
    //         const positions = await this.executor.getPositions();
    //         if (!positions || positions.length === 0) {
    //             console.log('🧾 Positions: none found (fresh session)');
    //             return;
    //         }

    //         const { loaded, skipped } = this.positions.loadFromClobPositions(positions);
    //         const totalNotional = this.positions.getTotalNotional();
    //         console.log(`🧾 Positions loaded: ${loaded} (skipped ${skipped}), total notional ≈ ${totalNotional.toFixed(2)} USDC`);
    //     } catch (error: any) {
    //         console.log(`🧾 Positions reconciliation failed: ${error.message || 'Unknown error'}`);
    //     }
    // }

    stop(): void {
        this.isRunning = false;

        if (this.wsMonitor) {
            this.wsMonitor.close();
        }

        console.log('\n🛑 Bot stopped');
        this.printStats();
    }

    printStats(): void {
        console.log('\n📊 Session Statistics:');
        console.log(`   Trades detected: ${this.stats.tradesDetected}`);
        console.log(`   Trades copied: ${this.stats.tradesCopied}`);
        console.log(`   Trades failed: ${this.stats.tradesFailed}`);
        console.log(`   Total volume: ${this.stats.totalVolume.toFixed(2)} pUSD`);
    }

    private sleep(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    private getTradeKeys(trade: Trade): string[] {
        const keys: string[] = [];
    
        if (trade.txHash) {
          keys.push(trade.txHash);
        }
    
        const fallbackKey = `${trade.tokenId}|${trade.side}|${trade.size}|${trade.price}|${trade.timestamp}`;
        keys.push(fallbackKey);
    
        return keys;
    }

    private pruneProcessedTrades(): void {
        if (this.processedTrades.size <= this.maxProcessedTrades) {
            return;
        }
    
        const entries = Array.from(this.processedTrades);
        this.processedTrades = new Set(entries.slice(-Math.floor(this.maxProcessedTrades / 2)));
    }
}

async function main() {
    const bot = new PolymarketCopyBot();

    process.on('SIGINT', () => {
        console.log('\n\nReceived SIGINT, shutting down...');
        bot.stop();
        process.exit(0);
    });

    process.on('SIGTERM', () => {
        bot.stop();
        process.exit(0);
    });

    try {
        await bot.initialize();
        await bot.start();
    } catch (error) {
        console.error('Fatal error:', error);
        process.exit(1);
    }
}

main();
import { ethers } from 'ethers';
import { ClobClient, SignatureTypeV2 } from '@polymarket/clob-client-v2';
import { config } from './config';

const PRIVATE_KEY = config.privateKey;
const CLOB_HTTP_URL = 'https://clob.polymarket.com';
const RPC_URL = config.rpcUrl;

// Check if the address is a Gnosis Safe
const isGnosisSafe = async (address: string): Promise<boolean> => {
    try {
        const provider = new ethers.providers.JsonRpcProvider(RPC_URL);
        const code = await provider.getCode(address);
        return code !== '0x';
    } catch (error) {
        console.error(`Error checking if ${address} is a Gnosis Safe: ${error}`);
        return false;
    }
}

const createClobClient = async (): Promise<ClobClient> => {
    const chainId = 137; // Polygon Mainnet
    const host = CLOB_HTTP_URL as string;
    const wallet = new ethers.Wallet(PRIVATE_KEY as string);
    const proxyWallet = await wallet.getAddress();

    const isProxySafe = await isGnosisSafe(proxyWallet);
    const signatureType = isProxySafe ? SignatureTypeV2.POLY_GNOSIS_SAFE : SignatureTypeV2.EOA;

    console.info(
        `Wallet type detected: ${isProxySafe ? 'Gnosis Safe' : 'EOA (Externally Owned Account)'}`
    );
    console.info(`Your address - ${proxyWallet}`);

    let clobClient = new ClobClient({
        host,
        chain: chainId,
        signer: wallet,
        creds: undefined,
        signatureType: signatureType as SignatureTypeV2,
    });

    // Suppress console output during API key creation
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    console.log = function () {};
    console.error = function () {};

    let creds = await clobClient.createApiKey();
    if (!creds.key) {
        creds = await clobClient.deriveApiKey();
    }

    clobClient = new ClobClient({
        host,
        chain: chainId,
        signer: wallet,
        creds: creds,
        signatureType: signatureType as SignatureTypeV2,
        funderAddress: isProxySafe ? (proxyWallet as string) : undefined,
    });

    // Restore console functions
    console.log = originalConsoleLog;
    console.error = originalConsoleError;

    return clobClient;
};

export default createClobClient;
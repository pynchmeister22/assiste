import * as fs from 'fs';
import * as path from 'path';

/** One line = one JSON object: compact Gamma market fields only (no trade payload). */
export type MarketInfoSnapshot = Record<string, unknown>;

const DEFAULT_FILE = path.join('logs', 'market-detections.jsonl');

let dedupLoaded = false;
const seenKeys = new Set<string>();

function ensureDir(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function keysForSnapshot(snapshot: MarketInfoSnapshot): string[] {
  const keys: string[] = [];
  const id = snapshot.id;
  const conditionId = snapshot.conditionId;
  if (id != null && String(id).length > 0) {
    keys.push(`id:${String(id)}`);
  }
  if (conditionId != null && String(conditionId).length > 0) {
    keys.push(`cond:${String(conditionId).toLowerCase()}`);
  }
  return keys;
}

/** Register keys from a snapshot already present on disk (new or legacy line shape). */
function ingestLineForDedup(line: string): void {
  const trimmed = line.trim();
  if (!trimmed) return;
  let o: unknown;
  try {
    o = JSON.parse(trimmed) as unknown;
  } catch {
    return;
  }
  if (!o || typeof o !== 'object' || Array.isArray(o)) return;
  const row = o as Record<string, unknown>;

  // New format: flat market snapshot only
  if (row.trade === undefined && (row.id != null || row.conditionId != null)) {
    for (const k of keysForSnapshot(row)) seenKeys.add(k);
    return;
  }

  // Legacy format: { market: { id, conditionId, ... }, trade, ... }
  const nested = row.market;
  if (nested && typeof nested === 'object' && !Array.isArray(nested)) {
    for (const k of keysForSnapshot(nested as MarketInfoSnapshot)) seenKeys.add(k);
  }
}

export function loadMarketLogDedupFromDisk(filePath: string = DEFAULT_FILE): void {
  if (dedupLoaded) {
    return;
  }
  if (!fs.existsSync(filePath)) {
    dedupLoaded = true;
    return;
  }
  const text = fs.readFileSync(filePath, { encoding: 'utf8' });
  for (const line of text.split('\n')) {
    ingestLineForDedup(line);
  }
  dedupLoaded = true;
}

function ensureDedupLoaded(filePath: string): void {
  if (!dedupLoaded) {
    loadMarketLogDedupFromDisk(filePath);
  }
}

/**
 * Append a single line of market-only JSON if this market has not been logged yet.
 * Dedupes by Gamma `id` and/or `conditionId` (case-folded for condition id).
 * @returns true if a new line was written
 */
export function appendUniqueMarketSnapshot(
  snapshot: MarketInfoSnapshot,
  filePath: string = DEFAULT_FILE,
): boolean {
  ensureDedupLoaded(filePath);
  const keys = keysForSnapshot(snapshot);
  if (keys.length === 0) {
    return false;
  }
  if (keys.some((k) => seenKeys.has(k))) {
    return false;
  }
  for (const k of keys) {
    seenKeys.add(k);
  }
  const dir = path.dirname(filePath);
  ensureDir(dir);
  fs.appendFileSync(filePath, JSON.stringify(snapshot) + '\n', { encoding: 'utf8' });
  return true;
}

import dotenv from 'dotenv';
dotenv.config();

function parseCsv(value?: string): string[] {
    if (!value) return [];
    return value.split(',').map((v) => v.trim()).filter(Boolean);
}
  

const useWebSocket = process.env.USE_WEBSOCKET !== 'false';

export const config = {
    targetWallet: process.env.TARGET_WALLET || '',
    privateKey: process.env.PRIVATE_KEY || '',
    polymarketGeoToken: process.env.POLYMARKET_GEO_TOKEN || '',
    rpcUrl: process.env.RPC_URL || '',
    chainId: 137,

    contracts: {
        pusd: process.env.PUSD_CONTRACT || '',
    },

    trading: {
        positionSizeMultiplier: parseFloat(process.env.POSITION_MULTIPLIER || '0.1'),
        maxTradeSize: parseFloat(process.env.MAX_TRADE_SIZE || '100'),
        minTradeSize: parseFloat(process.env.MIN_TRADE_SIZE || '1'),
        slippageTolerance: parseFloat(process.env.SLIPPAGE_TOLERANCE || '0.02'),
        // LIMIT=GTC, FOK=fill-or-kill, FAK=fill-and-kill
        orderType: (process.env.ORDER_TYPE || 'FOK') as 'LIMIT' | 'FOK' | 'FAK',
    },

    risk: {
        maxSessionNotional: parseFloat(process.env.MAX_SESSION_NOTIONAL || '0'),
        maxPerMarketNotional: parseFloat(process.env.MAX_PER_MARKET_NOTIONAL || '0'),
    },

    monitoring: {
        pollInterval: parseInt(process.env.POLL_INTERVAL || '2000'),
        useWebSocket,
        useUserChannel: process.env.USE_USER_CHANNEL === 'true',
        wsAssetIds: parseCsv(process.env.WS_ASSET_IDS),
        wsMarketIds: parseCsv(process.env.WS_MARKET_IDS),
    },

    withdraw: {
        autoWithdraw: process.env.AUTO_WITHDRAW === 'true',
        withdrawAddress: process.env.WITHDRAW_ADDRESS || '',
        withdrawAmount: parseFloat(process.env.WITHDRAW_AMOUNT || '0'),
        withdrawPoint: parseFloat(process.env.WITHDRAW_POINT || '0'),
    }
};

export function validateConfig(): void {
    const required = [
        'targetWallet',
        'privateKey'
    ];

    for (const key of required) {
        if (!config[key as keyof typeof config]) {
            throw new Error(`Missing required config: ${key}`);
        }
    }

    console.log('ℹ️  API credentials will be derived/generated from PRIVATE_KEY at startup');

    console.log('✅ Configuration validated');
    console.log(`   Auth: EOA (signature type 0)`);
}
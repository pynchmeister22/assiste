import axios from 'axios';

const GAMMA_BASE = 'https://gamma-api.polymarket.com';

const CONDITION_ID_RE = /^0x[a-fA-F0-9]{64}$/i;
const GAMMA_MARKET_ID_RE = /^\d+$/;

/** Raw Gamma market payload (subset used for logging; API may return more fields). */
export type GammaMarket = Record<string, unknown>;

export type MarketLookupMeta = {
  strategy: 'gamma_market_id' | 'condition_id' | 'none';
  requestedGammaMarketId?: string;
  requestedConditionId?: string;
};

export type ResolveMarketResult = {
  market: GammaMarket | null;
  lookup: MarketLookupMeta;
  error?: string;
};

function isConditionId(value: string): boolean {
  return CONDITION_ID_RE.test(value.trim());
}

function isGammaNumericId(value: string): boolean {
  return GAMMA_MARKET_ID_RE.test(value.trim());
}

export async function fetchMarketByGammaId(gammaMarketId: string): Promise<GammaMarket | null> {
  const id = gammaMarketId.trim();
  if (!isGammaNumericId(id)) return null;
  const url = `${GAMMA_BASE}/markets/${encodeURIComponent(id)}`;
  const { data } = await axios.get<GammaMarket>(url, {
    headers: { Accept: 'application/json' },
    validateStatus: () => true,
  });
  if (!data || typeof data !== 'object' || Array.isArray(data)) return null;
  if ('error' in data) return null;
  return data;
}

export async function fetchMarketByConditionId(conditionId: string): Promise<GammaMarket | null> {
  const id = conditionId.trim();
  if (!isConditionId(id)) return null;
  const url = `${GAMMA_BASE}/markets`;
  const { data, status } = await axios.get<GammaMarket[]>(url, {
    params: { condition_ids: id, limit: 1 },
    headers: { Accept: 'application/json' },
    validateStatus: () => true,
  });
  if (status >= 400 || !Array.isArray(data) || data.length === 0) return null;
  const row = data[0];
  if (!row || typeof row !== 'object') return null;
  return row;
}

/**
 * Resolve Gamma market metadata for a detected trade.
 * Prefer explicit `gammaMarketId` when present; otherwise use `trade.market` as condition id or numeric id.
 */
export async function resolveMarketForTrade(trade: {
  market: string;
  gammaMarketId?: string;
}): Promise<ResolveMarketResult> {
  const gammaId = trade.gammaMarketId?.trim();
  const marketField = trade.market?.trim() ?? '';

  try {
    if (gammaId && isGammaNumericId(gammaId)) {
      const market = await fetchMarketByGammaId(gammaId);
      return {
        market,
        lookup: { strategy: 'gamma_market_id', requestedGammaMarketId: gammaId },
        error: market ? undefined : `No market returned for Gamma id ${gammaId}`,
      };
    }

    if (isConditionId(marketField)) {
      const market = await fetchMarketByConditionId(marketField);
      return {
        market,
        lookup: { strategy: 'condition_id', requestedConditionId: marketField },
        error: market ? undefined : `No market returned for condition_id ${marketField}`,
      };
    }

    if (isGammaNumericId(marketField)) {
      const market = await fetchMarketByGammaId(marketField);
      return {
        market,
        lookup: { strategy: 'gamma_market_id', requestedGammaMarketId: marketField },
        error: market ? undefined : `No market returned for Gamma id ${marketField}`,
      };
    }

    return {
      market: null,
      lookup: { strategy: 'none' },
      error: `trade.market is neither a condition id (0x…64 hex) nor a Gamma numeric id: ${marketField}`,
    };
  } catch (e: any) {
    return {
      market: null,
      lookup: {
        strategy: gammaId && isGammaNumericId(gammaId) ? 'gamma_market_id' : isConditionId(marketField) ? 'condition_id' : 'none',
        requestedGammaMarketId: gammaId && isGammaNumericId(gammaId) ? gammaId : isGammaNumericId(marketField) ? marketField : undefined,
        requestedConditionId: isConditionId(marketField) ? marketField : undefined,
      },
      error: e?.message || String(e),
    };
  }
}

/** Compact snapshot for logs (avoids huge nested `events` blobs). */
export function summarizeGammaMarket(m: GammaMarket): Record<string, unknown> {
  return {
    id: m.id,
    question: m.question,
    slug: m.slug,
    conditionId: m.conditionId,
    endDate: m.endDate,
    endDateIso: m.endDateIso,
    active: m.active,
    closed: m.closed,
    outcomes: m.outcomes,
    outcomePrices: m.outcomePrices,
    clobTokenIds: m.clobTokenIds,
    negRisk: m.negRisk,
    resolutionSource: m.resolutionSource,
  };
}

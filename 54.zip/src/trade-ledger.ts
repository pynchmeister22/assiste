import * as fs from 'fs';
import * as path from 'path';
import type { Trade } from './monitor.js';
import type { CopyExecutionResult } from './trader.js';

export type TradeLedgerEntry = {
  /** ISO timestamp when we wrote the log entry */
  loggedAt: string;
  /** Chain time of the detected trade */
  tradeTime: string;

  /** Target wallet trade identifiers */
  targetTxHash: string;
  conditionId: string;
  tokenId: string;

  /** What the target wallet did */
  targetSide: 'BUY' | 'SELL';
  targetOutcome: Trade['outcome'];
  targetPrice: number;
  targetNotional: number;

  /** What the bot did */
  botOrderId: string;
  botSide: CopyExecutionResult['side'];
  botPrice: number;
  botNotional: number;
  botShares: number;
};

function ensureDir(dirPath: string): void {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

/**
 * Append one line of JSON to a ledger file for later reconciliation/redemption.
 * JSONL is intentional: easy to append and parse incrementally.
 */
export function appendTradeLedgerEntry(entry: TradeLedgerEntry, filePath = path.join('logs', 'trade-ledger.jsonl')): void {
  const dir = path.dirname(filePath);
  ensureDir(dir);
  fs.appendFileSync(filePath, JSON.stringify(entry) + '\n', { encoding: 'utf8' });
}

export function toTradeLedgerEntry(trade: Trade, result: CopyExecutionResult): TradeLedgerEntry {
  return {
    loggedAt: new Date().toISOString(),
    tradeTime: new Date(trade.timestamp).toISOString(),
    targetTxHash: trade.txHash,
    conditionId: trade.market,
    tokenId: trade.tokenId,
    targetSide: trade.side,
    targetOutcome: trade.outcome,
    targetPrice: trade.price,
    targetNotional: trade.size,
    botOrderId: result.orderId,
    botSide: result.side,
    botPrice: result.price,
    botNotional: result.copyNotional,
    botShares: result.copyShares,
  };
}


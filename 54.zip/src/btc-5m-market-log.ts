import * as fs from 'fs';
import * as path from 'path';

/** Root file shape: `{ [conditionId]: Btc5mMarketEntry }` */
export type Btc5mMarketsFile = Record<string, Btc5mMarketEntry>;

/** Redeem lifecycle for BTC 5m rows (bot-maintained). */
export type Btc5mRedeemStatus = 'active_in_cycle' | 'not_redeemed' | 'nothing_to_redeem' | 'redeemed';

export type Btc5mMarketEntry = {
  conditionId: string;
  slug: string;
  market: 'btc';
  cycleStartedAtIso: string;
  cycleEndedAtIso: string;
  redeemStatus: Btc5mRedeemStatus | string;
  updatedAtIso: string;
  nothingToRedeemNote?: string;
  /** Set when `redeemStatus` becomes `redeemed` (on-chain redeem completed). */
  redeemedAtIso?: string;
  transactionHash?: string;
  balanceAfterUsdc?: string;
  redeemSource?: 'auto' | 'manual' | 'batch' | 'pnl_pending';
};

export const BTC_5M_MARKETS_FILE = path.join('logs', 'btc-5m-markets.json');

const SLUG_RE = /^btc-updown-5m-(\d+)$/i;

/** Slug pattern for Polymarket BTC 5-minute Up/Down markets, e.g. `btc-updown-5m-1776117600`. */
export function isBtc5mMarketSlug(slug: unknown): slug is string {
  return typeof slug === 'string' && SLUG_RE.test(slug.trim());
}

export function parseCycleFromBtc5mSlug(slug: string): { startMs: number; endMs: number } | null {
  const m = slug.trim().match(SLUG_RE);
  if (!m) return null;
  const startSec = parseInt(m[1], 10);
  if (!Number.isFinite(startSec) || startSec <= 0) return null;
  const startMs = startSec * 1000;
  const endMs = startMs + 5 * 60 * 1000;
  return { startMs, endMs };
}

/** Normalized object key for `btc-5m-markets.json` (lowercase condition id). */
export function btc5mMapKey(conditionId: string): string {
  return conditionId.trim().toLowerCase();
}

function ensureDir(filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

export function readBtc5mMarketsMap(filePath: string = BTC_5M_MARKETS_FILE): Btc5mMarketsFile {
  if (!fs.existsSync(filePath)) {
    return {};
  }
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, { encoding: 'utf8' })) as unknown;
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      return raw as Btc5mMarketsFile;
    }
  } catch {
    // corrupt / empty — start fresh in memory (caller may overwrite file on save)
  }
  return {};
}

export function writeBtc5mMarketsMap(map: Btc5mMarketsFile, filePath: string = BTC_5M_MARKETS_FILE): void {
  ensureDir(filePath);
  fs.writeFileSync(filePath, JSON.stringify(map, null, 2), { encoding: 'utf8' });
}

/**
 * Find the previous BTC 5m cycle for a given (new) BTC 5m slug by time adjacency.
 * - First tries strict adjacency: prev.end === next.start
 * - Else chooses the most recent cycle that ended before next.start
 */
export function findPreviousBtc5mCycleForSlug(
  map: Btc5mMarketsFile,
  newSlug: string,
): { conditionId: string; slug: string } | null {
  const next = parseCycleFromBtc5mSlug(newSlug);
  if (!next) return null;

  let adjacent: { conditionId: string; slug: string } | null = null;
  let bestBefore: { conditionId: string; slug: string; endMs: number } | null = null;

  for (const e of Object.values(map)) {
    if (!e?.slug || !isBtc5mMarketSlug(e.slug)) continue;
    if (e.slug === newSlug) continue;
    const prev = parseCycleFromBtc5mSlug(e.slug);
    if (!prev) continue;

    if (prev.endMs === next.startMs) {
      adjacent = { conditionId: e.conditionId, slug: e.slug };
      break;
    }

    if (prev.endMs < next.startMs) {
      if (!bestBefore || prev.endMs > bestBefore.endMs) {
        bestBefore = { conditionId: e.conditionId, slug: e.slug, endMs: prev.endMs };
      }
    }
  }

  if (adjacent) return adjacent;
  if (bestBefore) return { conditionId: bestBefore.conditionId, slug: bestBefore.slug };
  return null;
}

const TERMINAL_REDEEM = new Set(['nothing_to_redeem', 'redeemed']);

function markOtherActiveCyclesAsNotRedeemed(
  map: Btc5mMarketsFile,
  exceptKey: string,
  nowMs: number,
): boolean {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();
  for (const k of Object.keys(map)) {
    if (k === exceptKey) continue;
    const e = map[k];
    if (!e) continue;
    if (e.redeemStatus !== 'active_in_cycle') continue;
    e.redeemStatus = 'not_redeemed';
    e.updatedAtIso = nowIso;
    delete e.nothingToRedeemNote;
    changed = true;
  }
  return changed;
}

/**
 * Insert or refresh a BTC 5m row from a known `conditionId` + `slug`.
 * Preserves `redeemStatus` / `nothingToRedeemNote` when the row already exists (bot-owned fields).
 */
/** Prior BTC 5m row(s) that were `active_in_cycle` before this new window was inserted (for async redeem). */
export type Btc5mRolloverFrom = { conditionId: string; slug: string };

export function upsertBtc5mMarketEntry(
  conditionId: string,
  slug: string,
  filePath: string = BTC_5M_MARKETS_FILE,
): { ok: boolean; created: boolean; rolledOverFrom: Btc5mRolloverFrom[] } {
  const empty = { ok: false, created: false, rolledOverFrom: [] as Btc5mRolloverFrom[] };
  if (!isBtc5mMarketSlug(slug)) {
    return empty;
  }
  const cycle = parseCycleFromBtc5mSlug(slug);
  if (!cycle) {
    return empty;
  }

  const key = btc5mMapKey(conditionId);
  const map = readBtc5mMarketsMap(filePath);
  const now = Date.now();
  const nowIso = new Date(now).toISOString();
  const startedIso = new Date(cycle.startMs).toISOString();
  const endedIso = new Date(cycle.endMs).toISOString();

  if (map[key]) {
    const prev = map[key];
    prev.slug = slug;
    prev.conditionId = conditionId;
    prev.market = 'btc';
    prev.cycleStartedAtIso = startedIso;
    prev.cycleEndedAtIso = endedIso;
    prev.updatedAtIso = nowIso;
    writeBtc5mMarketsMap(map, filePath);
    return { ok: true, created: false, rolledOverFrom: [] };
  }

  const rolledOverFrom: Btc5mRolloverFrom[] = [];
  // Prefer the immediately previous 5m cycle by time adjacency (prev.end === new.start).
  // This is more reliable than status-based detection because time-based maintenance may
  // have already flipped the previous row to `not_redeemed`.
  for (const k of Object.keys(map)) {
    const e = map[k];
    if (!e?.slug || e.conditionId === conditionId) continue;
    const prevCycle = parseCycleFromBtc5mSlug(e.slug);
    if (!prevCycle) continue;
    if (prevCycle.endMs === cycle.startMs) {
      rolledOverFrom.push({ conditionId: e.conditionId, slug: e.slug });
    }
  }
  // Fallback: if we didn't find an adjacent cycle, roll over any still-marked active cycle.
  for (const k of Object.keys(map)) {
    const e = map[k];
    if (rolledOverFrom.length === 0 && e?.redeemStatus === 'active_in_cycle') {
      rolledOverFrom.push({ conditionId: e.conditionId, slug: e.slug });
    }
  }

  // A new 5m window started: any still-active prior window is no longer the live cycle.
  markOtherActiveCyclesAsNotRedeemed(map, key, now);

  const redeemStatus: Btc5mRedeemStatus = now < cycle.endMs ? 'active_in_cycle' : 'not_redeemed';
  map[key] = {
    conditionId,
    slug,
    market: 'btc',
    cycleStartedAtIso: startedIso,
    cycleEndedAtIso: endedIso,
    redeemStatus,
    updatedAtIso: nowIso,
  };
  writeBtc5mMarketsMap(map, filePath);
  return { ok: true, created: true, rolledOverFrom };
}

/** Bot updates redeem state locally (no Polymarket HTTP API). */
export function updateBtc5mMarketRedeemStatus(
  conditionId: string,
  redeemStatus: string,
  opts?: { nothingToRedeemNote?: string; clearNote?: boolean },
  filePath: string = BTC_5M_MARKETS_FILE,
): boolean {
  const key = btc5mMapKey(conditionId);
  const map = readBtc5mMarketsMap(filePath);
  if (!map[key]) {
    return false;
  }
  map[key].redeemStatus = redeemStatus;
  map[key].updatedAtIso = new Date().toISOString();
  if (opts?.clearNote) {
    delete map[key].nothingToRedeemNote;
  } else if (opts?.nothingToRedeemNote !== undefined) {
    map[key].nothingToRedeemNote = opts.nothingToRedeemNote;
  }
  writeBtc5mMarketsMap(map, filePath);
  return true;
}

/**
 * Time-based transition: after `cycleEndedAtIso`, move `active_in_cycle` (and legacy `cycle_ended`) to `not_redeemed`.
 * Call periodically from the bot loop (no external API).
 */
export function advanceBtc5mRedeemStatusesForTime(
  filePath: string = BTC_5M_MARKETS_FILE,
  nowMs: number = Date.now(),
): boolean {
  const map = readBtc5mMarketsMap(filePath);
  let changed = false;
  for (const key of Object.keys(map)) {
    const e = map[key];
    if (!e?.cycleEndedAtIso) continue;
    const end = Date.parse(e.cycleEndedAtIso);
    if (!Number.isFinite(end)) continue;
    if (nowMs <= end) continue;
    if (TERMINAL_REDEEM.has(e.redeemStatus)) continue;
    if (e.redeemStatus === 'not_redeemed') continue;
    if (e.redeemStatus === 'active_in_cycle' || e.redeemStatus === 'cycle_ended') {
      e.redeemStatus = 'not_redeemed';
      e.updatedAtIso = new Date(nowMs).toISOString();
      delete e.nothingToRedeemNote;
      changed = true;
    }
  }
  if (changed) {
    writeBtc5mMarketsMap(map, filePath);
  }
  return changed;
}

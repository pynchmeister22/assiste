/**
 * Standalone entry: spawned by the bot after each 5m cycle so redemption never blocks
 * the trading loop. Retries until the market is resolved on-chain or limits are hit.
 */
import { redeemMarket } from '../utils/redeem.js';
import { config } from '../config.js';
import { Wallet } from '@ethersproject/wallet';
import getMyBalance from '../utils/getMyBalance.js';
import { markCycleNothingToRedeem, markCycleRedeemed } from '../utils/pnlRedeemTracking.js';
import { runAutoWithdrawAfterRedeem } from './runAutoWithdraw.js';

function sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function isNotResolvedMessage(msg: string): boolean {
    return /not yet resolved/i.test(msg);
}

function isNoPositionMessage(msg: string): boolean {
    return (
        /don't have any tokens/i.test(msg) ||
        /don't hold any winning/i.test(msg) ||
        /no tokens for this condition/i.test(msg)
    );
}

function txHashFromReceipt(receipt: { transactionHash?: string; hash?: string }): string | undefined {
    if (typeof receipt?.transactionHash === "string") return receipt.transactionHash;
    if (receipt?.hash != null) return String(receipt.hash);
    return undefined;
}

async function afterSuccessfulRedeem(
    conditionId: string,
    slug: string,
    receipt: { transactionHash?: string; hash?: string }
): Promise<void> {
    const txHash = txHashFromReceipt(receipt);

    let balanceStr: string | undefined;
    try {
        const privateKey = config.privateKey;
        const wallet = new Wallet(privateKey);
        const walletAddress = await wallet.getAddress();
        try {
            const balanceAfter = await getMyBalance(walletAddress);
            balanceStr = balanceAfter.toFixed(6);
            console.info(`[redeem-auto] Wallet balance after redeem: ${balanceStr} USDC`);
        } catch {
            /* optional */
        }
    } catch (e) {
        console.error(`[redeem-auto] post-redeem balance: ${e instanceof Error ? e.message : String(e)}`);
    }

    markCycleRedeemed({
        conditionId,
        transactionHash: txHash,
        balanceAfterUsdc: balanceStr,
        source: "auto",
        slug,
    });

    try {
        const { clearMarketHoldings } = await import('../utils/holdings.js');
        clearMarketHoldings(conditionId);
        console.info(`[redeem-auto] Cleared holdings for ${conditionId}`);
    } catch (e) {
        console.error(`[redeem-auto] clear holdings: ${e instanceof Error ? e.message : String(e)}`);
    }

    await runAutoWithdrawAfterRedeem();
}

async function main(): Promise<void> {
    const args = process.argv.slice(2);
    const conditionId = args[0]?.trim();
    const slug = args[1]?.trim() || "?";

    if (!conditionId || !/^0x[a-fA-F0-9]{64}$/.test(conditionId)) {
        console.error("[redeem-auto] Missing or invalid conditionId (expected 0x + 64 hex)");
        process.exit(1);
    }

    const interval = Math.max(5_000, 30_000);
    const max = Math.max(1, 10);

    console.info(
        `[redeem-auto] Started for conditionId=${conditionId} slug=${slug} retryMs=${interval} maxAttempts=${max}`
    );

    for (let attempt = 1; attempt <= max; attempt++) {
        try {
            const receipt = await redeemMarket(conditionId);
            console.info(
                `[redeem-auto] Success tx=${receipt?.transactionHash ?? receipt?.hash ?? "?"} block=${receipt?.blockNumber ?? "?"}`
            );
            await afterSuccessfulRedeem(conditionId, slug, receipt);
            process.exit(0);
        } catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            if (isNotResolvedMessage(msg)) {
                console.info(`[redeem-auto] Attempt ${attempt}/${max}: not resolved — retry in ${interval}ms`);
                if (attempt < max) await sleep(interval);
                continue;
            }
            if (isNoPositionMessage(msg)) {
                console.info(`[redeem-auto] Nothing to redeem: ${msg}`);
                markCycleNothingToRedeem({ conditionId, slug, note: msg.slice(0, 500) });
                process.exit(0);
            }
            console.error(`[redeem-auto] Fatal: ${msg}`);
            process.exit(1);
        }
    }

    console.error(`[redeem-auto] Gave up after ${max} attempts (conditionId=${conditionId})`);
    process.exit(1);
}

main().catch((e) => {
    console.error(`[redeem-auto] ${e instanceof Error ? e.message : String(e)}`);
    process.exit(1);
});

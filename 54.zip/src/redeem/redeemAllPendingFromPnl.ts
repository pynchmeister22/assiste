/**
 * CLI: redeem every `logs/btc-5m-markets.json` row with redeemStatus === "not_redeemed".
 * One attempt per market for "not yet resolved" (skips, continues); use `redeem:unresolved` for per-market retry loops.
 */
import { redeemMarket } from '../utils/redeem.js';
import {
    getNotRedeemedCycleEntries,
    markCycleNothingToRedeem,
    markCycleRedeemed,
} from '../utils/pnlRedeemTracking.js';

function isNotResolvedMessage(msg: string): boolean {
    return /not yet resolved/i.test(msg);
}

function isNoPositionMessage(msg: string): boolean {
    return (
        /don't have any tokens/i.test(msg) ||
        /don't hold any winning/i.test(msg) ||
        /no tokens for this condition/i.test(msg)
    );
}

function txHashFromReceipt(receipt: { transactionHash?: string; hash?: string }): string | undefined {
    if (typeof receipt?.transactionHash === "string") return receipt.transactionHash;
    if (receipt?.hash != null) return String(receipt.hash);
    return undefined;
}

async function main(): Promise<void> {
    const pending = getNotRedeemedCycleEntries();
    if (pending.length === 0) {
        console.info('[redeem:pnl-pending] No entries with redeemStatus=not_redeemed in logs/btc-5m-markets.json');
        process.exit(0);
    }

    console.info(`[redeem:pnl-pending] Processing ${pending.length} not_redeemed cycle(s) (oldest first)`);

    let redeemed = 0;
    let skippedUnresolved = 0;
    let nothingToRedeem = 0;
    let failedOther = 0;

    for (const entry of pending) {
        const { conditionId, slug, market } = entry;
        console.info(`[redeem:pnl-pending] --- ${conditionId.slice(0, 14)}… slug=${slug} market=${market}`);

        try {
            const receipt = await redeemMarket(conditionId);
            const txHash = txHashFromReceipt(receipt);
            markCycleRedeemed({
                conditionId,
                transactionHash: txHash,
                source: "pnl_pending",
                slug,
                market,
            });
            redeemed++;
            console.info(
                `[redeem:pnl-pending] ✅ Redeemed tx=${txHash ?? "?"} block=${receipt?.blockNumber ?? "?"}`
            );

            try {
                const { clearMarketHoldings } = await import('../utils/holdings.js');
                clearMarketHoldings(conditionId);
            } catch (e) {
                console.error(
                    `[redeem:pnl-pending] clear holdings: ${e instanceof Error ? e.message : String(e)}`
                );
            }
        } catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            if (isNotResolvedMessage(msg)) {
                skippedUnresolved++;
                console.info(`[redeem:pnl-pending] ⏭️  Not resolved yet — skipping (retry later or use redeem:unresolved)`);
                continue;
            }
            if (isNoPositionMessage(msg)) {
                nothingToRedeem++;
                markCycleNothingToRedeem({ conditionId, slug, note: msg.slice(0, 500) });
                console.info(`[redeem:pnl-pending] ⏭️  Nothing to redeem: ${msg}`);
                continue;
            }
            failedOther++;
            console.error(`[redeem:pnl-pending] ❌ ${msg}`);
        }
    }

    console.info(
        `[redeem:pnl-pending] Done: redeemed=${redeemed} skipped_unresolved=${skippedUnresolved} nothing_to_redeem=${nothingToRedeem} failed=${failedOther}`
    );
    process.exit(failedOther > 0 ? 1 : 0);
}

main().catch((e) => {
    console.error(`[redeem:pnl-pending] Fatal: ${e instanceof Error ? e.message : String(e)}`);
    process.exit(1);
});

import { Wallet } from "@ethersproject/wallet";

import { redeemMarket } from '../utils/redeem.js';

import { getAllHoldings, getMarketHoldings } from '../utils/holdings.js';

import { config } from '../config.js';

import getMyBalance from '../utils/getMyBalance.js';

import { markCycleRedeemed } from '../utils/pnlRedeemTracking.js';



async function main() {

    const args = process.argv.slice(2);



    // Get condition ID from args or env

    let conditionId: string | undefined;

    let indexSets: number[] | undefined;



    if (args.length > 0) {

        conditionId = args[0];

        if (args.length > 1) {

            indexSets = args.slice(1).map(arg => parseInt(arg, 10));

        }

    }



    // If no conditionId provided, show holdings and prompt

    if (!conditionId) {

        console.info("No condition ID provided. Showing current holdings...");

        const holdings = getAllHoldings();



        if (Object.keys(holdings).length === 0) {

            console.error("No holdings found.");

            console.info("\nUsage:");

            console.info("  bun src/redeem.ts <conditionId> [indexSets...]");

            console.info("  bun src/redeem.ts 0x5f65177b394277fd294cd75650044e32ba009a95022d88a0c1d565897d72f8f1 1 2");

            console.info("\nOr set in .env:");

            console.info("  CONDITION_ID=0x5f65177b394277fd294cd75650044e32ba009a95022d88a0c1d565897d72f8f1");

            console.info("  INDEX_SETS=1,2");

            process.exit(1);

        }



        console.info("\nCurrent Holdings:");

        for (const [marketId, tokens] of Object.entries(holdings)) {

            console.info(`  Market: ${marketId}`);

            for (const [tokenId, amount] of Object.entries(tokens)) {

                console.info(`    Token ${tokenId.substring(0, 20)}...: ${amount}`);

            }

        }

        console.info("\nTo redeem a market, provide the conditionId (market ID) as an argument.");

        console.info("Example: bun src/redeem.ts <conditionId>");

        process.exit(0);

    }



    // Default to [1, 2] for Polymarket binary markets if not specified

    if (!indexSets || indexSets.length === 0) {

        console.info("No index sets specified, using default [1, 2] for Polymarket binary markets");

        indexSets = [1, 2];

    }



    // Show holdings for this market if available

    const marketHoldings = getMarketHoldings(conditionId);

    if (Object.keys(marketHoldings).length > 0) {

        console.info(`\nHoldings for market ${conditionId}:`);

        for (const [tokenId, amount] of Object.entries(marketHoldings)) {

            console.info(`  Token ${tokenId.substring(0, 20)}...: ${amount}`);

        }

    } else {

        console.error(`No holdings found for market ${conditionId}`);

    }



    try {

        console.info(`\nRedeeming positions for condition: ${conditionId}`);

        console.info(`Index Sets: ${indexSets.join(", ")}`);



        const receipt = await redeemMarket(conditionId);



        console.info("\n✅ Successfully redeemed positions!");

        console.info(`Transaction hash: ${receipt.transactionHash}`);

        console.info(`Block number: ${receipt.blockNumber}`);

        console.info(`Gas used: ${receipt.gasUsed.toString()}`);



        const txHash =

            typeof receipt?.transactionHash === "string"

                ? receipt.transactionHash

                : receipt?.hash != null

                  ? String(receipt.hash)

                  : undefined;



        let balanceStr: string | undefined;

        try {

            const privateKey = config.privateKey;

            const wallet = new Wallet(privateKey);

            const walletAddress = await wallet.getAddress();

            const balanceAfterRedeem = await getMyBalance(walletAddress);

            balanceStr = balanceAfterRedeem.toFixed(6);

            console.info(`Wallet balance after redeem: ${balanceStr} USDC`);

        } catch (balanceError) {

            console.error(

                `Failed to get balance after redeem: ${balanceError instanceof Error ? balanceError.message : String(balanceError)}`

            );

        }



        markCycleRedeemed({

            conditionId,

            transactionHash: txHash,

            balanceAfterUsdc: balanceStr,

            source: "manual",

        });

        console.info(`✅ Updated redeem status in logs/btc-5m-markets.json`);



        try {

            const { clearMarketHoldings } = await import('../utils/holdings.js');

            clearMarketHoldings(conditionId);

            console.info(`\n✅ Cleared holdings record for this market from token-holding.json`);

        } catch (clearError) {

            console.error(`Failed to clear holdings: ${clearError instanceof Error ? clearError.message : String(clearError)}`);

        }

    } catch (error) {

        console.error(`\n❌ Failed to redeem positions:, ${error}`);

        if (error instanceof Error) {

            console.error(`Error message: ${error.message}`);

        }

        process.exit(1);

    }

}



main().catch((error) => {

    console.error(`Fatal error: ${error instanceof Error ? error.message : String(error)}`);

    process.exit(1);

});


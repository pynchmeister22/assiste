import { ethers, BigNumber } from "ethers";
import { parseUnits } from "@ethersproject/units";
import { Wallet } from "@ethersproject/wallet";
import { ENV } from "../config/env";
import logger from "../utils/appLogger";
import getMyBalance from "../utils/getMyBalance";

const ERC20_TRANSFER_ABI = ["function transfer(address to, uint256 amount) returns (bool)"];

function isZeroAddress(addr: string): boolean {
    return /^0x0{40}$/i.test(addr.trim());
}

/**
 * Sends USDC (native token on Polygon for Polymarket) to WITHDRAW_ADDRESS.
 * Intended to run inside the redeem worker right after a successful redeem — does not block the main bot.
 */
export async function runAutoWithdrawAfterRedeem(): Promise<void> {
    if (!ENV.AUTO_WITHDRAW) {
        return;
    }

    const to = (ENV.WITHDRAW_ADDRESS ?? "").trim();
    if (!to || !/^0x[a-fA-F0-9]{40}$/i.test(to) || isZeroAddress(to)) {
        logger.warn("[withdraw] AUTO_WITHDRAW is on but WITHDRAW_ADDRESS is missing or zero — skip");
        return;
    }

    const amountUsd = ENV.WITHDRAW_AMOUNT;
    if (!Number.isFinite(amountUsd) || amountUsd < 0.01) {
        logger.warn(`[withdraw] WITHDRAW_AMOUNT invalid or below minimum (${amountUsd}) — skip`);
        return;
    }

    const threshold = ENV.WITHDRAW_POINT;
    if (!Number.isFinite(threshold) || threshold < 0) {
        logger.warn(`[withdraw] WITHDRAW_POINT invalid (${threshold}) — skip`);
        return;
    }

    try {
        const wallet = new Wallet(ENV.PRIVATE_KEY);
        const provider = new ethers.providers.JsonRpcProvider(ENV.RPC_URL);
        const signer = wallet.connect(provider);
        const fromAddress = await signer.getAddress();

        const balance = await getMyBalance(fromAddress);
        logger.info(
            `[withdraw] Balance=${balance.toFixed(6)} USDC | WITHDRAW_POINT=${threshold} | amount=${amountUsd}`
        );

        if (balance <= threshold) {
            logger.info(`[withdraw] Balance not above WITHDRAW_POINT — skip`);
            return;
        }

        if (balance < amountUsd) {
            logger.warn(
                `[withdraw] Balance ${balance.toFixed(6)} < WITHDRAW_AMOUNT ${amountUsd} — skip (insufficient USDC)`
            );
            return;
        }

        const usdc = new ethers.Contract(ENV.PUSD_CONTRACT_ADDRESS, ERC20_TRANSFER_ABI, signer);
        const value = ethers.utils.parseUnits(amountUsd.toFixed(6), 6);

        let gasOptions: { gasPrice?: BigNumber, gasLimit?: number } = {};
        try {
            const gasPrice = await provider.getGasPrice();
            gasOptions = {
                gasPrice: gasPrice.mul(120).div(100),
                gasLimit: 200_000,
            };
        } catch (error) {
            logger.error("Could not fetch gas price, using fallback");
            gasOptions = {
                gasPrice: parseUnits("100", "gwei"),
                gasLimit: 200_000,
            };
        }

        logger.info(`[withdraw] Sending ${amountUsd} USDC → ${to}`);
        const tx = await usdc.transfer(to, value, gasOptions);
        logger.info(`[withdraw] Submitted tx=${tx.hash}`);
        const receipt = await tx.wait(1);
        logger.info(
            `[withdraw] Confirmed block=${receipt.blockNumber ?? "?"} status=${receipt.status ?? "?"}`
        );
    } catch (e) {
        logger.error(`[withdraw] Failed: ${e instanceof Error ? e.message : String(e)}`);
    }
}

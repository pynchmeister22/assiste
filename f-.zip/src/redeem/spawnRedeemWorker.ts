import { spawn } from "child_process";
import * as fs from "fs";
import * as path from "path";
import logger from "../utils/appLogger";

/**
 * Starts redemption in a separate OS process so RPC work, retries, and logging
 * cannot block the bot's event loop or be affected by the same unhandled rejection
 * stack as the main trader.
 */
export function spawnRedeemAutoWorker(conditionId: string, prevSlug: string): void {
    const scriptBase = path.join(__dirname, "redeemAuto");
    const jsPath = `${scriptBase}.js`;
    const tsPath = `${scriptBase}.ts`;
    const useCompiled = fs.existsSync(jsPath);
    const script = useCompiled ? jsPath : tsPath;

    if (!fs.existsSync(script)) {
        logger.error(`[redeem] Worker script missing: ${script}`);
        return;
    }

    const args = useCompiled
        ? [script, conditionId, prevSlug]
        : ["-r", "ts-node/register", script, conditionId, prevSlug];

    try {
        const child = spawn(process.execPath, args, {
            env: { ...process.env, POLYBOT_ROLE: "redeem-worker" },
            stdio: "inherit",
            windowsHide: true,
        });
        child.on("error", (err) => {
            logger.error(`[redeem] Failed to spawn worker: ${err.message}`);
        });
        child.on("exit", (code, signal) => {
            if (code !== 0 && code !== null) {
                logger.warn(
                    `[redeem] Worker exited code=${code} signal=${signal ?? ""} conditionId=${conditionId.slice(0, 18)}…`
                );
            }
        });
    } catch (e) {
        logger.error(`[redeem] spawn: ${e instanceof Error ? e.message : String(e)}`);
    }
}

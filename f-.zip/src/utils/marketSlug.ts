import logger from "./appLogger";
import { ENV } from "../config/env";

const ET_TZ = "America/New_York";

const MONTH_NAMES = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"] as const;

/** e.g. `bitcoin-up-or-down-may-3-2026-1am-et` */
const RE_HOURLY_ET = /^([a-z0-9]+)-up-or-down-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-(\d+)-(\d{4})-(\d{1,2})(am|pm)-et$/i;

/** Crypto interval slugs: `btc-updown-4h-{unix}` (also `5m` / `15m`). */
const RE_CRYPTO_INTERVAL = /-updown-(5m|15m|4h)-(\d+)$/i;

/**
 * Active Polymarket crypto up/down window length in seconds (UTC epoch buckets).
 * Configured via `CRYPTO_UPDOWN_INTERVAL` (5m | 15m | 4h); default 5m.
 */
export const CRYPTO_UPDOWN_INTERVAL_SECONDS = ENV.cryptoUpDown.intervalSeconds;

export function normalizeCryptoMarketKey(market: string): string {
    return String(market ?? "").trim().toLowerCase();
}

function etNumericParts(d: Date): { y: number; mon: number; day: number; h: number; min: number; sec: number } {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: ET_TZ,
        year: "numeric",
        month: "numeric",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        hour12: false,
    }).formatToParts(d);
    const num = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? NaN);
    return {
        y: num("year"),
        mon: num("month"),
        day: num("day"),
        h: num("hour"),
        min: num("minute"),
        sec: num("second"),
    };
}

function hour24ToAmPmSlug(h: number): string {
    const isPm = h >= 12;
    let h12 = h % 12;
    if (h12 === 0) h12 = 12;
    return `${h12}${isPm ? "pm" : "am"}`;
}

function parseMonthToken(tok: string): number | null {
    const i = MONTH_NAMES.indexOf(tok.toLowerCase() as (typeof MONTH_NAMES)[number]);
    return i >= 0 ? i + 1 : null;
}

function parseAmPmToHour24(h12: number, ap: string): number | null {
    if (!Number.isFinite(h12) || h12 < 1 || h12 > 12) return null;
    const up = ap.toLowerCase();
    if (up === "am") return h12 === 12 ? 0 : h12;
    if (up === "pm") return h12 === 12 ? 12 : h12 + 12;
    return null;
}

/**
 * UTC unix seconds for the first instant that is that wall-clock hour:00:00 in America/New_York
 * on the given calendar date (DST-aware via Intl).
 */
function findEtHourStartUnixSec(y: number, mon: number, day: number, hour24: number): number | null {
    const approxUtcSec = Math.floor(Date.UTC(y, mon - 1, day, 17, 0, 0) / 1000);
    for (let dt = -36 * 3600; dt <= 36 * 3600; dt++) {
        const t = approxUtcSec + dt;
        const p = etNumericParts(new Date(t * 1000));
        if (p.y === y && p.mon === mon && p.day === day && p.h === hour24 && p.min === 0 && p.sec === 0) {
            return t;
        }
    }
    return null;
}

/**
 * Polymarket crypto up/down slug for the current UTC-aligned window, e.g. `btc-updown-5m-1777786200`.
 */
export function slugForCurrentUpDownMarket(market: string): string {
    const key = normalizeCryptoMarketKey(market);
    const intervalSec = ENV.cryptoUpDown.intervalSeconds;
    const tag = ENV.cryptoUpDown.intervalTag;
    const nowSec = Math.floor(Date.now() / 1000);
    const startSec = Math.floor(nowSec / intervalSec) * intervalSec;
    return `${key}-updown-${tag}-${startSec}`;
}

/** Next UTC-aligned window after `slugForCurrentUpDownMarket` (same interval tag). */
export function slugForNextUpDownMarket(market: string): string {
    const key = normalizeCryptoMarketKey(market);
    const intervalSec = ENV.cryptoUpDown.intervalSeconds;
    const tag = ENV.cryptoUpDown.intervalTag;
    const nowSec = Math.floor(Date.now() / 1000);
    const currentStartSec = Math.floor(nowSec / intervalSec) * intervalSec;
    const nextStartSec = currentStartSec + intervalSec;
    return `${key}-updown-${tag}-${nextStartSec}`;
}

export function cycleStartUnixFromSlug(slug: string): number | null {
    const hm = slug.match(RE_HOURLY_ET);
    if (hm) {
        const mon = parseMonthToken(hm[2]);
        const day = parseInt(hm[3], 10);
        const y = parseInt(hm[4], 10);
        const h12 = parseInt(hm[5], 10);
        const hour24 = parseAmPmToHour24(h12, hm[6]);
        if (mon == null || !Number.isFinite(day) || !Number.isFinite(y) || hour24 == null) return null;
        return findEtHourStartUnixSec(y, mon, day, hour24);
    }
    const cm = slug.match(RE_CRYPTO_INTERVAL);
    if (cm) {
        const ts = parseInt(cm[2], 10);
        return Number.isFinite(ts) ? ts : null;
    }
    return null;
}

export function marketDurationSecondsFromSlug(slug: string): number | null {
    if (RE_HOURLY_ET.test(slug)) return 60 * 60;
    const m = slug.match(/-updown-(5m|15m|4h)-/i);
    if (!m) return null;
    const tag = m[1].toLowerCase();
    if (tag === "5m") return 5 * 60;
    if (tag === "15m") return 15 * 60;
    if (tag === "4h") return 4 * 60 * 60;
    return null;
}

/** Milliseconds until the next UTC-aligned crypto up/down window (matches `slugForCurrentUpDownMarket` boundaries). */
export function msUntilNextCryptoUpDownBoundary(nowMs = Date.now()): number {
    const intervalSec = ENV.cryptoUpDown.intervalSeconds;
    const nowSec = Math.floor(nowMs / 1000);
    const remainder = nowSec % intervalSec;
    if (remainder === 0) return 0;
    const nextStartSec = nowSec + (intervalSec - remainder);
    return Math.max(0, nextStartSec * 1000 - nowMs);
}

/** Milliseconds until the next top-of-clock-hour in America/New_York (for optional startup wait on hourly ET slugs). */
export function msUntilNextEtHourBoundary(nowMs = Date.now()): number {
    const ceiling = Math.ceil(nowMs / 1000) * 1000;
    for (let t = ceiling; t <= ceiling + 7201 * 1000; t += 1000) {
        const p = etNumericParts(new Date(t));
        if (p.min === 0 && p.sec === 0 && t > nowMs) {
            return t - nowMs;
        }
    }
    return 0;
}

export async function fetchTokenIdsForSlug(
    slug: string
): Promise<{ upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }> {
    try {
        const url = `https://gamma-api.polymarket.com/markets/slug/${encodeURIComponent(slug)}`;
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Gamma API ${response.status} ${response.statusText} for slug=${slug}`);
        }

        const data = (await response.json()) as any;
        const outcomes = parseJsonArray<string>(data.outcomes, "data.outcomes");
        const tokenIds = parseJsonArray<string>(data.clobTokenIds, "data.clobTokenIds");
        const conditionId = data.conditionId as string;

        const upIdx = outcomes.indexOf("Up");
        const downIdx = outcomes.indexOf("Down");
        if (upIdx < 0 || downIdx < 0) throw new Error(`Missing Up/Down outcomes for slug=${slug}`);
        if (!tokenIds[upIdx] || !tokenIds[downIdx]) throw new Error(`Missing token ids for slug=${slug}`);

        const question: string = typeof data.question === "string" ? data.question : (data.title ?? "");
        const strikeMatch = question.match(/\$([0-9,]+(?:\.[0-9]+)?)/);
        const strikeK = strikeMatch ? parseFloat(strikeMatch[1].replace(/,/g, "")) : null;

        return { upTokenId: tokenIds[upIdx], downTokenId: tokenIds[downIdx], conditionId, upIdx, downIdx, strikeK };
    } catch (error) {
        logger.error(`Error fetching token IDs for slug=${slug}: ${error}`);
        throw error;
    }
}

function parseJsonArray<T>(raw: unknown, ctx: string): T[] {
    if (typeof raw !== "string") throw new Error(`${ctx}: expected JSON string`);
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) throw new Error(`${ctx}: expected JSON array`);
    return parsed as T[];
}

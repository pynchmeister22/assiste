import fs from "fs";
import path from "path";

/** Redeem lifecycle for a 5m cycle row (keyed by conditionId). */
export type RedeemStatus = "not_redeemed" | "redeemed" | "nothing_to_redeem";

export interface PnlCycleEntry {
    conditionId: string;
    slug: string;
    market: string;
    /** When the bot first learned about this conditionId (cycle start). */
    cycleStartedAtIso?: string;
    /** When the bot rolled to the next cycle (cycle end). */
    cycleEndedAtIso?: string;
    redeemStatus: RedeemStatus;
    redeemedAtIso?: string;
    transactionHash?: string;
    balanceAfterUsdc?: string;
    redeemSource?: "auto" | "manual" | "batch" | "pnl_pending";
    /** Set when redeemStatus is nothing_to_redeem */
    nothingToRedeemNote?: string;
    updatedAtIso: string;
}

interface PnlFileV1 {
    version: 1;
    byConditionId: Record<string, PnlCycleEntry>;
}

function pnlJsonPath(): string {
    return path.resolve(process.cwd(), "logs", "pnl.json");
}

function emptyFile(): PnlFileV1 {
    return { version: 1, byConditionId: {} };
}

function load(): PnlFileV1 {
    const p = pnlJsonPath();
    try {
        if (!fs.existsSync(p)) return emptyFile();
        const raw = fs.readFileSync(p, "utf8");
        const parsed = JSON.parse(raw) as unknown;
        if (
            parsed &&
            typeof parsed === "object" &&
            (parsed as PnlFileV1).version === 1 &&
            typeof (parsed as PnlFileV1).byConditionId === "object" &&
            (parsed as PnlFileV1).byConditionId !== null
        ) {
            return parsed as PnlFileV1;
        }
    } catch {
        // corrupt or empty — reset structure
    }
    return emptyFile();
}

function save(data: PnlFileV1): void {
    const p = pnlJsonPath();
    fs.mkdirSync(path.dirname(p), { recursive: true });
    const tmp = `${p}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
    fs.renameSync(tmp, p);
}

function mutate(fn: (data: PnlFileV1) => void): void {
    for (let i = 0; i < 5; i++) {
        try {
            const data = load();
            fn(data);
            save(data);
            return;
        } catch {
            /* retry — concurrent writers or transient FS errors */
        }
    }
}

const nowIso = () => new Date().toISOString();

/** All cycles in `logs/pnl.json` with `redeemStatus === "not_redeemed"`, oldest first. */
export function getNotRedeemedCycleEntries(): PnlCycleEntry[] {
    const data = load();
    return Object.values(data.byConditionId)
        .filter((e) => e.redeemStatus === "not_redeemed")
        .sort((a, b) => {
            const ak = a.cycleEndedAtIso ?? a.cycleStartedAtIso ?? "";
            const bk = b.cycleEndedAtIso ?? b.cycleStartedAtIso ?? "";
            return ak.localeCompare(bk);
        });
}

/**
 * Call when a new cycle starts (we know the new conditionId). This allows redeem even if the bot
 * is stopped mid-cycle before rollover.
 */
export function recordCycleStartedForRedeemTracking(params: {
    conditionId: string;
    slug: string;
    market: string;
}): void {
    const { conditionId, slug, market } = params;
    const t = nowIso();
    try {
        mutate((data) => {
            const prev = data.byConditionId[conditionId];
            if (prev?.redeemStatus === "redeemed") return;
            data.byConditionId[conditionId] = {
                conditionId,
                slug,
                market,
                cycleStartedAtIso: prev?.cycleStartedAtIso ?? t,
                cycleEndedAtIso: prev?.cycleEndedAtIso,
                redeemStatus: prev?.redeemStatus ?? "not_redeemed",
                transactionHash: prev?.transactionHash,
                balanceAfterUsdc: prev?.balanceAfterUsdc,
                redeemSource: prev?.redeemSource,
                nothingToRedeemNote: prev?.nothingToRedeemNote,
                updatedAtIso: t,
            };
        });
    } catch {
        // non-fatal
    }
}

/**
 * Call when the bot rolls into a new 5m slug: previous cycle is pending redeem.
 */
export function recordCycleEndedForRedeemTracking(params: {
    conditionId: string;
    slug: string;
    market: string;
}): void {
    const { conditionId, slug, market } = params;
    const t = nowIso();
    try {
        mutate((data) => {
            const prev = data.byConditionId[conditionId];
            if (prev?.redeemStatus === "redeemed") return;
            data.byConditionId[conditionId] = {
                conditionId,
                slug,
                market,
                cycleStartedAtIso: prev?.cycleStartedAtIso,
                cycleEndedAtIso: t,
                redeemStatus: prev?.redeemStatus ?? "not_redeemed",
                updatedAtIso: t,
            };
        });
    } catch {
        // non-fatal for bot
    }
}

/**
 * After a successful on-chain redeem (CLI auto/manual or batch).
 */
export function markCycleRedeemed(params: {
    conditionId: string;
    transactionHash?: string;
    balanceAfterUsdc?: string;
    source: "auto" | "manual" | "batch" | "pnl_pending";
    slug?: string;
    market?: string;
}): void {
    const t = nowIso();
    const { conditionId, transactionHash, balanceAfterUsdc, source, slug, market } = params;
    try {
        mutate((data) => {
            const prev = data.byConditionId[conditionId];
            const base: PnlCycleEntry = prev ?? {
                conditionId,
                slug: slug ?? "?",
                market: market ?? "?",
                cycleStartedAtIso: t,
                cycleEndedAtIso: undefined,
                redeemStatus: "not_redeemed",
                updatedAtIso: t,
            };
            data.byConditionId[conditionId] = {
                ...base,
                slug: slug ?? base.slug,
                market: market ?? base.market,
                redeemStatus: "redeemed",
                redeemedAtIso: t,
                transactionHash: transactionHash ?? base.transactionHash,
                balanceAfterUsdc: balanceAfterUsdc ?? base.balanceAfterUsdc,
                redeemSource: source,
                updatedAtIso: t,
            };
        });
    } catch {
        // non-fatal
    }
}

/**
 * Redeem worker / flow determined there was nothing to redeem for this condition.
 */
export function markCycleNothingToRedeem(params: {
    conditionId: string;
    slug?: string;
    note?: string;
}): void {
    const t = nowIso();
    const { conditionId, slug, note } = params;
    try {
        mutate((data) => {
            const prev = data.byConditionId[conditionId];
            if (prev?.redeemStatus === "redeemed") return;
            const base: PnlCycleEntry = prev ?? {
                conditionId,
                slug: slug ?? "?",
                market: "?",
                cycleEndedAtIso: t,
                redeemStatus: "not_redeemed",
                updatedAtIso: t,
            };
            data.byConditionId[conditionId] = {
                ...base,
                slug: slug ?? base.slug,
                redeemStatus: "nothing_to_redeem",
                nothingToRedeemNote: note,
                updatedAtIso: t,
            };
        });
    } catch {
        // non-fatal
    }
}

/**
 * Replaces @mgcrae/pino-pretty-logger (no longer available on npm).
 * Default + named `logger`; info/warn/error with variadic args; Separator divider.
 */

const SEPARATOR_LINE =
    '────────────────────────────────────────────────────────────────────────';

function mapArgs(args: unknown[]): unknown[] {
    if (args.length === 1 && args[0] === 'Separator') {
        return [SEPARATOR_LINE];
    }
    return args;
}

export const logger = {
    info(...args: unknown[]) {
        console.log(...mapArgs(args));
    },
    warn(...args: unknown[]) {
        console.warn(...mapArgs(args));
    },
    error(...args: unknown[]) {
        console.error(...mapArgs(args));
    },
};

export default logger;

import { ENV } from "../config/env";

export const TIME_LINES = {
    GOLDERN_TIME: "Golden Time",
    GOOD_TIME: "Good Time",
    MIDDLE_TIME: "Middle Time",
    POOR_TIME: "Poor Time",
} as const;

export type TimeLineKey = keyof typeof TIME_LINES;

function getMinutesSinceMidnightJst(d: Date): number {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Tokyo",
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
    }).formatToParts(d);

    const hh = Number(parts.find((p) => p.type === "hour")?.value ?? NaN);
    const mm = Number(parts.find((p) => p.type === "minute")?.value ?? NaN);
    if (!Number.isFinite(hh) || !Number.isFinite(mm)) return NaN;
    return hh * 60 + mm;
}

function inHourRangeJst(
    minsSinceMidnight: number,
    startHourInclusive: number,
    endHourExclusive: number
): boolean {
    const start = startHourInclusive * 60;
    const end = endHourExclusive * 60;

    // Normal range: [start .. end)
    if (startHourInclusive <= endHourExclusive) {
        return minsSinceMidnight >= start && minsSinceMidnight < end;
    }
    // Wrap-around range crossing midnight: [start .. 1440) U [0 .. end)
    return minsSinceMidnight >= start || minsSinceMidnight < end;
}

/**
 * Returns which time-line (JST) "now" is in.
 *
 * Timeline ranges are configured via env as a JSON array of 4 ranges:
 *
 * `TIME_LINES_JST=[[17,1],[1,7],[14,17],[7,14]]`
 *
 * Meaning (hours in JST):
 * - GOLDERN_TIME: [17..1)  (wraps over midnight)
 * - GOOD_TIME:    [1..7)
 * - MIDDLE_TIME:  [14..17)
 * - POOR_TIME:    [7..14)
 */
export function getCurrentTimeLine(now: Date = new Date()): TimeLineKey {
    const mins = getMinutesSinceMidnightJst(now);
    if (!Number.isFinite(mins)) return "POOR_TIME";

    const ranges = ENV.TIME_LINES_JST;
    const keys: TimeLineKey[] = ["GOLDERN_TIME", "GOOD_TIME", "MIDDLE_TIME", "POOR_TIME"];

    for (let i = 0; i < keys.length; i++) {
        const r = ranges?.[i];
        const startH = r?.[0];
        const endH = r?.[1];
        if (!Number.isFinite(startH) || !Number.isFinite(endH)) continue;
        if (inHourRangeJst(mins, startH, endH)) return keys[i];
    }

    // If env is malformed or doesn't cover the day, default to POOR_TIME (most conservative).
    return "POOR_TIME";
}

export function getCurrentTimeLineLabel(now: Date = new Date()): string {
    return TIME_LINES[getCurrentTimeLine(now)];
}


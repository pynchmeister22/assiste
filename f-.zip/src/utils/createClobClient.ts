import * as fs from "fs";
import * as path from "path";
import { ethers } from "ethers";
import { ClobClient, SignatureTypeV2 } from "@polymarket/clob-client-v2";
import { ENV } from "../config/env";
import logger from "./appLogger";

const PRIVATE_KEY = ENV.PRIVATE_KEY;
const CLOB_HTTP_URL = ENV.CLOB_HTTP_URL;
const RPC_URL = ENV.RPC_URL;

const API_CREDS_FILE = path.resolve(process.cwd(), "api-creds.polymarket-api-creds");

// Check if the address is a Gnosis Safe
const isGnosisSafe = async (address: string): Promise<boolean> => {
    try {
        const provider = new ethers.providers.JsonRpcProvider(RPC_URL);
        const code = await provider.getCode(address);
        return code !== '0x';
    } catch (error) {
        logger.error(`Error checking if ${address} is a Gnosis Safe: ${error}`);
        return false;
    }
}

type StoredApiCreds = { key: string; secret: string; passphrase: string };

function parseDotenvLike(raw: string): Record<string, string> {
    const out: Record<string, string> = {};
    for (const line of raw.split(/\r?\n/)) {
        const t = line.trim();
        if (!t || t.startsWith("#")) continue;
        const eq = t.indexOf("=");
        if (eq <= 0) continue;
        const k = t.slice(0, eq).trim();
        let v = t.slice(eq + 1).trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
            v = v.slice(1, -1);
        }
        if (k) out[k] = v;
    }
    return out;
}

function loadStoredApiCreds(): StoredApiCreds | undefined {
    try {
        if (!fs.existsSync(API_CREDS_FILE)) return undefined;
        const raw = fs.readFileSync(API_CREDS_FILE, "utf8");
        if (!raw.trim()) return undefined;
        const env = parseDotenvLike(raw);
        const key = env.POLYMARKET_USER_API_KEY?.trim();
        const secret = env.POLYMARKET_USER_SECRET?.trim();
        const passphrase = env.POLYMARKET_USER_PASSPHRASE?.trim();
        if (!key || !secret || !passphrase) return undefined;
        return { key, secret, passphrase };
    } catch (e) {
        logger.warn(
            `Error reading stored Polymarket API creds: ${e instanceof Error ? e.message : String(e)}`
        );
        return undefined;
    }
}

function saveStoredApiCreds(creds: StoredApiCreds): void {
    try {
        const dir = path.dirname(API_CREDS_FILE);
        fs.mkdirSync(dir, { recursive: true });
        const contents =
            `POLYMARKET_USER_API_KEY=${creds.key}\n` +
            `POLYMARKET_USER_SECRET=${creds.secret}\n` +
            `POLYMARKET_USER_PASSPHRASE=${creds.passphrase}\n`;
        fs.writeFileSync(API_CREDS_FILE, contents, "utf8");
    } catch (e) {
        logger.warn(
            `Failed to persist Polymarket API creds: ${e instanceof Error ? e.message : String(e)}`
        );
    }
}

const createClobClient = async (): Promise<ClobClient> => {
    const chainId = 137; // Polygon Mainnet
    const host = CLOB_HTTP_URL as string;
    const wallet = new ethers.Wallet(PRIVATE_KEY as string);
    const proxyWallet = await wallet.getAddress();

    const isProxySafe = await isGnosisSafe(proxyWallet);
    const signatureType = isProxySafe ? SignatureTypeV2.POLY_GNOSIS_SAFE : SignatureTypeV2.EOA;

    logger.info(
        `Wallet type detected: ${isProxySafe ? 'Gnosis Safe' : 'EOA (Externally Owned Account)'}`
    );
    logger.info(`Your address - ${proxyWallet}`);

    const stored = loadStoredApiCreds();
    if (stored) {
        return new ClobClient({
            host,
            chain: chainId,
            signer: wallet,
            creds: stored,
            signatureType: signatureType as SignatureTypeV2,
            funderAddress: isProxySafe ? (proxyWallet as string) : undefined,
        });
    }

    let clobClient = new ClobClient({
        host,
        chain: chainId,
        signer: wallet,
        creds: undefined,
        signatureType: signatureType as SignatureTypeV2,
    });

    // Suppress console output during API key creation
    const originalConsoleLog = console.log;
    const originalConsoleError = console.error;
    console.log = function () {};
    console.error = function () {};

    let creds = await clobClient.createApiKey();
    if (!creds.key) {
        creds = await clobClient.deriveApiKey();
    }

    clobClient = new ClobClient({
        host,
        chain: chainId,
        signer: wallet,
        creds: creds,
        signatureType: signatureType as SignatureTypeV2,
        funderAddress: isProxySafe ? (proxyWallet as string) : undefined,
    });

    // Restore console functions
    console.log = originalConsoleLog;
    console.error = originalConsoleError;

    if (creds?.key && creds?.secret && creds?.passphrase) {
        saveStoredApiCreds({ key: creds.key, secret: creds.secret, passphrase: creds.passphrase });
    }

    return clobClient;
};

export default createClobClient;
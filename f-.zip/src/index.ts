import { ENV } from "./config/env";
import createClobClient from "./utils/createClobClient";
import logger from "./utils/appLogger";
import { performHealthCheck, logHealthCheck } from "./utils/healthcheck";
import { approveUSDCAllowance } from "./security/getUSDCAllowance";

import { UpDownPredictionBot } from "./order-builder/updown-bot";
import { ArbitrageBot } from "./order-builder/arbitrage-bot";
import { LowBot } from "./order-builder/low-bot";

export const main = async () => {
    // Identify this process as the main bot (used to suppress noisy logs in child workers).
    process.env.POLYBOT_ROLE = process.env.POLYBOT_ROLE || "bot";
    logger.info("Starting the bot...");

    try {
        // Welcome message for first-time users
        const colors = {
            reset: '\x1b[0m',
            yellow: '\x1b[33m',
            cyan: '\x1b[36m',
        };

        console.log(`\n${colors.yellow}💡 First time running the bot?${colors.reset}`);
        console.log(`   Read the guide: ${colors.cyan}GETTING_STARTED.md${colors.reset}`);
        console.log(`   Run health check: ${colors.cyan}npm run health-check${colors.reset}\n`);

        // Perform initial health check
        logger.info('Performing initial health check...');
        const healthResult = await performHealthCheck();
        logHealthCheck(healthResult);

        if (!healthResult.healthy) {
            logger.warn('Health check failed, but continuing startup...');
        }

        logger.info('Initializing CLOB client...');
        const clobClient = await createClobClient();
        logger.info('CLOB client ready');

        // Approve USDC allowances to Polymarket contracts
        logger.info("Approving USDC allowances to Polymarket contracts...");
        // await approveUSDCAllowance();

        // 4h crypto up/down: wait until the next UTC-aligned 4h window before booting bots.
        // import { msUntilNextCryptoUpDownBoundary } from "./utils/marketSlug";
        // const waitMs = msUntilNextCryptoUpDownBoundary();
        // if (waitMs > 0) {
        //     const targetMs = Date.now() + waitMs;
        //     const fmt = (ms: number) => `${Math.max(0, Math.ceil(ms / 1000))}s`;

        //     logger.info(`⏳ Waiting ${fmt(waitMs)} until next 4h market starts...`);

        //     const countdown = setInterval(() => {
        //         const remainingMs = targetMs - Date.now();
        //         if (remainingMs <= 0) return;
        //         logger.info(`⏳ Next 4h market starts in ${fmt(remainingMs)}`);
        //     }, 15_000);

        //     try {
        //         await new Promise<void>((resolve) => setTimeout(resolve, waitMs));
        //     } finally {
        //         clearInterval(countdown);
        //     }
        // }

        // const bot = await UpDownPredictionBot.fromEnv(clobClient);
        // const arbitrageBot = await ArbitrageBot.fromEnv(clobClient);
        const lowBot = await LowBot.fromEnv(clobClient);

        const shutdown = async (signal: string) => {
            logger.info(`\n🛑 Received ${signal}, generating final summaries...`);
            // bot.stop();
            // arbitrageBot.stop();
            await lowBot.stop();
            await new Promise(resolve => setTimeout(resolve, 1000));
            process.exit(0);
        };

        process.on('SIGTERM', () => shutdown('SIGTERM'));
        process.on('SIGINT', () => shutdown('SIGINT'));

        // await bot.start();
        // await arbitrageBot.start();
        await lowBot.start();
    } catch (error) {
        logger.error(`Fatal error during startup: ${error}`);
        process.exit(1);
    }
}

main();
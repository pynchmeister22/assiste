import { ClobClient, CreateOrderOptions, OrderType, Side, TickSize, UserOrderV2, AssetType } from "@polymarket/clob-client-v2";
import * as fs from "fs";
import * as path from "path";
import { ENV } from "../config/env";
import logger from "../utils/appLogger";
import { spawnRedeemAutoWorker } from "../redeem/spawnRedeemWorker";
import { recordCycleEndedForRedeemTracking } from "../utils/pnlRedeemTracking";
import { slugForCurrentUpDownMarket, slugForNextUpDownMarket, fetchTokenIdsForSlug } from "../utils/marketSlug";

type SimpleStateRow = {
    lastUpdatedIso: string;
    conditionId?: string;
    slug?: string;
    market?: string;
    upIdx?: number;
    downIdx?: number;
    /** Orders being monitored in the CURRENT window (promoted from prev* at rollover). */
    currentUpOrderId?: string;
    currentDownOrderId?: string;
    /** When this market window started (ms since epoch). */
    marketStartedAtMs?: number;
    /** Pre-placed GTC buys for the NEXT window's tokens. */
    prevUpBuyOrderId?: string;
    prevDownBuyOrderId?: string;
};

type SimpleStateFile = Record<string, SimpleStateRow>;

type SimpleConfig = {
    markets: string[];
    tickSize: CreateOrderOptions["tickSize"];
    negRisk: boolean;
    priceBuffer: number;
    fireAndForget: boolean;
    minBalanceUsdc: number;
};

const STATE_FILE = "src/data/bot-state.json";

/** Poll clock + order monitor this often (no orderbook WebSocket). */
const LOW_BOT_TICK_MS = 1_000;

const LOW_BUY_PRICE = ENV.low.buyPrice;
const LOW_SELL_PRICE = ENV.low.sellPrice;
const LOW_BUY_AMOUNT = ENV.low.buyAmount;
/** GTC sell size after a pre-buy fill; capped by matched size. */
const LOW_SELL_AMOUNT = ENV.low.pointAmount;
const KILL_DUAL_BUY_ORDERS_MS = Math.max(0, ENV.low.killDualBuyOrders) * 1_000;

function statePath(): string {
    return path.resolve(process.cwd(), STATE_FILE);
}

function emptyRow(): SimpleStateRow {
    return {
        lastUpdatedIso: new Date().toISOString(),
        currentUpOrderId: undefined,
        currentDownOrderId: undefined,
        marketStartedAtMs: undefined,
        prevUpBuyOrderId: undefined,
        prevDownBuyOrderId: undefined,
    };
}

function loadState(): SimpleStateFile {
    const p = statePath();
    try {
        if (fs.existsSync(p)) {
            const raw = fs.readFileSync(p, "utf8").trim();
            if (!raw) return {};
            const parsed = JSON.parse(raw);

            const normalized: SimpleStateFile = {};
            for (const [k, v] of Object.entries(parsed)) {
                if (typeof v !== "object" || !v) continue;
                const row = v as any;
                normalized[k] = {
                    lastUpdatedIso: String(row.lastUpdatedIso ?? new Date().toISOString()),
                    conditionId: typeof row.conditionId === "string" ? row.conditionId : undefined,
                    slug: typeof row.slug === "string" ? row.slug : undefined,
                    market: typeof row.market === "string" ? row.market : undefined,
                    upIdx: Number.isFinite(Number(row.upIdx)) ? Number(row.upIdx) : undefined,
                    downIdx: Number.isFinite(Number(row.downIdx)) ? Number(row.downIdx) : undefined,
                    currentUpOrderId: typeof row.currentUpOrderId === "string" ? row.currentUpOrderId : undefined,
                    currentDownOrderId: typeof row.currentDownOrderId === "string" ? row.currentDownOrderId : undefined,
                    marketStartedAtMs: Number.isFinite(Number(row.marketStartedAtMs))
                        ? Number(row.marketStartedAtMs)
                        : undefined,
                    prevUpBuyOrderId: typeof row.prevUpBuyOrderId === "string" ? row.prevUpBuyOrderId : undefined,
                    prevDownBuyOrderId: typeof row.prevDownBuyOrderId === "string" ? row.prevDownBuyOrderId : undefined,
                };
            }
            return normalized;
        }
    } catch (e) {
        logger.error(`Failed to read state: ${e instanceof Error ? e.message : String(e)}`);
    }
    return {};
}

let saveStateTimer: NodeJS.Timeout | null = null;
function saveState(state: SimpleStateFile): void {
    if (saveStateTimer) {
        clearTimeout(saveStateTimer);
    }
    saveStateTimer = setTimeout(() => {
        try {
            const p = statePath();
            fs.mkdirSync(path.dirname(p), { recursive: true });
            fs.writeFileSync(p, JSON.stringify(state, null, 2));
        } catch (e) {
            logger.error(`Failed to save state: ${e instanceof Error ? e.message : String(e)}`);
        }
        saveStateTimer = null;
    }, 500);
}

export class LowBot {
    private lastSlugByMarket: Record<string, string> = {};
    private tokenIdsByMarket: Record<
        string,
        { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    > = {};

    private state: SimpleStateFile = loadState();
    private isStopped: boolean = false;

    private tokenCountsByMarket: Map<string, { upTokenCount: number; downTokenCount: number }> = new Map();
    private pausedMarkets: Set<string> = new Set();

    private intervals: NodeJS.Timeout[] = [];
    private reinitLocks: Set<string> = new Set();
    private orderInFlightByMarket: Set<string> = new Set();

    constructor(private client: ClobClient, private cfg: SimpleConfig) {}

    static async fromEnv(client: ClobClient): Promise<LowBot> {
        return new LowBot(client, {
            markets: ["btc"],
            tickSize: "0.01" as CreateOrderOptions["tickSize"],
            negRisk: false,
            priceBuffer: 0.03,
            fireAndForget: false,
            minBalanceUsdc: 1,
        });
    }

    async start(): Promise<void> {
        if (this.isStopped) {
            logger.error("Bot is stopped, cannot start");
            return;
        }

        logger.info(`Starting LowBot for markets: ${this.cfg.markets.join(", ")} (tick ${LOW_BOT_TICK_MS}ms)`);
        await this.initializeMarkets();

        const tick = (): void => {
            void this.runMarketTicks().catch((e) => {
                logger.error(`LowBot tick error: ${e instanceof Error ? e.message : String(e)}`);
            });
        };
        tick();
        const id = setInterval(tick, LOW_BOT_TICK_MS);
        this.intervals.push(id);
    }

    async stop(): Promise<void> {
        this.isStopped = true;

        for (const t of this.intervals) clearInterval(t);
        this.intervals = [];

        logger.info("\n🛑 LowBot stopping...");
        await this.client.cancelAll();
        logger.info("LowBot stopped");
    }

    private async runMarketTicks(): Promise<void> {
        if (this.isStopped) return;
        for (const market of this.cfg.markets) {
            await this.tickMarket(market);
        }
    }

    private async tickMarket(market: string): Promise<void> {
        if (this.isStopped) return;

        const slug = slugForCurrentUpDownMarket(market);

        if (!this.lastSlugByMarket[market]) {
            await this.initializeMarket(market);
            return;
        }

        const prevSlug = this.lastSlugByMarket[market];
        if (prevSlug !== slug) {
            await this.reinitializeMarketForNewCycle(market, prevSlug, slug);
            return;
        }

        let row = this.state[market];
        if (!row) {
            row = emptyRow();
            this.state[market] = row;
        }

        // If we're still within the configured \"kill window\" from market start, cancel current pre-buys.
        if (row.marketStartedAtMs && KILL_DUAL_BUY_ORDERS_MS > 0) {
            const elapsed = Date.now() - row.marketStartedAtMs;
            if (elapsed <= KILL_DUAL_BUY_ORDERS_MS && (row.currentUpOrderId || row.currentDownOrderId)) {
                await this.killDualPrebuyOrders(market, row, market);
            }
        }

        // Monitor current-window orders (promoted from prev* at rollover).
        if (row.currentUpOrderId || row.currentDownOrderId) {
            await this.monitorDualPrebuyOrders(market, slug, row, market);
        }

        // // Place pre-buys for the NEXT window if not yet placed.
        // row = this.state[market] ?? row;
        // if (!row.prevUpBuyOrderId && !row.prevDownBuyOrderId) {
        //     await this.kickstartCycle(market);
        // }

        saveState(this.state);
    }

    private async initializeMarkets(): Promise<void> {
        await Promise.all(this.cfg.markets.map((m) => this.initializeMarket(m)));
    }

    private async initializeMarket(market: string): Promise<void> {
        try {
            const slug = slugForCurrentUpDownMarket(market);
            logger.info(`Initializing market ${market} with slug ${slug}`);
            const tokenIds = await fetchTokenIdsForSlug(slug);
            this.tokenIdsByMarket[market] = { slug, ...tokenIds };
            this.lastSlugByMarket[market] = slug;

            // If this is a cold start, record market start time (best-effort).
            const row = this.state[market] ?? emptyRow();
            if (!row.marketStartedAtMs) {
                row.marketStartedAtMs = Date.now();
            }
            this.state[market] = row;
            saveState(this.state);

            await this.kickstartCycle(market);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            const slug = slugForCurrentUpDownMarket(market);
            logger.error(`⚠️  Market ${market} not available yet (${slug}): ${errorMsg}. Will retry on next tick.`);
        }
    }

    private async kickstartCycle(market: string): Promise<void> {
        if (this.isStopped) return;
        let row = this.state[market];
        if (!row) {
            row = emptyRow();
            this.state[market] = row;
        }
        await this.placeDualBuyOrdersForNextSlug(market, row, market);
    }

    /**
     * New window rollover:
     * - Promote `prevUpBuyOrderId` / `prevDownBuyOrderId` → `currentUpOrderId` / `currentDownOrderId`
     *   (those orders were placed last window for THIS window, now it's time to monitor them).
     * - Clear `prev*` so `kickstartCycle` can place fresh pre-buys for the NEXT window.
     */
    private mergeStateRowForNewCycle(
        market: string,
        newSlug: string,
        newTokenIds: { conditionId: string; upIdx: number; downIdx: number }
    ): SimpleStateRow {
        const prev = this.state[market];
        const now = Date.now();
        const prevMarketStartedAtMs = prev?.marketStartedAtMs;
        return {
            lastUpdatedIso: new Date().toISOString(),
            conditionId: newTokenIds.conditionId,
            slug: newSlug,
            market,
            upIdx: newTokenIds.upIdx,
            downIdx: newTokenIds.downIdx,
            currentUpOrderId: prev?.prevUpBuyOrderId,
            currentDownOrderId: prev?.prevDownBuyOrderId,
            // set market start on rollover; if already set (e.g. retry), keep the older value
            marketStartedAtMs: typeof prevMarketStartedAtMs === "number" && Number.isFinite(prevMarketStartedAtMs)
                ? prevMarketStartedAtMs
                : now,
            prevUpBuyOrderId: undefined,
            prevDownBuyOrderId: undefined,
        };
    }

    private async reinitializeMarketForNewCycle(market: string, prevSlug: string, newSlug: string): Promise<void> {
        if (this.reinitLocks.has(market)) return;
        this.reinitLocks.add(market);
        this.orderInFlightByMarket.delete(market);

        const priorRow = this.state[market];
        const prevConditionId =
            typeof priorRow?.conditionId === "string" && /^0x[a-fA-F0-9]{64}$/.test(priorRow.conditionId.trim())
                ? priorRow.conditionId.trim()
                : undefined;

        logger.info(`🔄 New market cycle [${market}]: ${prevSlug} → ${newSlug}`);

        if (prevConditionId) {
            setImmediate(() => {
                recordCycleEndedForRedeemTracking({ conditionId: prevConditionId, slug: prevSlug, market });
            });
        }

        if (ENV.redeem.autoAfterCycle && prevConditionId) {
            setImmediate(() => {
                try {
                    spawnRedeemAutoWorker(prevConditionId, prevSlug);
                    logger.info(`[redeem] Spawned worker for prior condition (slug=${prevSlug})`);
                } catch (e) {
                    logger.error(`[redeem] Failed to spawn worker: ${e instanceof Error ? e.message : String(e)}`);
                }
            });
        }

        const prevScoreKey = `${market}-${prevSlug}`;
        this.tokenCountsByMarket.delete(prevScoreKey);
        this.pausedMarkets.delete(prevScoreKey);

        try {
            const newTokenIds = await fetchTokenIdsForSlug(newSlug);
            this.tokenIdsByMarket[market] = { slug: newSlug, ...newTokenIds };
            this.lastSlugByMarket[market] = newSlug;

            logger.info(`✅ Market ${market} re-initialized with new token IDs for cycle ${newSlug}`);

            // Promote prev* → current*, clear prev*.
            const row = this.mergeStateRowForNewCycle(market, newSlug, newTokenIds);

            logger.info('-----------------------------');
            logger.info('currentUpOrderId', row.currentUpOrderId);
            logger.info('currentDownOrderId', row.currentDownOrderId);
            logger.info('prevUpBuyOrderId', row.prevUpBuyOrderId);
            logger.info('prevDownBuyOrderId', row.prevDownBuyOrderId);
            this.state[market] = row;

            if (row.currentUpOrderId || row.currentDownOrderId) {
                logger.info(`[low-bot] New cycle ${newSlug}: monitoring promoted orders until one leg fills`);
                await this.monitorDualPrebuyOrders(market, newSlug, row, market);
            }

            logger.info('-----------------------------');
            logger.info('currentUpOrderId', row.currentUpOrderId);
            logger.info('currentDownOrderId', row.currentDownOrderId);
            logger.info('prevUpBuyOrderId', row.prevUpBuyOrderId);
            logger.info('prevDownBuyOrderId', row.prevDownBuyOrderId);

            // Place pre-buys for the NEXT window (prev* already cleared above).
            await this.kickstartCycle(market);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            logger.error(`⚠️  Failed to re-initialize market ${market} with slug ${newSlug}: ${errorMsg}. Will retry on next tick.`);
        } finally {
            this.reinitLocks.delete(market);
        }
    }

    private async placeGTCBuyLimit(
        tokenId: string,
        shares: number,
        tickSize: string,
        negRisk: boolean
    ): Promise<{ ok: boolean; orderID?: string; makingAmount: number; takingAmount: number }> {
        const userOrder: UserOrderV2 = {
            tokenID: tokenId,
            price: LOW_BUY_PRICE,
            size: shares,
            side: Side.BUY,
        };

        const response = await this.client.createAndPostOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk },
            OrderType.GTC
        );

        if (response.success) {
            logger.info(`[low-bot] GTC buy token=${tokenId.slice(0, 8)}… price=${LOW_BUY_PRICE} orderID=${response.orderID}`);
            return { ok: true, orderID: response.orderID, makingAmount: response.makingAmount, takingAmount: response.takingAmount };
        }
        logger.error(`[low-bot] GTC buy failed: ${JSON.stringify(response)}`);
        return { ok: false, orderID: undefined, makingAmount: 0, takingAmount: 0 };
    }

    private async placeGTCSellLimit(
        tokenId: string,
        shares: number,
        tickSize: string,
        negRisk: boolean
    ): Promise<{ ok: boolean; orderID?: string }> {
        await this.client.updateBalanceAllowance();
        const balanceResponse = await this.client.getBalanceAllowance({
            asset_type: AssetType.CONDITIONAL,
            token_id: tokenId,
        });

        const balance = parseFloat(String(balanceResponse.balance ?? "0.000000")) / 1000000;

        const userOrder: UserOrderV2 = {
            tokenID: tokenId,
            price: LOW_SELL_PRICE,
            size: balance,
            side: Side.SELL,
        };

        const response = await this.client.createAndPostOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk },
            OrderType.GTC
        );

        if (response.success) {
            logger.info(`[low-bot] GTC sell token=${tokenId.slice(0, 8)}… price=${LOW_SELL_PRICE} size=${shares} orderID=${response.orderID}`);
            return { ok: true, orderID: response.orderID };
        }
        logger.error(`[low-bot] GTC sell failed: ${JSON.stringify(response)}`);
        return { ok: false, orderID: undefined };
    }

    private parseSizeMatched(raw: string | undefined): number {
        const n = parseFloat(String(raw ?? "0"));
        return Number.isFinite(n) && n > 0 ? n : 0;
    }

    private async killDualPrebuyOrders(
        market: string,
        row: SimpleStateRow,
        stateKey: string
    ): Promise<void> {
        if (this.isStopped) return;
        if (!row.currentUpOrderId && !row.currentDownOrderId) return;
        if (this.orderInFlightByMarket.has(market)) return;

        this.orderInFlightByMarket.add(market);
        try {
            const upId = row.currentUpOrderId;
            const downId = row.currentDownOrderId;
            if (upId) {
                await this.client.cancelOrder({ orderID: upId });
                row.currentUpOrderId = undefined;
                logger.info(`[low-bot] Cancelled unfilled UP leg ${upId}`);
            }
            if (downId) {
                await this.client.cancelOrder({ orderID: downId });
                row.currentDownOrderId = undefined;
                logger.info(`[low-bot] Cancelled unfilled DOWN leg ${downId}`);
            }
            this.state[stateKey] = row;
            saveState(this.state);
        } catch (error) {
            logger.warn(`[low-bot] cancel unfilled leg: ${error instanceof Error ? error.message : String(error)}`);
        } finally {
            this.orderInFlightByMarket.delete(market);
        }
    }

    /**
     * Poll `currentUpOrderId` / `currentDownOrderId` (orders placed in the previous window for
     * THIS current window). When one leg fills, cancel the other and post a GTC sell.
     * Clears `current*` only after sell posts OK (kept for retry on next tick if sell fails).
     */
    private async monitorDualPrebuyOrders(
        market: string,
        slug: string,
        row: SimpleStateRow,
        stateKey: string
    ): Promise<void> {
        if (this.isStopped) return;
        if (!row.currentUpOrderId && !row.currentDownOrderId) return;
        if (this.orderInFlightByMarket.has(market)) return;

        this.orderInFlightByMarket.add(market);
        try {
            let upMatched = 0;
            let downMatched = 0;
            try {
                if (row.currentUpOrderId) {
                    const u = await this.client.getOrder(row.currentUpOrderId);
                    upMatched = this.parseSizeMatched(u.size_matched);
                }
            } catch (e) {
                logger.warn(`[low-bot] getOrder UP: ${e instanceof Error ? e.message : String(e)}`);
            }
            try {
                if (row.currentDownOrderId) {
                    const d = await this.client.getOrder(row.currentDownOrderId);
                    downMatched = this.parseSizeMatched(d.size_matched);
                }
            } catch (e) {
                logger.warn(`[low-bot] getOrder DOWN: ${e instanceof Error ? e.message : String(e)}`);
            }

            if (upMatched <= 0 && downMatched <= 0) {
                return;
            }

            let winner: "UP" | "DOWN";
            if (upMatched > 0 && downMatched <= 0) winner = "UP";
            else if (downMatched > 0 && upMatched <= 0) winner = "DOWN";
            else {
                winner = upMatched >= downMatched ? "UP" : "DOWN";
                logger.warn(`[low-bot] Both legs matched — treating ${winner} as winner`);
            }

            logger.info(`[low-bot] winner`, winner);
            const loserOrderId = winner === "UP" ? row.currentDownOrderId : row.currentUpOrderId;
            if (loserOrderId) {
                try {
                    await this.client.cancelOrder({ orderID: loserOrderId });
                    logger.info(`[low-bot] Cancelled unfilled ${winner === "UP" ? "DOWN" : "UP"} leg ${loserOrderId}`);
                } catch (e) {
                    logger.warn(`[low-bot] cancel unfilled leg: ${e instanceof Error ? e.message : String(e)}`);
                }
            }

            const matchedSize = winner === "UP" ? upMatched : downMatched;
            const sellShares = Math.min(LOW_SELL_AMOUNT, matchedSize);
            if (sellShares <= 0) {
                logger.warn(`[low-bot] Matched size ${matchedSize} too small — clearing monitor state`);
                row.currentUpOrderId = undefined;
                row.currentDownOrderId = undefined;
                this.state[stateKey] = row;
                saveState(this.state);
                return;
            }

            const cached = this.tokenIdsByMarket[market];
            let winnerTokenId: string;
            if (cached?.slug === slug) {
                winnerTokenId = winner === "UP" ? cached.upTokenId : cached.downTokenId;
            } else {
                const t = await fetchTokenIdsForSlug(slug);
                winnerTokenId = winner === "UP" ? t.upTokenId : t.downTokenId;
            }

            const sellRes = await this.placeGTCSellLimit(winnerTokenId, sellShares, this.cfg.tickSize, this.cfg.negRisk);
            if (!sellRes.ok) {
                logger.error(`[low-bot] GTC sell after ${winner} fill failed — keeping current IDs for retry`);
                return;
            }

            row.currentUpOrderId = undefined;
            row.currentDownOrderId = undefined;
            this.state[stateKey] = row;
            saveState(this.state);
            logger.info(`[low-bot] Monitor done [${market}] winner=${winner} sellShares=${sellShares} @ ${LOW_SELL_PRICE}`);
        } finally {
            this.orderInFlightByMarket.delete(market);
        }
    }

    private async placeDualBuyOrdersForNextSlug(
        market: string,
        row: SimpleStateRow,
        stateKey: string,
    ): Promise<void> {
        if (row.prevUpBuyOrderId && row.prevDownBuyOrderId) {
            return;
        }

        const nextSlug = slugForNextUpDownMarket(market);

        let nextTokenIds: {
            upTokenId: string;
            downTokenId: string;
            conditionId: string;
            upIdx: number;
            downIdx: number;
            strikeK: number | null;
        };

        try {
            nextTokenIds = await fetchTokenIdsForSlug(nextSlug);
        } catch (e) {
            logger.warn(`[low-bot] Next market not ready yet [${market}] slug=${nextSlug}: ${e instanceof Error ? e.message : String(e)}`);
            return;
        }

        logger.info(`[low-bot] Placing pre-buy orders for next slug [${market}] slug=${nextSlug}`);

        const upRes = await this.placeGTCBuyLimit(nextTokenIds.upTokenId, LOW_BUY_AMOUNT, this.cfg.tickSize, this.cfg.negRisk);
        const downRes = await this.placeGTCBuyLimit(nextTokenIds.downTokenId, LOW_BUY_AMOUNT, this.cfg.tickSize, this.cfg.negRisk);

        if (upRes.ok && upRes.orderID) {
            row.prevUpBuyOrderId = upRes.orderID;
        }

        if (downRes.ok && downRes.orderID) {
            row.prevDownBuyOrderId = downRes.orderID;
        }

        this.state[stateKey] = row;
        saveState(this.state);
    }
}

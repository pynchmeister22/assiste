import { ClobClient, CreateOrderOptions, OrderType, Side, UserMarketOrderV2, TickSize, AssetType, BalanceAllowanceResponse, UserOrderV2 } from "@polymarket/clob-client-v2";
import * as fs from "fs";
import * as path from "path";
import { WebSocketOrderBook, TokenPrice } from "../providers/websocketOrderbook";
import { ENV } from "../config/env";
import logger from "../utils/appLogger";
import { spawnRedeemAutoWorker } from "../redeem/spawnRedeemWorker";
import { recordCycleEndedForRedeemTracking, recordCycleStartedForRedeemTracking } from "../utils/pnlRedeemTracking";
import { getCurrentTimeLine, getCurrentTimeLineLabel } from "../utils/timeCheck";
import {
    slugForCurrentUpDownMarket,
    fetchTokenIdsForSlug,
    cycleStartUnixFromSlug,
    marketDurationSecondsFromSlug,
} from "../utils/marketSlug";

type SimpleStateRow = {
    lastUpdatedIso: string;
    /** Previous tick asks used to detect price crossings. */
    prevUpAsk?: number | null;
    prevDownAsk?: number | null;
    prevUpBid?: number | null;
    prevDownBid?: number | null;
    // Holdings tracking (for redemption)
    conditionId?: string;
    slug?: string;
    market?: string;
    upIdx?: number;
    downIdx?: number;
    /** Arbitrage trade settings */
    tradeUsd: number;
    depthLimit: number;
    /**
     * How many depth levels are currently open (0 = no position).
     * Each level corresponds to a buy at action points 0.4, 0.3, 0.2 for depths 1, 2, 3.
     */
    currentDepth: number;
    /**
     * Which side the bot laddered into ("UP" or "DOWN").
     * null when currentDepth === 0.
     */
    boughtSide: "UP" | "DOWN" | null;
    /**
     * Shares purchased at each depth level (0-indexed: index 0 = depth 1, etc.).
     * Length equals currentDepth.
     */
    sharesPerDepth: number[];

    /**
     * Bitmasks to prevent double-firing the same action while the order confirmation is pending.
     * - bit 0 => depth 1, bit 1 => depth 2, bit 2 => depth 3
     */
    pendingEntryMask: number;
    pendingOppositeMask: number;

    /**
     * Per-depth progress tracking.
     * - `firstLegMask`: we bought the falling side at that depth action point (0.4/0.3/0.2)
     * - `oppositeLegMask`: we bought the opposite leg for that depth match point (0.5/0.6/0.7)
     * These masks let us "prefill" opposite legs (buy them earlier) and avoid re-buying later.
     */
    firstLegMask: number;
    oppositeLegMask: number;

    /**
     * Total USD spent on buys.
     */
    spentUSD: number;
    /**
     * Number of First shares bought.
     */
    boughtUPShares: number;
    /**
     * Number of Second shares bought.
     */
    boughtDOWNShares: number;


    /**
     * Number of First shares bought triggers.
     */
    boughtFirstSharesTriggers: number;
    /**
     * Number of Second shares bought triggers.
     */
    boughtSecondSharesTriggers: number;

    /** Martingale state (independent of arbitrage ladder). */
    martingaleSide: "UP" | "DOWN" | null;
    /** 0-based step; buy notional = TRADE_USD * 2^step. Stops when step >= MARTINGALE_LIMIT. */
    martingaleStep: number;
    /** Shares currently held for martingale side. */
    martingaleSharesHeld: number;
    /** Prevent duplicate async orders. */
    martingalePendingBuy: boolean;
    /** Prevent duplicate async "buy opposite shares" orders. */
    martingalePendingOppositeBuy: boolean;
    martingalePendingSell: boolean;
};

type SimpleStateFile = Record<string, SimpleStateRow>;

type SimpleConfig = {
    markets: string[]; // e.g. ["btc"] → `btc-updown-4h-{unix}` (legacy hourly / 15m slugs still parsed)
    tickSize: CreateOrderOptions["tickSize"];
    negRisk: boolean;
    priceBuffer: number; // Price buffer in cents for order execution (e.g., 0.03 = 3 cents)
    fireAndForget: boolean; // Don't wait for order confirmation (fire-and-forget)
    // Risk management
    minBalanceUsdc: number; // Minimum balance before stopping
};

const STATE_FILE = "src/data/arbitrage-bot-state.json";

/** No action-point buys when this many seconds or fewer remain (volatile close). */

const TRADE_USD = ENV.arbitrage.tradeUsd;
const DEPTH_LIMIT = ENV.arbitrage.depth;
const ACTION_POINT = ENV.arbitrage.actionPoint;

const FEE_RATE = 0.02;

const MARTINGALE_LIMIT = 2;
const MARTINGALE_ACTION_POINT = 0.6;

/** USDC chunk floor (6dp) so split parts sum without overspending intent. */
function roundUsdDown(usd: number): number {
    return Math.floor(usd * 1000000) / 1000000;
}

function statePath(): string {
    return path.resolve(process.cwd(), STATE_FILE);
}

function emptyRow(): SimpleStateRow {
    return {
        lastUpdatedIso: new Date().toISOString(),
        prevUpAsk: null,
        prevDownAsk: null,
        prevUpBid: null,
        prevDownBid: null,
        tradeUsd: TRADE_USD,
        depthLimit: DEPTH_LIMIT,
        currentDepth: 0,
        boughtSide: null,
        sharesPerDepth: [],
        pendingEntryMask: 0,
        pendingOppositeMask: 0,
        firstLegMask: 0,
        oppositeLegMask: 0,
        spentUSD: 0,
        boughtUPShares: 0,
        boughtDOWNShares: 0,
        boughtFirstSharesTriggers: 0,
        boughtSecondSharesTriggers: 0,
        martingaleSide: null,
        martingaleStep: 0,
        martingaleSharesHeld: 0,
        martingalePendingBuy: false,
        martingalePendingOppositeBuy: false,
        martingalePendingSell: false,
    };
}

function floorPriceToTick(price: number, tickSize: string): number {
    const tick = parseFloat(tickSize);
    if (!Number.isFinite(tick) || tick <= 0) return price;
    return Math.floor(price / tick) * tick;
}

function ceilPriceToTick(price: number, tickSize: string): number {
    const tick = parseFloat(tickSize);
    if (!Number.isFinite(tick) || tick <= 0) return price;
    return Math.ceil(price / tick - 1e-12) * tick;
}

/** Round share size down so USDC spend does not exceed intended notional. */
function roundSizeDown(size: number, decimals = 6): number {
    const f = 10 ** decimals;
    return Math.floor(size * f) / f;
}

/**
 * Polymarket CLOB fixed-6 response amounts. Encoding is the same for both sides; **meaning** depends on order side:
 * - **BUY:** `makingAmount` = **USDC** the maker spent (collateral out).
 * - **SELL:** `makingAmount` = **outcome shares** the maker sold (not USDC).
 * All-digit strings → ÷ 1e6; decimal strings → human fallback.
 */
const MAX_FAK_PARTIAL_MARKET_ROUNDS = 10;

const MIN_ORDER_SHARES = 0.01;
const MIN_ORDER_USDC = 0.01;

const FAK_BUY_RAISE_CAP_EVERY_N_ROUNDS = 5;
const FAK_PARTIAL_MARKET_DELAY_MS = 20;

function loadState(): SimpleStateFile {
    const p = statePath();
    try {
        if (fs.existsSync(p)) {
            const raw = fs.readFileSync(p, "utf8").trim();
            if (!raw) return {};
            const parsed = JSON.parse(raw);

            // Normalize state
            const normalized: SimpleStateFile = {};
            for (const [k, v] of Object.entries(parsed)) {
                if (typeof v !== "object" || !v) continue;
                const row = v as any;
                normalized[k] = {
                    lastUpdatedIso: String(row.lastUpdatedIso ?? new Date().toISOString()),
                    prevUpAsk: row.prevUpAsk == null ? null : (Number.isFinite(Number(row.prevUpAsk)) ? Number(row.prevUpAsk) : null),
                    prevDownAsk: row.prevDownAsk == null ? null : (Number.isFinite(Number(row.prevDownAsk)) ? Number(row.prevDownAsk) : null),
                    prevUpBid: row.prevUpBid == null ? null : (Number.isFinite(Number(row.prevUpBid)) ? Number(row.prevUpBid) : null),
                    prevDownBid: row.prevDownBid == null ? null : (Number.isFinite(Number(row.prevDownBid)) ? Number(row.prevDownBid) : null),
                    conditionId: typeof row.conditionId === "string" ? row.conditionId : undefined,
                    slug: typeof row.slug === "string" ? row.slug : undefined,
                    market: typeof row.market === "string" ? row.market : undefined,
                    upIdx: Number.isFinite(Number(row.upIdx)) ? Number(row.upIdx) : undefined,
                    downIdx: Number.isFinite(Number(row.downIdx)) ? Number(row.downIdx) : undefined,
                    tradeUsd: typeof row.tradeUsd === "number" ? row.tradeUsd : TRADE_USD,
                    depthLimit: typeof row.depthLimit === "number" ? row.depthLimit : DEPTH_LIMIT,
                    currentDepth: typeof row.currentDepth === "number" ? row.currentDepth : 0,
                    boughtSide: row.boughtSide === "UP" || row.boughtSide === "DOWN" ? row.boughtSide : null,
                    pendingEntryMask: Number.isFinite(Number(row.pendingEntryMask)) ? Number(row.pendingEntryMask) : 0,
                    pendingOppositeMask: Number.isFinite(Number(row.pendingOppositeMask))
                        ? Number(row.pendingOppositeMask)
                        : Number.isFinite(Number(row.pendingExitMask))
                        ? Number(row.pendingExitMask) // migrate old field name
                        : 0,
                    firstLegMask: Number.isFinite(Number(row.firstLegMask)) ? Number(row.firstLegMask) : 0,
                    oppositeLegMask: Number.isFinite(Number(row.oppositeLegMask)) ? Number(row.oppositeLegMask) : 0,
                    spentUSD: typeof row.spentUSD === "number" ? row.spentUSD : 0,
                    boughtUPShares: typeof row.boughtUPShares === "number" ? row.boughtUPShares : 0,
                    boughtDOWNShares: typeof row.boughtDOWNShares === "number" ? row.boughtDOWNShares : 0,
                    boughtFirstSharesTriggers: typeof row.boughtFirstSharesTriggers === "number" ? row.boughtFirstSharesTriggers : 0,
                    boughtSecondSharesTriggers: typeof row.boughtSecondSharesTriggers === "number" ? row.boughtSecondSharesTriggers : 0,
                    martingaleSide:
                        row.martingaleSide === "UP" || row.martingaleSide === "DOWN" ? row.martingaleSide : null,
                    martingaleStep: Number.isFinite(Number(row.martingaleStep)) ? Number(row.martingaleStep) : 0,
                    martingaleSharesHeld: Number.isFinite(Number(row.martingaleSharesHeld)) ? Number(row.martingaleSharesHeld) : 0,
                    martingalePendingBuy: typeof row.martingalePendingBuy === "boolean" ? row.martingalePendingBuy : false,
                    martingalePendingOppositeBuy:
                        typeof row.martingalePendingOppositeBuy === "boolean" ? row.martingalePendingOppositeBuy : false,
                    martingalePendingSell: typeof row.martingalePendingSell === "boolean" ? row.martingalePendingSell : false,
                    sharesPerDepth: Array.isArray(row.sharesPerDepth)
                        ? row.sharesPerDepth.map((x: unknown) => (Number.isFinite(Number(x)) ? Number(x) : 0))
                        : Array.isArray(row.downSharesBought) // migrate old field name
                        ? row.downSharesBought.map((x: unknown) => (Number.isFinite(Number(x)) ? Number(x) : 0))
                        : [],
                };
            }
            return normalized;
        }
    } catch (e) {
        logger.error(`Failed to read state: ${e instanceof Error ? e.message : String(e)}`);
    }
    return {};
}

// Debounced state save
let saveStateTimer: NodeJS.Timeout | null = null;
function saveState(state: SimpleStateFile): void {
    if (saveStateTimer) {
        clearTimeout(saveStateTimer);
    }
    saveStateTimer = setTimeout(() => {
        try {
            const p = statePath();
            fs.mkdirSync(path.dirname(p), { recursive: true });
            fs.writeFileSync(p, JSON.stringify(state, null, 2));
        } catch (e) {
            logger.error(`Failed to save state: ${e instanceof Error ? e.message : String(e)}`);
        }
        saveStateTimer = null;
    }, 500); // Debounce saves by 500ms
}

export class ArbitrageBot {
    private lastSlugByMarket: Record<string, string> = {};
    private tokenIdsByMarket: Record<
        string,
        { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    > = {};

    private state: SimpleStateFile = loadState();
    private isStopped: boolean = false;
    private wsOrderBook: WebSocketOrderBook | null = null;
    private useWebSocket: boolean = true; // Toggle to use WebSocket or API

    // Limit order second side strategy tracking
    private tokenCountsByMarket: Map<string, { upTokenCount: number; downTokenCount: number }> = new Map(); // Track token counts per market
    private pausedMarkets: Set<string> = new Set(); // Track paused markets (reached max tokens per side)

    private initializationPromise: Promise<void> | null = null;
    /** Unix-ms timestamp of the last `cancelAll()` call – prevents duplicate calls when
     *  multiple markets roll over near-simultaneously. */
    private lastCancelAllMs = 0;
    /** Interval handles stored so they can be cleared on stop(). */
    private intervals: NodeJS.Timeout[] = [];
    /** Per-market lock to prevent concurrent reinitializeMarketForNewCycle calls. */
    private reinitLocks: Set<string> = new Set();

    constructor(private client: ClobClient, private cfg: SimpleConfig) {
        // Initialize WebSocket orderbook (store promise for later awaiting)
        this.initializationPromise = this.initializeWebSocket();
    }

    static async fromEnv(client: ClobClient): Promise<ArbitrageBot> {
        const bot = new ArbitrageBot(client, {
            markets: ["btc"], tickSize: "0.01" as CreateOrderOptions["tickSize"],
            negRisk: false, priceBuffer: 0.03, fireAndForget: false, minBalanceUsdc: 1,
        });
        await bot.initializationPromise; // Await Polymarket WebSocket initialization

        return bot;
    }

    async initializeWebSocket(): Promise<void> {
        if (!this.useWebSocket) {
            logger.error("WebSocket disabled in config");
            return;
        }
        try {
            this.wsOrderBook = new WebSocketOrderBook("market", [], null);
            await this.wsOrderBook.connect();
            logger.info("WebSocket orderbook initialized");
        } catch (e) {
            logger.error(`Failed to initialize WebSocket: ${e instanceof Error ? e.message : String(e)}`);
            throw e;
        }
    }

    async start(): Promise<void> {
        if (this.isStopped) {
            logger.error("Bot is stopped, cannot start");
            return;
        }

        if (!this.wsOrderBook) {
            logger.error("Fatal error: WebSocket orderbook not initialized - cannot start bot");
            return;
        }

        logger.info(`Starting Arbitrage Bot for markets: ${this.cfg.markets.join(", ")}`);
        await this.initializeMarkets();
    }

    stop(): void {
        this.isStopped = true;

        // Clear all periodic timers
        for (const t of this.intervals) clearInterval(t);
        this.intervals = [];

        // Generate final summaries unconditionally (no time-gate at shutdown)
        logger.info("\n🛑 Generating final prediction summaries...");
        // this.flushPredictionSummaries(true);

        if (this.wsOrderBook) {
            this.wsOrderBook.disconnect();
        }
        logger.info("Arbitrage Bot stopped");
    }

    private async initializeMarkets(): Promise<void> {
        await Promise.all(this.cfg.markets.map((m) => this.initializeMarket(m)));
    }

    private async initializeMarket(market: string): Promise<void> {
        try {
            const slug = slugForCurrentUpDownMarket(market);
            logger.info(`Initializing market ${market} with slug ${slug}`);
            const tokenIds = await fetchTokenIdsForSlug(slug);
            this.tokenIdsByMarket[market] = { slug, ...tokenIds };
            this.lastSlugByMarket[market] = slug;

            // Subscribe to WebSocket prices for these tokens
            if (this.wsOrderBook) {
                this.wsOrderBook.subscribeToTokenIds([tokenIds.upTokenId, tokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(tokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(tokenIds.downTokenId, "Down");

                // Set up price update callbacks - trigger trading logic on price updates
                this.wsOrderBook.onPriceUpdate(tokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(tokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "NO");
                });
            }

            // Kickstart one tick immediately so Action Point #1 fires as close to cycle start as possible,
            // instead of waiting for the first WS update to arrive.
            this.kickstartCycleTick(market, slug, tokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            const slug = slugForCurrentUpDownMarket(market);
            logger.error(`⚠️  Market ${market} not available yet (${slug}): ${errorMsg}. Will retry on next price update.`);
            // Don't throw - allow the bot to continue and retry later
        }
    }

    /** Try to run one executeTrade tick ASAP using the latest cached WS prices. */
    private kickstartCycleTick(
        market: string,
        slug: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    ): void {
        if (!this.wsOrderBook) return;
        if (this.isStopped) return;

        // Fire-and-forget, short polling window (WS often lags a couple seconds at boundary).
        void (async () => {
            const maxAttempts = 40; // ~2s at 50ms
            const delayMs = 50;
            for (let i = 0; i < maxAttempts; i++) {
                if (this.isStopped) return;
                const up = this.wsOrderBook?.getPrice(tokenIds.upTokenId);
                const down = this.wsOrderBook?.getPrice(tokenIds.downTokenId);
                const upAsk = up?.bestAsk;
                const downAsk = down?.bestAsk;
                if (
                    upAsk != null &&
                    downAsk != null &&
                    Number.isFinite(upAsk) &&
                    Number.isFinite(downAsk)
                ) {
                    const upBid = up?.bestBid != null && Number.isFinite(up.bestBid) ? up.bestBid : null;
                    const downBid = down?.bestBid != null && Number.isFinite(down.bestBid) ? down.bestBid : null;
                    const timeRemaining = this.getTimeRemainingForSlug(slug);
                    await this.executeTrade(
                        market,
                        slug,
                        upAsk,
                        downAsk,
                        upBid,
                        downBid,
                        up?.tickSize || this.cfg.tickSize,
                        down?.tickSize || this.cfg.tickSize,
                        {
                            upTokenId: tokenIds.upTokenId,
                            downTokenId: tokenIds.downTokenId,
                            conditionId: tokenIds.conditionId,
                            upIdx: tokenIds.upIdx,
                            downIdx: tokenIds.downIdx,
                        },
                        timeRemaining
                    );
                    return;
                }
                await new Promise((r) => setTimeout(r, delayMs));
            }
        })().catch((e) => {
            logger.error(
                `kickstartCycleTick error [${market}] slug=${slug}: ${e instanceof Error ? e.message : String(e)}`
            );
        });
    }

    private async handlePriceUpdate(
        market: string,
        tokenIds: { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        price: TokenPrice,
        _leg: "YES" | "NO"
    ): Promise<void> {
        if (this.isStopped) return;
        if (!price.bestAsk || !Number.isFinite(price.bestAsk)) return; // Use bestAsk

        // Defer heavy processing to prevent blocking WebSocket message loop
        queueMicrotask(() => {
            void (async () => {
                // Get slug for current 4h UTC window (or legacy cached slug)
                const slug = this.getSlugForMarket(market);
                if (!slug) {
                    // Market not initialized yet - initialize it
                    void this.initializeMarket(market);
                    return;
                }

                // Check if we have cached tokenIds for this market, and if slug matches
                let currentTokenIds = tokenIds;
                const cachedTokenIds = this.tokenIdsByMarket[market];
                if (cachedTokenIds && cachedTokenIds.slug === slug) {
                    // Use cached tokenIds if slug matches
                    currentTokenIds = cachedTokenIds;
                }
                // If slug doesn't match, we'll handle re-initialization in the market cycle check below

                // Get both prices (we need UP ask price for comparison) - fast cache lookup
                const upPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                const downPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                // Use bestAsk price for limit orders (required for order placement)
                if (!upPrice?.bestAsk || !downPrice?.bestAsk ||
                    !Number.isFinite(upPrice.bestAsk) || !Number.isFinite(downPrice.bestAsk)) {
                    return; // Wait for both ask prices
                }

                let upAsk: number = upPrice.bestAsk;
                let downAsk: number = downPrice.bestAsk;
                let upBid: number | null =
                    upPrice.bestBid != null && Number.isFinite(upPrice.bestBid) ? upPrice.bestBid : null;
                let downBid: number | null =
                    downPrice.bestBid != null && Number.isFinite(downPrice.bestBid) ? downPrice.bestBid : null;

                // Check for market cycle change (new hour / slug)
                // Initialize lastSlugByMarket if not set (first time)
                if (!this.lastSlugByMarket[market]) {
                    this.lastSlugByMarket[market] = slug;
                }

                const prevSlug = this.lastSlugByMarket[market];
                if (prevSlug && prevSlug !== slug) {
                    // Do not log here: UP+DOWN WS ticks (and burst updates) all hit this branch
                    // before reinit finishes — logging only inside reinitializeMarketForNewCycle after lock.
                    await this.reinitializeMarketForNewCycle(market, prevSlug, slug);

                    // Refresh tokenIds after re-init
                    const refreshed = this.tokenIdsByMarket[market];
                    if (!refreshed || refreshed.slug !== slug) return;
                    currentTokenIds = refreshed;

                    const newUpPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                    const newDownPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                    if (!newUpPrice?.bestAsk || !newDownPrice?.bestAsk ||
                        !Number.isFinite(newUpPrice.bestAsk) || !Number.isFinite(newDownPrice.bestAsk)) {
                        return;
                    }
                    upAsk = newUpPrice.bestAsk;
                    downAsk = newDownPrice.bestAsk;
                    upBid =
                        newUpPrice.bestBid != null && Number.isFinite(newUpPrice.bestBid)
                            ? newUpPrice.bestBid
                            : null;
                    downBid =
                        newDownPrice.bestBid != null && Number.isFinite(newDownPrice.bestBid)
                            ? newDownPrice.bestBid
                            : null;
                }

                const timeRemaining = this.getTimeRemainingForSlug(slug);

                await this.executeTrade(
                    market,
                    slug,
                    upAsk,
                    downAsk,
                    upBid,
                    downBid,
                    upPrice.tickSize || this.cfg.tickSize,
                    downPrice.tickSize || this.cfg.tickSize,
                    currentTokenIds,
                    timeRemaining
                );

                saveState(this.state);
            })().catch((e) => {
                logger.error(`handlePriceUpdate error [${market}]: ${e instanceof Error ? e.message : String(e)}`);
            });
        });
    }

    private getSlugForMarket(market: string): string {
        return slugForCurrentUpDownMarket(market);
    }

    private async reinitializeMarketForNewCycle(market: string, prevSlug: string, newSlug: string): Promise<void> {
        if (this.reinitLocks.has(market)) return;
        this.reinitLocks.add(market);

        const priorRow = this.state[market];
        const prevConditionId =
            typeof priorRow?.conditionId === "string" && /^0x[a-fA-F0-9]{64}$/.test(priorRow.conditionId.trim())
                ? priorRow.conditionId.trim()
                : undefined;

        logger.info(`🔄 New market cycle [${market}]: ${prevSlug} → ${newSlug}`);

        // Track prior cycle in logs/pnl.json as not_redeemed (updated to redeemed when redeem succeeds).
        if (prevConditionId) {
            setImmediate(() => {
                recordCycleEndedForRedeemTracking({
                    conditionId: prevConditionId,
                    slug: prevSlug,
                    market,
                });
            });
        }

        // Redeem previous market in a separate Node process (no await) — does not block trading or WS handling.
        if (ENV.redeem.autoAfterCycle && prevConditionId) {
            setImmediate(() => {
                try {
                    spawnRedeemAutoWorker(prevConditionId, prevSlug);
                    logger.info(`[redeem] Spawned worker for prior condition (slug=${prevSlug})`);
                } catch (e) {
                    logger.error(
                        `[redeem] Failed to spawn worker: ${e instanceof Error ? e.message : String(e)}`
                    );
                }
            });
        }

        // Cancel all open GTC orders (resting second-leg limits from the previous cycle) once per
        // rollover event, even when multiple markets tick simultaneously.
        const now = Date.now();
        if (now - this.lastCancelAllMs > 60_000) {
            this.lastCancelAllMs = now;
            try {
                await this.client.cancelAll();
                logger.info(`🗑️  Cancelled all open GTC orders at cycle boundary`);
            } catch (e) {
                logger.error(`cancelAll failed at cycle boundary: ${e instanceof Error ? e.message : String(e)}`);
            }
        }

        // Reset token counts and paused state for previous market
        const prevScoreKey = `${market}-${prevSlug}`;
        this.tokenCountsByMarket.delete(prevScoreKey);
        this.pausedMarkets.delete(prevScoreKey);

        try {
            const newTokenIds = await fetchTokenIdsForSlug(newSlug);
            this.tokenIdsByMarket[market] = { slug: newSlug, ...newTokenIds };

            // Update WebSocket subscriptions for new tokens
            if (this.wsOrderBook) {
                // Subscribe to new tokens
                this.wsOrderBook.subscribeToTokenIds([newTokenIds.upTokenId, newTokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(newTokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(newTokenIds.downTokenId, "Down");

                // Update callbacks with new token IDs
                this.wsOrderBook.onPriceUpdate(newTokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(newTokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "NO");
                });         
            }

            this.lastSlugByMarket[market] = newSlug;

            logger.info(`✅ Market ${market} re-initialized with new token IDs for cycle ${newSlug}`);

            // Kickstart one tick immediately to reduce delay on Action Point #1 at boundary.
            this.kickstartCycleTick(market, newSlug, newTokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            logger.error(`⚠️  Failed to re-initialize market ${market} with new slug ${newSlug}: ${errorMsg}. Will retry on next check.`);
        } finally {
            this.reinitLocks.delete(market);
        }
    }

    private async buySharesWithFAK(
        leg: "YES" | "NO",
        tokenID: string,
        usdAmount: number,
        priceCap: number,
        tickSize: string,
    ): Promise<{ ok: boolean; makingAmount: number; takingAmount: number }> {
        let remainingUsd = usdAmount;
        if (remainingUsd < MIN_ORDER_USDC) {
            logger.error(`BUY skipped ${leg}: USDC amount ${remainingUsd} below minimum`);
            return { ok: false, makingAmount: 0.000000, takingAmount: 0.000000 };
        }

        let buyPriceCap = priceCap;
        const tickN = parseFloat(tickSize);
        const canStepBuyCap = Number.isFinite(tickN) && tickN > 0;
        let takingAmount = 0.000000;

        try {
            for (let partialRound = 1; partialRound <= MAX_FAK_PARTIAL_MARKET_ROUNDS; partialRound++) {
                if (remainingUsd < MIN_ORDER_USDC) break;

                const amount = remainingUsd;
                const userMarketOrder: UserMarketOrderV2 = {
                    tokenID,
                    side: Side.BUY,
                    amount,
                    orderType: OrderType.FAK,
                    price: buyPriceCap,
                };

                logger.info(
                    [
                        `BUY: ${leg} market FAK ~$${amount.toFixed(2)} USDC @ max price ${buyPriceCap.toFixed(4)}`,
                        partialRound >= 1 ? `(partial round ${partialRound})` : "",
                    ]
                        .filter(Boolean)
                        .join(" ")
                );

                const response = await this.client.createAndPostMarketOrder(
                    userMarketOrder,
                    { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
                    OrderType.FAK,
                    false
                );

                logger.info('-------------------------------------------------------');
                logger.info(`🟦 BUY ${leg} response: ${JSON.stringify(response)}`);

                const filledRaw = parseFloat(String(response.makingAmount ?? "0.000000"));
                const filledUsd = Math.min(amount, filledRaw);
                remainingUsd = remainingUsd - filledUsd;
                takingAmount += parseFloat(String(response.takingAmount ?? "0.000000"));

                logger.warn(
                    [
                        `BUY ${leg} round ${partialRound}/${MAX_FAK_PARTIAL_MARKET_ROUNDS} partial FAK post succeeded`,
                        `spentThisRound≈$${filledUsd.toFixed(4)} (order $${amount.toFixed(2)}) remaining≈$${remainingUsd.toFixed(2)}`,
                    ].join(" | ")
                )

                if (remainingUsd < MIN_ORDER_USDC) {
                    return { ok: true, makingAmount: usdAmount - remainingUsd, takingAmount: takingAmount };
                }

                await new Promise((r) => setTimeout(r, FAK_PARTIAL_MARKET_DELAY_MS));
            }
            if (remainingUsd < MIN_ORDER_USDC) return { ok: true, makingAmount: usdAmount, takingAmount: takingAmount };
            logger.error(
                `BUY ${leg}: exceeded ${MAX_FAK_PARTIAL_MARKET_ROUNDS} FAK partial rounds; ~$${remainingUsd.toFixed(2)} USDC still intended`
            );
            return { ok: false, makingAmount: usdAmount, takingAmount: takingAmount };
        } catch (e) {
            logger.error(`BUY failed for ${leg}: ${e instanceof Error ? e.message : String(e)}`);
            return { ok: false, makingAmount: usdAmount, takingAmount: takingAmount };
        }
    }

    private async buySharesWithGTC(
        leg: "YES" | "NO",
        tokenID: string,
        shares: number,
        tickSize: string        
    ): Promise<{ ok: boolean; makingAmount: number; takingAmount: number }> {
        const userOrder: UserOrderV2 = {
            tokenID,
            price: 0.99,
            size: shares,
            side: Side.BUY
        }

        const response = await this.client.createAndPostOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
            OrderType.GTC
        )

        logger.info('-------------------------------------------------------');
        logger.info(`🟦 BUY ${leg} response: ${JSON.stringify(response)}`);

        const success = response?.success;
        const orderId = response?.orderID;

        if (!success && !orderId) {
            logger.error(`🟠 BUY ${leg} failed: ${JSON.stringify(response)}`);
            return { ok: false, makingAmount: 0.000000, takingAmount: 0.000000 };
        }

        const filledRaw = parseFloat(String(response.takingAmount ?? "0.000000"));
        const spentUSDC = parseFloat(String(response.makingAmount ?? "0.000000"));

        logger.info(`🟢 BUY ${leg} success: ${success} orderId: ${orderId} bought shares: ${filledRaw.toFixed(4)} spent USDC: ${spentUSDC.toFixed(4)}`);

        return { ok: true, makingAmount: spentUSDC, takingAmount: filledRaw };
    }

    private async executeTrade(
        market: string,
        slug: string,
        upAsk: number,
        downAsk: number,
        upBid: number | null,
        downBid: number | null,
        upTickSize: string,
        downTickSize: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        _timeRemainingSeconds: number,
    ): Promise<void> {
        const stateKey = market;
        try {
            const row: SimpleStateRow = this.state[stateKey] ?? emptyRow();
            const entryBit = (depth: number) => 1 << Math.max(0, depth - 1);

            const commitPrevPrices = () => {
                row.prevUpAsk = Number.isFinite(upAsk) ? upAsk : row.prevUpAsk ?? null;
                row.prevDownAsk = Number.isFinite(downAsk) ? downAsk : row.prevDownAsk ?? null;
                row.prevUpBid = upBid != null && Number.isFinite(upBid) ? upBid : row.prevUpBid ?? null;
                row.prevDownBid = downBid != null && Number.isFinite(downBid) ? downBid : row.prevDownBid ?? null;
            };

            const persist = () => {
                row.lastUpdatedIso = new Date().toISOString();
                this.state[stateKey] = row;
                saveState(this.state);
            };

            // Reset per-cycle state when slug changes (new market window)
            if (row.slug !== slug) {
                row.slug = slug;
                row.market = market;
                row.conditionId = tokenIds.conditionId;
                row.upIdx = tokenIds.upIdx;
                row.downIdx = tokenIds.downIdx;
                row.prevUpAsk = null;
                row.prevDownAsk = null;
                row.prevUpBid = null;
                row.prevDownBid = null;
                row.tradeUsd = TRADE_USD;
                row.depthLimit = DEPTH_LIMIT;
                row.currentDepth = 0;
                row.boughtSide = null;
                row.sharesPerDepth = [];
                row.pendingEntryMask = 0;
                row.pendingOppositeMask = 0;
                row.firstLegMask = 0;
                row.oppositeLegMask = 0;
                row.spentUSD = 0;
                row.boughtUPShares = 0;
                row.boughtDOWNShares = 0;
                row.boughtFirstSharesTriggers = 0;
                row.boughtSecondSharesTriggers = 0;
                row.martingaleSide = null;
                row.martingaleStep = 0;
                row.martingaleSharesHeld = 0;
                row.martingalePendingBuy = false;
                row.martingalePendingOppositeBuy = false;
                row.martingalePendingSell = false;

                logger.info(`🆕 New cycle state reset [${market}] slug=${slug}`);
                const cid = row.conditionId;
                if (typeof cid === "string" && /^0x[a-fA-F0-9]{64}$/.test(cid)) {
                    setImmediate(() => {
                        recordCycleStartedForRedeemTracking({ conditionId: cid, slug, market });
                    });
                }
            }

            /**
             * Action point formulas — derived from depth, never stored as arrays.
             *
             * nextBuyPoint(currentDepth): the price at which to buy the falling side again.
             *   depth=0 → 0.4, depth=1 → 0.3, depth=2 → 0.2
             *
             * oppositePointForDepth(depth): opposite-side points.
             *   depth=1 → 0.5, depth=2 → 0.6, depth=3 → 0.7
             */
            const nextBuyPoint = (depth: number): number => ACTION_POINT - 0.1 * depth;
            // Opposite points for the depth action points:
            // 0.4→0.5 (depth 1), 0.3→0.6 (depth 2), 0.2→0.7 (depth 3)
            const oppositePointForDepth = (depth: number): number => ACTION_POINT + 0.1 * depth;
            const plannedSharesForDepth = (depth: number): number => TRADE_USD / Math.max(nextBuyPoint(depth - 1), 1e-9);

            const usdForActionPoint = (pointNumber: number): number => {
                if (!Number.isFinite(pointNumber) || pointNumber <= 0) return 0;
                // 1,2,4,8,16,32 then +8 each time: 40,48,56,...
                if (pointNumber <= 5) return Math.pow(2, pointNumber - 1);
                return 24 + 8 * (pointNumber - 5);
            };

            /** Martingale only: require a real two-sample cross (never infer from missing `prev`). */
            const crossedBelowStrict = (prev: number | null | undefined, now: number | null, threshold: number): boolean =>
                Number.isFinite(now) &&
                prev != null &&
                Number.isFinite(prev) &&
                prev > threshold &&
                now != null &&
                Number.isFinite(now) &&
                now <= threshold;

            const crossedAboveStrict = (prev: number | null | undefined, now: number, threshold: number): boolean =>
                Number.isFinite(now) &&
                prev != null &&
                Number.isFinite(prev) &&
                prev < threshold &&
                now >= threshold;

            const depthLimit = row.depthLimit;

            // ── MARTINGALE (independent) ───────────────────────────────────────────────
            // Buy $1 of the rising side when it rises through 0.6.
            // If it later drops through 0.5, arm a sell; when it rises back through 0.6, sell all martingale shares.
            // Repeat with doubled USD each buy until MARTINGALE_LIMIT steps are reached.
            
            {
                // Prevent double-firing while the async buy is still pending.
                if (!row.martingalePendingBuy && row.martingaleSharesHeld < MIN_ORDER_SHARES && row.martingaleStep < MARTINGALE_LIMIT) {
                    const prevUpAsk = row.prevUpAsk;
                    const prevDownAsk = row.prevDownAsk;
                    const nowUpAsk = upAsk;
                    const nowDownAsk = downAsk;

                    const upRisingHit = crossedAboveStrict(prevUpAsk, nowUpAsk, 0.6);
                    const downRisingHit = crossedAboveStrict(prevDownAsk, nowDownAsk, 0.6);
                    const triggerAsk = upRisingHit ? upAsk : downRisingHit ? downAsk : undefined;
                    if (Number.isFinite(triggerAsk) && triggerAsk !== null) {
                        const side: "UP" | "DOWN" = upRisingHit ? "UP" : "DOWN";

                        const pointNumber = row.martingaleStep + 1;
                        const usd = usdForActionPoint(pointNumber);

                        logger.info(`[Martingale] BUY step=${pointNumber}/${MARTINGALE_LIMIT} ${side} crossed ${0.6.toFixed(2)} → buying ~$${usd.toFixed(2)}`);
                        const leg = side === "UP" ? "YES" : "NO";
                        const tokenId = side === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                        const tickSize = side === "UP" ? upTickSize : downTickSize;

                        row.martingalePendingBuy = true;
                        persist();
                        void this.buySharesWithFAK(leg, tokenId, usd, 0.99, tickSize)
                            .then((result) => {
                                const r = this.state[stateKey];
                                if (!r || r.slug !== slug) return;
                                r.martingalePendingBuy = false;
                                if (result.ok && result.takingAmount > 0) {
                                    r.spentUSD += result.makingAmount;
                                    r.boughtDOWNShares += (leg === "NO" ? result.takingAmount : 0);
                                    r.boughtUPShares += (leg === "YES" ? result.takingAmount : 0);
                                    r.martingaleStep = pointNumber;
                                    r.martingaleSharesHeld = result.takingAmount;
                                    r.martingaleSide = side;
                                    const expectedProfit = upAsk > downAsk ? r.boughtUPShares - r.spentUSD : r.boughtDOWNShares - r.spentUSD;
                                    logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                                    logger.info(`[Martingale] ✅ BUY step=${pointNumber}/${MARTINGALE_LIMIT} ${side} crossed ${0.6.toFixed(2)} → bought ${result.takingAmount.toFixed(4)} shares`);
                                    logger.info(`[Status] Spent USD: ${r.spentUSD.toFixed(4)} UP shares bought: ${r.boughtUPShares.toFixed(4)} DOWN shares bought: ${r.boughtDOWNShares.toFixed(4)}`);
                                    logger.info(`[Status] Low shares bought triggers: ${r.boughtFirstSharesTriggers.toFixed(4)} High shares bought triggers: ${r.boughtSecondSharesTriggers.toFixed(4)}`);
                                    logger.info(`[Expected] Expected profit: ${expectedProfit.toFixed(4)}`);
                                    logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                                    saveState(this.state);
                                } else {
                                    logger.error(`[Martingale] ❌ BUY step=${pointNumber}/${MARTINGALE_LIMIT} ${side} crossed ${0.6.toFixed(2)} failed`);
                                    saveState(this.state);
                                }
                            })
                            .catch((e) => {
                                logger.error(`[Martingale] ❌ BUY step=${pointNumber}/${MARTINGALE_LIMIT} ${side} crossed ${0.6.toFixed(2)} error: ${e instanceof Error ? e.message : String(e)}`);
                                const r = this.state[stateKey];
                                if (r && r.slug === slug) {
                                    r.martingalePendingBuy = false;
                                }
                                saveState(this.state);
                            })
                    }
                }

                if (row.martingaleSharesHeld > 0) {
                    const martingaleSide = row.martingaleSide;
                    const askPx = martingaleSide === "UP" ? upAsk : downAsk;
                    const prevAskPx = martingaleSide === "UP" ? (row.prevUpAsk ?? null) : (row.prevDownAsk ?? null);
                    
                    if (!row.martingalePendingOppositeBuy && crossedBelowStrict(prevAskPx, askPx, 0.5)) {
                        logger.info(`[Martingale] BUY Opposite shares ${martingaleSide}: crossed back below ${0.5.toFixed(2)} → buying opposite shares ${row.martingaleSharesHeld.toFixed(4)} shares @ ${0.5.toFixed(2)}`);
                        const leg = martingaleSide === "UP" ? "NO" : "YES";
                        const tokenId = martingaleSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                        const tickSize = martingaleSide === "UP" ? upTickSize : downTickSize;
                        row.martingalePendingOppositeBuy = true;
                        persist();
                        void this.buySharesWithGTC(leg, tokenId, row.martingaleSharesHeld, tickSize)
                            .then((result) => {
                                const r = this.state[stateKey];
                                if (!r || r.slug !== slug) return;
                                r.martingalePendingOppositeBuy = false;
                                if (result.ok && result.takingAmount > 0) {
                                    r.martingaleSharesHeld = 0.0000;
                                    r.martingaleSide = null;
                                    r.spentUSD += result.makingAmount;
                                    r.boughtUPShares += (leg === "YES" ? result.takingAmount : 0);
                                    r.boughtDOWNShares += (leg === "NO" ? result.takingAmount : 0);
                                    const expectedProfit = upAsk > downAsk ? r.boughtUPShares - r.spentUSD : r.boughtDOWNShares - r.spentUSD;
                                    logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                                    logger.info(`[Martingale] ✅ BUY Opposite shares ${martingaleSide}: bought ${result.takingAmount.toFixed(4)} shares @ ${0.5.toFixed(2)}`);
                                    logger.info(`[Status] Spent USD: ${r.spentUSD.toFixed(4)} UP shares bought: ${r.boughtUPShares.toFixed(4)} DOWN shares bought: ${r.boughtDOWNShares.toFixed(4)}`);
                                    logger.info(`[Status] Low shares bought triggers: ${r.boughtFirstSharesTriggers.toFixed(4)} High shares bought triggers: ${r.boughtSecondSharesTriggers.toFixed(4)}`);
                                    logger.info(`[Expected] Expected profit: ${expectedProfit.toFixed(4)}`);
                                    logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                                    saveState(this.state);
                                } else {
                                    logger.error(`[Martingale] ❌ BUY Opposite shares ${martingaleSide}: failed`);
                                    saveState(this.state);
                                }
                            }).catch((e) => {
                                logger.error(`[Martingale] ❌ BUY Opposite shares ${martingaleSide}: error: ${e instanceof Error ? e.message : String(e)}`);
                                const r = this.state[stateKey];
                                if (r && r.slug === slug) {
                                    r.martingalePendingOppositeBuy = false;
                                }
                                saveState(this.state);
                            })
                    }
                }
            }

            // ── ARBITRAGE: multi-trigger per tick (handles price jumps) ────────────────
            // If price jumps across multiple action points between WS updates (e.g. 0.8 → 0.2),
            // we may need to fire multiple depth orders in a single executeTrade call.

            /**
             * When first leg hits depth D (0.4 or 0.3), opposite may already sit at the *next* depth’s
             * match price (0.6 for depth 2, 0.7 for depth 3). Buy planned shares (1$/0.3, 1$/0.2) once.
             */
            const firePrefillOppositeForNextDepth = (
                fallingSide: "UP" | "DOWN",
                depthJustHit: number,
                oppAskNow: number
            ) => {
                const nextDepth = depthJustHit + 1;
                if (nextDepth > depthLimit) return;

                const bit = entryBit(nextDepth);
                if ((row.oppositeLegMask & bit) !== 0) return;
                if ((row.pendingOppositeMask & bit) !== 0) return;

                const oppPoint = oppositePointForDepth(nextDepth);
                if (!(Number.isFinite(oppAskNow) && oppAskNow >= oppPoint - 1e-9)) return;

                const oppositeSide: "UP" | "DOWN" = fallingSide === "UP" ? "DOWN" : "UP";
                const tokenId = oppositeSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                const tick = oppositeSide === "UP" ? upTickSize : downTickSize;
                const legLabel: "YES" | "NO" = oppositeSide === "UP" ? "YES" : "NO";
                const sharesToBuy = plannedSharesForDepth(nextDepth);

                row.pendingOppositeMask |= bit;
                logger.info(
                    `[Arb] Prefill opposite depth ${nextDepth}: ${oppositeSide} ask=${oppAskNow.toFixed(4)} ≥ ${oppPoint.toFixed(2)}` +
                    ` → buying ${sharesToBuy.toFixed(6)} shares (planned 1$/${nextBuyPoint(nextDepth - 1).toFixed(2)})`
                );
                persist();

                void this.buySharesWithGTC(legLabel, tokenId, sharesToBuy, tick)
                    .then((result) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingOppositeMask &= ~bit;
                        if (result.ok && result.takingAmount > 0) {
                            r.oppositeLegMask |= bit;
                            r.spentUSD += result.makingAmount;
                            r.boughtUPShares += (legLabel === "YES" ? result.takingAmount : 0);
                            r.boughtDOWNShares += (legLabel === "NO" ? result.takingAmount : 0);
                            r.boughtSecondSharesTriggers += 1;
                            const expectedProfit = upAsk > downAsk ? r.boughtUPShares - r.spentUSD : r.boughtDOWNShares - r.spentUSD;
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            logger.info(
                                `[Arb] ✅ Prefill confirmed depth ${nextDepth}: bought ${result.takingAmount.toFixed(4)} ${oppositeSide} shares`
                            );
                            logger.info(`[Status] Spent USD: ${r.spentUSD.toFixed(4)} UP shares bought: ${r.boughtUPShares.toFixed(4)} DOWN shares bought: ${r.boughtDOWNShares.toFixed(4)}`);
                            logger.info(`[Status] Low shares bought triggers: ${r.boughtFirstSharesTriggers.toFixed(4)} High shares bought triggers: ${r.boughtSecondSharesTriggers.toFixed(4)}`);
                            logger.info(`[Expected] Expected profit: ${expectedProfit.toFixed(4)}`);
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            saveState(this.state);
                        } else {
                            logger.error(`[Arb] ❌ Prefill failed depth ${nextDepth}`);
                            saveState(this.state);
                        }
                        saveState(this.state);
                    })
                    .catch((e) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingOppositeMask &= ~bit;
                        logger.error(`[Arb] ❌ Prefill error depth ${nextDepth}: ${e instanceof Error ? e.message : String(e)}`);
                        saveState(this.state);
                    });
            };

            const fireFirstLeg = (side: "UP" | "DOWN", depth: number, execAsk: number) => {
                const bit = entryBit(depth);
                if ((row.firstLegMask & bit) !== 0) return;
                if ((row.pendingEntryMask & bit) !== 0) return;
                if (depth < 1 || depth > depthLimit) return;

                const tick = side === "UP" ? upTickSize : downTickSize;
                const tokenId = side === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                const legLabel: "YES" | "NO" = side === "UP" ? "YES" : "NO";
                const priceCap = ceilPriceToTick(Math.min(0.99, execAsk + this.cfg.priceBuffer), tick);

                row.boughtSide = side;
                row.currentDepth = Math.max(row.currentDepth, depth);
                while (row.sharesPerDepth.length < depth) row.sharesPerDepth.push(0);
                row.sharesPerDepth[depth - 1] = TRADE_USD / Math.max(execAsk, 1e-9); // expected until confirmation
                row.pendingEntryMask |= bit;

                logger.info(
                    `[Arb] First-leg depth ${depth}: ${side} ask=${execAsk.toFixed(4)} hit ${nextBuyPoint(depth - 1).toFixed(2)} → buying $${TRADE_USD}`
                );
                persist();

                // Prefill: when UP hits 0.4 / 0.3, opposite may already be at 0.6 / 0.7 (same tick as rapid moves).
                const oppAskNow = side === "UP" ? downAsk : upAsk;
                if (depth === 1 || depth === 2) {
                    firePrefillOppositeForNextDepth(side, depth, oppAskNow);
                }

                void this.buySharesWithFAK(legLabel, tokenId, TRADE_USD, priceCap, tick)
                    .then((result) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingEntryMask &= ~bit;
                        if (result.ok && result.takingAmount > 0 && result.makingAmount > 0) {
                            r.firstLegMask |= bit;
                            r.sharesPerDepth[depth - 1] = result.takingAmount;
                            r.spentUSD += result.makingAmount;
                            r.boughtUPShares += (legLabel === "YES" ? result.takingAmount : 0);
                            r.boughtDOWNShares += (legLabel === "NO" ? result.takingAmount : 0);
                            r.boughtFirstSharesTriggers += 1;
                            const expectedProfit = upAsk > downAsk ? r.boughtUPShares - r.spentUSD : r.boughtDOWNShares - r.spentUSD;
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            logger.info(
                                `[Arb] ✅ First-leg confirmed depth ${depth}: bought ${result.takingAmount.toFixed(4)} ${side} shares`
                            );
                            logger.info(`[Status] Spent USD: ${r.spentUSD.toFixed(4)} UP shares bought: ${r.boughtUPShares.toFixed(4)} DOWN shares bought: ${r.boughtDOWNShares.toFixed(4)}`);
                            logger.info(`[Status] Low shares bought triggers: ${r.boughtFirstSharesTriggers.toFixed(4)} High shares bought triggers: ${r.boughtSecondSharesTriggers.toFixed(4)}`);
                            logger.info(`[Expected] Expected profit: ${expectedProfit.toFixed(4)}`);
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            saveState(this.state);
                        } else {
                            logger.error(`[Arb] ❌ First-leg failed depth ${depth} (${side})`);
                            saveState(this.state);
                        }
                        saveState(this.state);
                    })
                    .catch((e) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingEntryMask &= ~bit;
                        logger.error(`[Arb] ❌ First-leg error depth ${depth} (${side}): ${e instanceof Error ? e.message : String(e)}`);
                        saveState(this.state);
                    });
            };

            const fireOppositeLeg = (oppositeSide: "UP" | "DOWN", depth: number, oppAskNow: number) => {
                const bit = entryBit(depth);
                // Allow opposite hedge as soon as first leg is scheduled or confirmed (same-tick multi-leg).
                if (((row.firstLegMask & bit) === 0) && ((row.pendingEntryMask & bit) === 0)) return;
                if ((row.oppositeLegMask & bit) !== 0) return;
                if ((row.pendingOppositeMask & bit) !== 0) return;

                const threshold = oppositePointForDepth(depth);
                if (!(Number.isFinite(oppAskNow) && oppAskNow <= threshold + 1e-9)) return;

                const sharesToBuy = row.sharesPerDepth[depth - 1] ?? 0;
                if (sharesToBuy <= MIN_ORDER_SHARES) return;

                const tokenId = oppositeSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                const tick = oppositeSide === "UP" ? upTickSize : downTickSize;
                const legLabel: "YES" | "NO" = oppositeSide === "UP" ? "YES" : "NO";

                row.pendingOppositeMask |= bit;
                logger.info(
                    `[Arb] Opposite depth ${depth}: ${oppositeSide} ask=${oppAskNow.toFixed(4)} hit ${threshold.toFixed(2)} → buying ${sharesToBuy.toFixed(6)} shares`
                );
                persist();

                void this.buySharesWithGTC(legLabel, tokenId, sharesToBuy, tick)
                    .then((result) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingOppositeMask &= ~bit;
                        if (result.ok && result.takingAmount > 0) {
                            r.oppositeLegMask |= bit;
                            r.spentUSD += result.makingAmount;
                            r.boughtUPShares += (legLabel === "YES" ? result.takingAmount : 0);
                            r.boughtDOWNShares += (legLabel === "NO" ? result.takingAmount : 0);
                            r.boughtSecondSharesTriggers += 1;
                            const expectedProfit = upAsk > downAsk ? r.boughtUPShares - r.spentUSD : r.boughtDOWNShares - r.spentUSD;
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            logger.info(
                                `[Arb] ✅ Opposite confirmed depth ${depth}: bought ${result.takingAmount.toFixed(4)} ${oppositeSide} shares`
                            );
                            logger.info(`[Status] Spent USD: ${r.spentUSD.toFixed(4)} UP shares bought: ${r.boughtUPShares.toFixed(4)} DOWN shares bought: ${r.boughtDOWNShares.toFixed(4)}`);
                            logger.info(`[Status] Low shares bought triggers: ${r.boughtFirstSharesTriggers.toFixed(4)} High shares bought triggers: ${r.boughtSecondSharesTriggers.toFixed(4)}`);
                            logger.info(`[Expected] Expected profit: ${expectedProfit.toFixed(4)}`);
                            logger.info('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
                            saveState(this.state);
                        } else {
                            logger.error(`[Arb] ❌ Opposite failed depth ${depth}`);
                            saveState(this.state);
                        }
                        saveState(this.state);
                    })
                    .catch((e) => {
                        const r = this.state[stateKey];
                        if (!r || r.slug !== slug) return;
                        r.pendingOppositeMask &= ~bit;
                        logger.error(`[Arb] ❌ Opposite error depth ${depth}: ${e instanceof Error ? e.message : String(e)}`);
                        saveState(this.state);
                    });
            };

            // 1) Pick side if not yet chosen (depth 0). We base this on *current* asks so jumps still trigger.
            if (row.boughtSide == null) {
                const p1 = nextBuyPoint(0); // 0.4
                const upEligible = Number.isFinite(upAsk) && upAsk <= p1 + 1e-9;
                const downEligible = Number.isFinite(downAsk) && downAsk <= p1 + 1e-9;
                if (upEligible || downEligible) {
                    const side: "UP" | "DOWN" =
                        upEligible && downEligible ? (upAsk <= downAsk ? "UP" : "DOWN") : upEligible ? "UP" : "DOWN";
                    row.boughtSide = side;
                }
            }

            // 2) Fire all missing first-leg depth buys that are already satisfied by the current falling-side ask.
            if (row.boughtSide) {
                const side = row.boughtSide;
                const fallingAskNow = side === "UP" ? upAsk : downAsk;
                if (Number.isFinite(fallingAskNow)) {
                    for (let depth = 1; depth <= depthLimit; depth++) {
                        const threshold = nextBuyPoint(depth - 1); // 0.4/0.3/0.2
                        if (fallingAskNow <= threshold + 1e-9) {
                            fireFirstLeg(side, depth, fallingAskNow);
                        }
                    }
                }
            }

            // 3) Fire all missing opposite-leg buys satisfied by current opposite ask (handles jumps too).
            if (row.boughtSide) {
                const oppositeSide: "UP" | "DOWN" = row.boughtSide === "UP" ? "DOWN" : "UP";
                const oppAskNow = oppositeSide === "UP" ? upAsk : downAsk;
                for (let depth = 1; depth <= depthLimit; depth++) {
                    fireOppositeLeg(oppositeSide, depth, oppAskNow);
                }
            }

            // No trigger fired — just update previous prices and move on
            commitPrevPrices();
            persist();

        } catch (error) {
            logger.error(
                `executeTrade error [${market}] slug=${slug}: ${error instanceof Error ? error.message : String(error)}`
            );
        }
    }

    // Derive seconds remaining until settlement from the slug timestamp.
    // Primary: `btc-updown-4h-{unix}`; legacy hourly ET + `5m` / `15m` interval slugs.
    private getTimeRemainingForSlug(slug: string): number {
        const startTs = cycleStartUnixFromSlug(slug);
        const durationSec = marketDurationSecondsFromSlug(slug);
        if (startTs == null || !Number.isFinite(startTs) || durationSec == null) return Infinity;
        return startTs + durationSec - Math.floor(Date.now() / 1000);
    }
}
import { ClobClient, CreateOrderOptions, OrderType, Side, UserMarketOrderV2, TickSize, AssetType, BalanceAllowanceResponse, UserOrderV2 } from "@polymarket/clob-client-v2";
import * as fs from "fs";
import * as path from "path";
import { WebSocketOrderBook, TokenPrice } from "../providers/websocketOrderbook";
import { ENV } from "../config/env";
import logger from "../utils/appLogger";
import { spawnRedeemAutoWorker } from "../redeem/spawnRedeemWorker";
import { recordCycleEndedForRedeemTracking, recordCycleStartedForRedeemTracking } from "../utils/pnlRedeemTracking";
import { getCurrentTimeLine, getCurrentTimeLineLabel } from "../utils/timeCheck";
import {
    slugForCurrentUpDownMarket,
    fetchTokenIdsForSlug,
    cycleStartUnixFromSlug,
    marketDurationSecondsFromSlug,
} from "../utils/marketSlug";

type SimpleStateRow = {
    previousUpPrice: number | null; // Previous cycle's UP token price
    lastUpdatedIso: string;
    /** Previous tick asks (used to detect rising into action-point band). */
    prevUpAsk?: number | null;
    prevDownAsk?: number | null;
    /** Previous tick bids (used to detect falling into reversal-guard band). */
    prevUpBid?: number | null;
    prevDownBid?: number | null;
    // Holdings tracking (for redemption)
    conditionId?: string;
    slug?: string;
    market?: string;
    upIdx?: number;
    downIdx?: number;
    /**
     * Development-mode "action points" state machine (no real orders).
     * pointCount includes the first point.
     */
    pointCount?: number;
    /** Current holding share side */
    currentHoldingSide?: "UP" | "DOWN";
    /** Virtual shares bought this cycle (for dev sell simulation) */
    cycleShares?: number;
    /** Flag variable if bot boughts shares at action point */
    actionPointBought?: boolean;
    /** Time-line at cycle start (JST) */
    timeLineKey?: "GOLDERN_TIME" | "GOOD_TIME" | "MIDDLE_TIME" | "POOR_TIME";
    timeLineLabel?: string;
    /** Delay Action Point #2+ until N seconds into the cycle */
    actionPointResumeAfterSeconds?: number;
    /** Action limit for this cycle (derived from timeline config). */
    actionLimit?: number;
    /** Action multiplier for this cycle (derived from timeline config). */
    actionMultiplier?: number;
    /** Throttle "seconds until next round" logs while idle after rapid reverse */
    lastIdleCountdownLogMs?: number;
    /** Amount of shares bot bought to overcome instant sell just after buying shares */
    instantShares?: number;
};

type SimpleStateFile = Record<string, SimpleStateRow>;

type SimpleConfig = {
    markets: string[]; // e.g. ["btc"] → `btc-updown-4h-{unix}` (legacy hourly / 15m slugs still parsed)
    tickSize: CreateOrderOptions["tickSize"];
    negRisk: boolean;
    priceBuffer: number; // Price buffer in cents for order execution (e.g., 0.03 = 3 cents)
    fireAndForget: boolean; // Don't wait for order confirmation (fire-and-forget)
    // Risk management
    minBalanceUsdc: number; // Minimum balance before stopping
};

const STATE_FILE = "src/data/bot-state.json";

/** No action-point buys when this many seconds or fewer remain (volatile close). */
const ACTION_POINT_BUY_BLOCKED_LAST_SECONDS = ENV.ACTION_POINT_BUY_BLOCKED_LAST_SECONDS;
const ACTION_POINT = ENV.ACTION_POINT;
const actionPointDelta = 0.02;
const ACTION_LIMIT = ENV.ACTION_LIMIT;
const ACTION_MULTIPLIER = ENV.ACTION_MULTIPLIER;
const SELL_DIVISION_START_USD = ENV.SELL_DIVISION_START_USD;
const BUY_DIVISION_START_USD = ENV.BUY_DIVISION_START_USD;

/** USDC chunk floor (2dp) so split parts sum without overspending intent. */
function roundUsdDown(usd: number): number {
    return Math.floor(usd * 1000000) / 1000000;
}

/** Keep a short FIFO history of prior-cycle action point hits (per market). */
const ACTION_POINT_HISTORY_LEN = 5;

/** During the cycle, reduce reversal risk if last-bought side drops near 0.50. */
const REVERSAL_GUARD_THRESHOLD = 0.5;
const reversalGuardDelta = actionPointDelta; // 0.02 → band [0.48..0.50]

/** How often to log countdown while idle after rapid-reverse (avoid WS spam). */
const IDLE_COUNTDOWN_LOG_MS = 15_000;

function statePath(): string {
    return path.resolve(process.cwd(), STATE_FILE);
}

function emptyRow(): SimpleStateRow {
    return {
        previousUpPrice: null,
        lastUpdatedIso: new Date().toISOString(),
        prevUpAsk: null,
        prevDownAsk: null,
        prevUpBid: null,
        prevDownBid: null,
        pointCount: 0,
        cycleShares: 0,
        actionPointBought: false,
        timeLineKey: undefined,
        actionPointResumeAfterSeconds: undefined,
        actionLimit: undefined,
        actionMultiplier: undefined,
        instantShares: 0,
    };
}

function floorPriceToTick(price: number, tickSize: string): number {
    const tick = parseFloat(tickSize);
    if (!Number.isFinite(tick) || tick <= 0) return price;
    return Math.floor(price / tick) * tick;
}

function ceilPriceToTick(price: number, tickSize: string): number {
    const tick = parseFloat(tickSize);
    if (!Number.isFinite(tick) || tick <= 0) return price;
    return Math.ceil(price / tick - 1e-12) * tick;
}

/** Round share size down so USDC spend does not exceed intended notional. */
function roundSizeDown(size: number, decimals = 6): number {
    const f = 10 ** decimals;
    return Math.floor(size * f) / f;
}

/**
 * Polymarket CLOB fixed-6 response amounts. Encoding is the same for both sides; **meaning** depends on order side:
 * - **BUY:** `makingAmount` = **USDC** the maker spent (collateral out).
 * - **SELL:** `makingAmount` = **outcome shares** the maker sold (not USDC).
 * All-digit strings → ÷ 1e6; decimal strings → human fallback.
 */

const MIN_ORDER_SHARES = 0.01;
const MIN_ORDER_USDC = 0.01;
/** Max extra FAK posts per market buy/sell when an order only partially fills. */
const MAX_FAK_PARTIAL_MARKET_ROUNDS = 5;
/** After this many partial FAK rounds with leftover shares, lower min sell price by one tick. */
const FAK_SELL_LOWER_MIN_EVERY_N_ROUNDS = 5;
/** After this many partial FAK rounds with leftover USDC, raise buy price cap by one tick. */
const FAK_BUY_RAISE_CAP_EVERY_N_ROUNDS = 5;
const FAK_PARTIAL_MARKET_DELAY_MS = 20;

function loadState(): SimpleStateFile {
    const p = statePath();
    try {
        if (fs.existsSync(p)) {
            const raw = fs.readFileSync(p, "utf8").trim();
            if (!raw) return {};
            const parsed = JSON.parse(raw);

            // Normalize state
            const normalized: SimpleStateFile = {};
            for (const [k, v] of Object.entries(parsed)) {
                if (typeof v !== "object" || !v) continue;
                const row = v as any;
                normalized[k] = {
                    previousUpPrice: typeof row.previousUpPrice === "number" ? row.previousUpPrice : null,
                    lastUpdatedIso: String(row.lastUpdatedIso ?? new Date().toISOString()),
                    prevUpAsk: row.prevUpAsk == null ? null : (Number.isFinite(Number(row.prevUpAsk)) ? Number(row.prevUpAsk) : null),
                    prevDownAsk: row.prevDownAsk == null ? null : (Number.isFinite(Number(row.prevDownAsk)) ? Number(row.prevDownAsk) : null),
                    prevUpBid: row.prevUpBid == null ? null : (Number.isFinite(Number(row.prevUpBid)) ? Number(row.prevUpBid) : null),
                    prevDownBid: row.prevDownBid == null ? null : (Number.isFinite(Number(row.prevDownBid)) ? Number(row.prevDownBid) : null),
                    conditionId: typeof row.conditionId === "string" ? row.conditionId : undefined,
                    slug: typeof row.slug === "string" ? row.slug : undefined,
                    market: typeof row.market === "string" ? row.market : undefined,
                    upIdx: Number.isFinite(Number(row.upIdx)) ? Number(row.upIdx) : undefined,
                    downIdx: Number.isFinite(Number(row.downIdx)) ? Number(row.downIdx) : undefined,
                    pointCount: Number.isFinite(Number(row.pointCount)) ? Number(row.pointCount) : 0,
                    currentHoldingSide: row.currentHoldingSide === "UP" || row.currentHoldingSide === "DOWN" ? row.currentHoldingSide : undefined,
                    cycleShares: Number.isFinite(Number(row.cycleShares)) ? Number(row.cycleShares) : 0,
                    actionPointBought: row.actionPointBought === true ? true : false,
                    instantShares: Number.isFinite(Number(row.instantShares)) ? Number(row.instantShares) : 0,
                    timeLineKey:
                        row.timeLineKey === "GOLDERN_TIME" ||
                        row.timeLineKey === "GOOD_TIME" ||
                        row.timeLineKey === "MIDDLE_TIME" ||
                        row.timeLineKey === "POOR_TIME"
                            ? row.timeLineKey
                            : row.timeLineKey === "GOLDEN_TIME"
                                ? "GOLDERN_TIME"
                                : row.timeLineKey === "LUNCH_TIME"
                                    ? "MIDDLE_TIME"
                                    : row.timeLineKey === "POOR_TIME"
                                        ? "POOR_TIME"
                                        : undefined,
                    timeLineLabel: typeof row.timeLineLabel === "string" ? row.timeLineLabel : undefined,
                    actionPointResumeAfterSeconds: Number.isFinite(Number(row.actionPointResumeAfterSeconds))
                        ? Number(row.actionPointResumeAfterSeconds)
                        : undefined,
                    actionLimit: Number.isFinite(Number(row.actionLimit)) ? Number(row.actionLimit) : undefined,
                    actionMultiplier: Number.isFinite(Number(row.actionMultiplier)) ? Number(row.actionMultiplier) : undefined,
                    lastIdleCountdownLogMs: Number.isFinite(Number(row.lastIdleCountdownLogMs))
                        ? Number(row.lastIdleCountdownLogMs)
                        : undefined,
                };
            }
            return normalized;
        }
    } catch (e) {
        logger.error(`Failed to read state: ${e instanceof Error ? e.message : String(e)}`);
    }
    return {};
}

// Debounced state save
let saveStateTimer: NodeJS.Timeout | null = null;
function saveState(state: SimpleStateFile): void {
    if (saveStateTimer) {
        clearTimeout(saveStateTimer);
    }
    saveStateTimer = setTimeout(() => {
        try {
            const p = statePath();
            fs.mkdirSync(path.dirname(p), { recursive: true });
            fs.writeFileSync(p, JSON.stringify(state, null, 2));
        } catch (e) {
            logger.error(`Failed to save state: ${e instanceof Error ? e.message : String(e)}`);
        }
        saveStateTimer = null;
    }, 500); // Debounce saves by 500ms
}

export class UpDownPredictionBot {
    private lastSlugByMarket: Record<string, string> = {};
    private tokenIdsByMarket: Record<
        string,
        { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    > = {};

    private state: SimpleStateFile = loadState();
    private isStopped: boolean = false;
    private wsOrderBook: WebSocketOrderBook | null = null;
    private useWebSocket: boolean = true; // Toggle to use WebSocket or API

    // Limit order second side strategy tracking
    private tokenCountsByMarket: Map<string, { upTokenCount: number; downTokenCount: number }> = new Map(); // Track token counts per market
    private pausedMarkets: Set<string> = new Set(); // Track paused markets (reached max tokens per side)

    private initializationPromise: Promise<void> | null = null;
    /** Unix-ms timestamp of the last `cancelAll()` call – prevents duplicate calls when
     *  multiple markets roll over near-simultaneously. */
    private lastCancelAllMs = 0;
    /** Interval handles stored so they can be cleared on stop(). */
    private intervals: NodeJS.Timeout[] = [];
    /** Per-market lock to prevent concurrent reinitializeMarketForNewCycle calls. */
    private reinitLocks: Set<string> = new Set();
    /** One order flow at a time per market (avoids duplicate action points / rapid sells on burst ticks). */
    private orderInFlightByMarket: Set<string> = new Set();

    /** Fixed-length queue of prior cycle pointCounts (per market). */
    private actionPointHistoryByMarket: Record<string, number[]> = {};

    constructor(private client: ClobClient, private cfg: SimpleConfig) {
        // Initialize WebSocket orderbook (store promise for later awaiting)
        this.initializationPromise = this.initializeWebSocket();
    }

    private getActionPointHistoryQueue(market: string): number[] {
        const existing = this.actionPointHistoryByMarket[market];
        if (Array.isArray(existing) && existing.length === ACTION_POINT_HISTORY_LEN) return existing;
        const init = new Array(ACTION_POINT_HISTORY_LEN).fill(0);
        this.actionPointHistoryByMarket[market] = init;
        return init;
    }

    private enqueuePriorCycleActionPoints(market: string, lastPointCount: number): void {
        const q = this.getActionPointHistoryQueue(market);
        q.push(Number.isFinite(lastPointCount) ? lastPointCount : 0);
        while (q.length > ACTION_POINT_HISTORY_LEN) q.shift();
        this.actionPointHistoryByMarket[market] = q;
    }

    static async fromEnv(client: ClobClient): Promise<UpDownPredictionBot> {
        const bot = new UpDownPredictionBot(client, {
            markets: ["btc"], tickSize: "0.01" as CreateOrderOptions["tickSize"],
            negRisk: false, priceBuffer: 0.03, fireAndForget: false, minBalanceUsdc: 1,
        });
        await bot.initializationPromise; // Await Polymarket WebSocket initialization

        return bot;
    }

    async initializeWebSocket(): Promise<void> {
        if (!this.useWebSocket) {
            logger.error("WebSocket disabled in config");
            return;
        }
        try {
            this.wsOrderBook = new WebSocketOrderBook("market", [], null);
            await this.wsOrderBook.connect();
            logger.info("WebSocket orderbook initialized");
        } catch (e) {
            logger.error(`Failed to initialize WebSocket: ${e instanceof Error ? e.message : String(e)}`);
            throw e;
        }
    }

    async start(): Promise<void> {
        if (this.isStopped) {
            logger.error("Bot is stopped, cannot start");
            return;
        }

        if (!this.wsOrderBook) {
            logger.error("Fatal error: WebSocket orderbook not initialized - cannot start bot");
            return;
        }

        logger.info(`Starting UpDownPredictionBot for markets: ${this.cfg.markets.join(", ")}`);
        await this.initializeMarkets();
    }

    stop(): void {
        this.isStopped = true;

        // Clear all periodic timers
        for (const t of this.intervals) clearInterval(t);
        this.intervals = [];

        // Generate final summaries unconditionally (no time-gate at shutdown)
        logger.info("\n🛑 Generating final prediction summaries...");
        // this.flushPredictionSummaries(true);

        if (this.wsOrderBook) {
            this.wsOrderBook.disconnect();
        }
        logger.info("UpDownPredictionBot stopped");
    }

    private async initializeMarkets(): Promise<void> {
        await Promise.all(this.cfg.markets.map((m) => this.initializeMarket(m)));
    }

    private async initializeMarket(market: string): Promise<void> {
        try {
            const slug = slugForCurrentUpDownMarket(market);
            logger.info(`Initializing market ${market} with slug ${slug}`);
            const tokenIds = await fetchTokenIdsForSlug(slug);
            this.tokenIdsByMarket[market] = { slug, ...tokenIds };
            this.lastSlugByMarket[market] = slug;

            // Subscribe to WebSocket prices for these tokens
            if (this.wsOrderBook) {
                this.wsOrderBook.subscribeToTokenIds([tokenIds.upTokenId, tokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(tokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(tokenIds.downTokenId, "Down");

                // Set up price update callbacks - trigger trading logic on price updates
                this.wsOrderBook.onPriceUpdate(tokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(tokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug, ...tokenIds }, price, "NO");
                });
            }

            // Kickstart one tick immediately so Action Point #1 fires as close to cycle start as possible,
            // instead of waiting for the first WS update to arrive.
            this.kickstartCycleTick(market, slug, tokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            const slug = slugForCurrentUpDownMarket(market);
            logger.error(`⚠️  Market ${market} not available yet (${slug}): ${errorMsg}. Will retry on next price update.`);
            // Don't throw - allow the bot to continue and retry later
        }
    }

    /** Try to run one executeTrade tick ASAP using the latest cached WS prices. */
    private kickstartCycleTick(
        market: string,
        slug: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number; strikeK: number | null }
    ): void {
        if (!this.wsOrderBook) return;
        if (this.isStopped) return;

        // Fire-and-forget, short polling window (WS often lags a couple seconds at boundary).
        void (async () => {
            const maxAttempts = 40; // ~2s at 50ms
            const delayMs = 50;
            for (let i = 0; i < maxAttempts; i++) {
                if (this.isStopped) return;
                const up = this.wsOrderBook?.getPrice(tokenIds.upTokenId);
                const down = this.wsOrderBook?.getPrice(tokenIds.downTokenId);
                const upAsk = up?.bestAsk;
                const downAsk = down?.bestAsk;
                if (
                    upAsk != null &&
                    downAsk != null &&
                    Number.isFinite(upAsk) &&
                    Number.isFinite(downAsk)
                ) {
                    const upBid = up?.bestBid != null && Number.isFinite(up.bestBid) ? up.bestBid : null;
                    const downBid = down?.bestBid != null && Number.isFinite(down.bestBid) ? down.bestBid : null;
                    const timeRemaining = this.getTimeRemainingForSlug(slug);
                    await this.executeTrade(
                        market,
                        slug,
                        upAsk,
                        downAsk,
                        upBid,
                        downBid,
                        up?.tickSize || this.cfg.tickSize,
                        down?.tickSize || this.cfg.tickSize,
                        {
                            upTokenId: tokenIds.upTokenId,
                            downTokenId: tokenIds.downTokenId,
                            conditionId: tokenIds.conditionId,
                            upIdx: tokenIds.upIdx,
                            downIdx: tokenIds.downIdx,
                        },
                        timeRemaining
                    );
                    return;
                }
                await new Promise((r) => setTimeout(r, delayMs));
            }
        })().catch((e) => {
            logger.error(
                `kickstartCycleTick error [${market}] slug=${slug}: ${e instanceof Error ? e.message : String(e)}`
            );
        });
    }

    // Handle price updates from WebSocket - core trading logic
    // Uses queueMicrotask to prevent blocking WebSocket message loop
    private async handlePriceUpdate(
        market: string,
        tokenIds: { slug: string; upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        price: TokenPrice,
        _leg: "YES" | "NO"
    ): Promise<void> {
        if (this.isStopped) return;
        if (!price.bestAsk || !Number.isFinite(price.bestAsk)) return; // Use bestAsk

        // Defer heavy processing to prevent blocking WebSocket message loop
        queueMicrotask(() => {
            void (async () => {
                // Get slug for current 4h UTC window (or legacy cached slug)
                const slug = this.getSlugForMarket(market);
                if (!slug) {
                    // Market not initialized yet - initialize it
                    void this.initializeMarket(market);
                    return;
                }

                // Check if we have cached tokenIds for this market, and if slug matches
                let currentTokenIds = tokenIds;
                const cachedTokenIds = this.tokenIdsByMarket[market];
                if (cachedTokenIds && cachedTokenIds.slug === slug) {
                    // Use cached tokenIds if slug matches
                    currentTokenIds = cachedTokenIds;
                }
                // If slug doesn't match, we'll handle re-initialization in the market cycle check below

                // Get both prices (we need UP ask price for comparison) - fast cache lookup
                const upPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                const downPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                // Use bestAsk price for limit orders (required for order placement)
                if (!upPrice?.bestAsk || !downPrice?.bestAsk ||
                    !Number.isFinite(upPrice.bestAsk) || !Number.isFinite(downPrice.bestAsk)) {
                    return; // Wait for both ask prices
                }

                let upAsk: number = upPrice.bestAsk;
                let downAsk: number = downPrice.bestAsk;
                let upBid: number | null =
                    upPrice.bestBid != null && Number.isFinite(upPrice.bestBid) ? upPrice.bestBid : null;
                let downBid: number | null =
                    downPrice.bestBid != null && Number.isFinite(downPrice.bestBid) ? downPrice.bestBid : null;

                // Check for market cycle change (new hour / slug)
                // Initialize lastSlugByMarket if not set (first time)
                if (!this.lastSlugByMarket[market]) {
                    this.lastSlugByMarket[market] = slug;
                }

                const prevSlug = this.lastSlugByMarket[market];
                if (prevSlug && prevSlug !== slug) {
                    // Do not log here: UP+DOWN WS ticks (and burst updates) all hit this branch
                    // before reinit finishes — logging only inside reinitializeMarketForNewCycle after lock.
                    await this.reinitializeMarketForNewCycle(market, prevSlug, slug);

                    // Refresh tokenIds after re-init
                    const refreshed = this.tokenIdsByMarket[market];
                    if (!refreshed || refreshed.slug !== slug) return;
                    currentTokenIds = refreshed;

                    const newUpPrice = this.wsOrderBook?.getPrice(currentTokenIds.upTokenId);
                    const newDownPrice = this.wsOrderBook?.getPrice(currentTokenIds.downTokenId);

                    if (!newUpPrice?.bestAsk || !newDownPrice?.bestAsk ||
                        !Number.isFinite(newUpPrice.bestAsk) || !Number.isFinite(newDownPrice.bestAsk)) {
                        return;
                    }
                    upAsk = newUpPrice.bestAsk;
                    downAsk = newDownPrice.bestAsk;
                    upBid =
                        newUpPrice.bestBid != null && Number.isFinite(newUpPrice.bestBid)
                            ? newUpPrice.bestBid
                            : null;
                    downBid =
                        newDownPrice.bestBid != null && Number.isFinite(newDownPrice.bestBid)
                            ? newDownPrice.bestBid
                            : null;
                }

                const timeRemaining = this.getTimeRemainingForSlug(slug);

                await this.executeTrade(
                    market,
                    slug,
                    upAsk,
                    downAsk,
                    upBid,
                    downBid,
                    upPrice.tickSize || this.cfg.tickSize,
                    downPrice.tickSize || this.cfg.tickSize,
                    currentTokenIds,
                    timeRemaining
                );

                saveState(this.state);
            })().catch((e) => {
                logger.error(`handlePriceUpdate error [${market}]: ${e instanceof Error ? e.message : String(e)}`);
            });
        });
    }

    private getSlugForMarket(market: string): string {
        return slugForCurrentUpDownMarket(market);
    }

    // Re-initialize market for a new cycle
    // A per-market lock prevents concureent calls (from handlePriceUpdate AND the periodic checkAndHandleMarketCycleChanges) running simultaneously
    private async reinitializeMarketForNewCycle(market: string, prevSlug: string, newSlug: string): Promise<void> {
        if (this.reinitLocks.has(market)) return;
        this.reinitLocks.add(market);

        const priorRow = this.state[market];
        const prevConditionId =
            typeof priorRow?.conditionId === "string" && /^0x[a-fA-F0-9]{64}$/.test(priorRow.conditionId.trim())
                ? priorRow.conditionId.trim()
                : undefined;

        logger.info(`🔄 New market cycle [${market}]: ${prevSlug} → ${newSlug}`);

        // Track prior cycle in logs/pnl.json as not_redeemed (updated to redeemed when redeem succeeds).
        if (prevConditionId) {
            setImmediate(() => {
                recordCycleEndedForRedeemTracking({
                    conditionId: prevConditionId,
                    slug: prevSlug,
                    market,
                });
            });
        }

        // Redeem previous market in a separate Node process (no await) — does not block trading or WS handling.
        if (ENV.redeem.autoAfterCycle && prevConditionId) {
            setImmediate(() => {
                try {
                    spawnRedeemAutoWorker(prevConditionId, prevSlug);
                    logger.info(`[redeem] Spawned worker for prior condition (slug=${prevSlug})`);
                } catch (e) {
                    logger.error(
                        `[redeem] Failed to spawn worker: ${e instanceof Error ? e.message : String(e)}`
                    );
                }
            });
        }

        // Cancel all open GTC orders (resting second-leg limits from the previous cycle) once per
        // rollover event, even when multiple markets tick simultaneously.
        const now = Date.now();
        if (now - this.lastCancelAllMs > 60_000) {
            this.lastCancelAllMs = now;
            try {
                await this.client.cancelAll();
                logger.info(`🗑️  Cancelled all open GTC orders at cycle boundary`);
            } catch (e) {
                logger.error(`cancelAll failed at cycle boundary: ${e instanceof Error ? e.message : String(e)}`);
            }
        }

        // Reset token counts and paused state for previous market
        const prevScoreKey = `${market}-${prevSlug}`;
        this.tokenCountsByMarket.delete(prevScoreKey);
        this.pausedMarkets.delete(prevScoreKey);

        try {
            const newTokenIds = await fetchTokenIdsForSlug(newSlug);
            this.tokenIdsByMarket[market] = { slug: newSlug, ...newTokenIds };

            // Update WebSocket subscriptions for new tokens
            if (this.wsOrderBook) {
                // Subscribe to new tokens
                this.wsOrderBook.subscribeToTokenIds([newTokenIds.upTokenId, newTokenIds.downTokenId]);

                // Set token labels for logging
                this.wsOrderBook.setTokenLabel(newTokenIds.upTokenId, "Up");
                this.wsOrderBook.setTokenLabel(newTokenIds.downTokenId, "Down");

                // Update callbacks with new token IDs
                this.wsOrderBook.onPriceUpdate(newTokenIds.upTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "YES");
                });

                this.wsOrderBook.onPriceUpdate(newTokenIds.downTokenId, (tokenId, price) => {
                    void this.handlePriceUpdate(market, { slug: newSlug, ...newTokenIds }, price, "NO");
                });         
            }

            this.lastSlugByMarket[market] = newSlug;

            logger.info(`✅ Market ${market} re-initialized with new token IDs for cycle ${newSlug}`);

            // Kickstart one tick immediately to reduce delay on Action Point #1 at boundary.
            this.kickstartCycleTick(market, newSlug, newTokenIds);
        } catch (e) {
            const errorMsg = e instanceof Error ? e.message : String(e);
            logger.error(`⚠️  Failed to re-initialize market ${market} with new slug ${newSlug}: ${errorMsg}. Will retry on next check.`);
        } finally {
            this.reinitLocks.delete(market);
        }
    }

    /**
     * Market BUY (FAK): `usdAmount` is total USDC to spend. `priceCap` is max acceptable price.
     * Re-posts FAK until remaining notional is below {@link MIN_ORDER_USDC} or a post fails.
     * Response **`makingAmount`** is USDC spent on this fill (collateral out), parsed via
     * {@link parseClobOrderResponseAmount}; leftover notional is reduced by that amount.
     * Every {@link FAK_BUY_RAISE_CAP_EVERY_N_ROUNDS} partial rounds with leftover USDC, price cap
     * steps up by one tick (capped at 0.99).
     */
    private async buyShares(
        leg: "YES" | "NO",
        tokenID: string,
        usdAmount: number,
        priceCap: number,
        tickSize: string,
    ): Promise<{ ok: boolean; takingAmount: number }> {
        let remainingUsd = usdAmount;
        if (remainingUsd < MIN_ORDER_USDC) {
            logger.error(`BUY skipped ${leg}: USDC amount ${remainingUsd} below minimum`);
            return { ok: false, takingAmount: 0.000000 };
        }

        let buyPriceCap = priceCap;
        buyPriceCap = 0.99;
        const tickN = parseFloat(tickSize);
        const canStepBuyCap = Number.isFinite(tickN) && tickN > 0;
        let takingAmount = 0.000000;

        try {
            for (let partialRound = 1; partialRound <= MAX_FAK_PARTIAL_MARKET_ROUNDS; partialRound++) {
                if (remainingUsd < MIN_ORDER_USDC) break;

                const amount = remainingUsd;
                const userMarketOrder: UserMarketOrderV2 = {
                    tokenID,
                    side: Side.BUY,
                    amount,
                    orderType: OrderType.FAK,
                    price: buyPriceCap,
                };

                logger.info(
                    [
                        `BUY: ${leg} market FAK ~$${amount.toFixed(2)} USDC @ max price ${buyPriceCap.toFixed(4)}`,
                        partialRound >= 1 ? `(partial round ${partialRound})` : "",
                    ]
                        .filter(Boolean)
                        .join(" ")
                );

                const response = await this.client.createAndPostMarketOrder(
                    userMarketOrder,
                    { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
                    OrderType.FAK,
                    false
                );

                logger.info('-------------------------------------------------------');
                logger.info(`🟦 BUY ${leg} response: ${JSON.stringify(response)}`);

                const filledRaw = parseFloat(String(response.makingAmount ?? "0.000000"));
                const filledUsd = Math.min(amount, filledRaw);
                remainingUsd = remainingUsd - filledUsd;
                takingAmount += parseFloat(String(response.takingAmount ?? "0.000000"));

                logger.warn(
                    [
                        `BUY ${leg} round ${partialRound}/${MAX_FAK_PARTIAL_MARKET_ROUNDS} partial FAK post succeeded`,
                        `spentThisRound≈$${filledUsd.toFixed(4)} (order $${amount.toFixed(2)}) remaining≈$${remainingUsd.toFixed(2)}`,
                    ].join(" | ")
                );

                if (remainingUsd < MIN_ORDER_USDC) {
                    return { ok: true, takingAmount: takingAmount };
                }

                if (partialRound % FAK_BUY_RAISE_CAP_EVERY_N_ROUNDS === 0 && canStepBuyCap) {
                    const next = Math.min(0.99, buyPriceCap + tickN);
                    if (next > buyPriceCap + 1e-12) {
                        logger.warn(
                            `BUY ${leg}: after ${partialRound} partial FAK rounds, raising priceCap ${buyPriceCap.toFixed(4)} → ${next.toFixed(4)} (tick=${tickN})`
                        );
                        buyPriceCap = next;
                    } else {
                        logger.warn(
                            `BUY ${leg}: priceCap cannot increase further (${buyPriceCap.toFixed(4)}) after ${partialRound} partial rounds`
                        );
                    }
                }

                await new Promise((r) => setTimeout(r, FAK_PARTIAL_MARKET_DELAY_MS));
            }
            if (remainingUsd < MIN_ORDER_USDC) return { ok: true, takingAmount: takingAmount };
            logger.error(
                `BUY ${leg}: exceeded ${MAX_FAK_PARTIAL_MARKET_ROUNDS} FAK partial rounds; ~$${remainingUsd.toFixed(2)} USDC still intended`
            );
            return { ok: false, takingAmount: takingAmount };
        } catch (e) {
            logger.error(`BUY failed for ${leg}: ${e instanceof Error ? e.message : String(e)}`);
            return { ok: false, takingAmount: takingAmount };
        }
    }

    /**
     * Market SELL (FAK): `shares` is total to sell. `minPrice` is minimum acceptable (best bid floor).
     * Up to {@link MAX_FAK_PARTIAL_MARKET_ROUNDS} FAK posts until remaining shares drop below
     * MIN_ORDER_SHARES or a post fails. After each post,
     * Response **`makingAmount`** is **outcome shares** sold this post (maker leg), not USDC — parsed via
     * {@link parseClobOrderResponseAmount}; `remaining` is reduced by that share count.
     * Every {@link FAK_SELL_LOWER_MIN_EVERY_N_ROUNDS} partial rounds with leftover size, min price steps
     * down by one tick (same pattern as former rapid-reverse retries).
     */
    private async sellShares(
        leg: "YES" | "NO",
        tokenID: string,
        minPrice: number,
        shares: number,
        tickSize: string,
    ): Promise<{ ok: boolean, takingAmount: number }> {
        let remaining = shares * 0.98; // Buffer to avoid rounding errors
        if (remaining < MIN_ORDER_SHARES) {
            logger.error(`SELL skipped ${leg}: shares ${remaining} below minimum`);
            return { ok: false, takingAmount: 0.000000 };
        }

        let sellMinPx = minPrice;
        const tickN = parseFloat(tickSize);
        const canStepMinPx = Number.isFinite(tickN) && tickN > 0;

        // try {
        //     for (
        //         let partialRound = 1;
        //         partialRound <= MAX_FAK_PARTIAL_MARKET_ROUNDS;
        //         partialRound++
        //     ) {
        //         if (remaining < MIN_ORDER_SHARES) {
        //             break;
        //         }

        //         let amount = remaining;
        //         const userMarketOrder: UserMarketOrder = {
        //             tokenID,
        //             price: sellMinPx,
        //             side: Side.SELL,
        //             amount,
        //             orderType: OrderType.FAK,
        //         };

        //         logger.info(
        //             [
        //                 `SELL: ${leg} market FAK ~${amount.toFixed(4)} shares @ min price ${sellMinPx.toFixed(4)}`,
        //                 partialRound > 1 ? `(partial round ${partialRound})` : "",
        //             ]
        //                 .filter(Boolean)
        //                 .join(" ")
        //         );

        //         const response = await this.client.createAndPostMarketOrder(
        //             userMarketOrder,
        //             { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
        //             OrderType.FAK,
        //             false
        //         );

        //         if (response?.status == 400) {
        //             const str = String(response?.error);
        //             const match = str.match(/balance:\s*(\d+)/);
        //             const balance = match ? parseInt(match[1], 10) : null;

        //             amount = balance != null ? balance / 1000000 : amount;
        //         }
        //         logger.info('=================================================');
        //         logger.info(`🟦 SELL ${leg} response makingAmount: ${JSON.stringify(response)}`);

        //         const sharesFilledRaw = parseFloat(String(response.makingAmount ?? "0.0000"));
        //         const soldShares = Math.min(amount, sharesFilledRaw);
        //         remaining = amount - soldShares;

        //         logger.warn(
        //             [
        //                 `SELL ${leg} round ${partialRound}/${MAX_FAK_PARTIAL_MARKET_ROUNDS} partial FAK post succeeded`,
        //                 `sharesSoldThisRound≈${soldShares.toFixed(4)} (order ${amount.toFixed(4)} sh) remaining≈${remaining.toFixed(4)} (target ${roundSizeDown(shares).toFixed(4)} sh)`,
        //             ].join(" | ")
        //         );

        //         if (
        //             partialRound % FAK_SELL_LOWER_MIN_EVERY_N_ROUNDS === 0 &&
        //             canStepMinPx
        //         ) {
        //             const next = Math.max(0.01, sellMinPx - tickN);
        //             if (next < sellMinPx - 1e-12) {
        //                 logger.warn(
        //                     `SELL ${leg}: after ${partialRound} partial FAK rounds, lowering minPx ${sellMinPx.toFixed(4)} → ${next.toFixed(4)} (tick=${tickN})`
        //                 );
        //                 sellMinPx = next;
        //             } else {
        //                 logger.warn(
        //                     `SELL ${leg}: minPx cannot decrease further (${sellMinPx.toFixed(4)}) after ${partialRound} partial rounds`
        //                 );
        //             }
        //         }

        //         await new Promise((r) => setTimeout(r, FAK_PARTIAL_MARKET_DELAY_MS));
        //     }

        //     if (remaining < MIN_ORDER_SHARES) {
        //         return true;
        //     }
        //     logger.error(
        //         `SELL ${leg}: exceeded ${MAX_FAK_PARTIAL_MARKET_ROUNDS} FAK partial rounds; ~${remaining.toFixed(4)} shares still intended`
        //     );
        //     return false;
        // } catch (e) {
        //     logger.error(`SELL failed for ${leg}: ${e instanceof Error ? e.message : String(e)}`);
        //     return false;
        // }

        try {
            for (
                let partialRound = 1;
                partialRound <= MAX_FAK_PARTIAL_MARKET_ROUNDS;
                partialRound++
            ) {
                let amount = remaining;
                const userOrder: UserOrderV2 = {
                    tokenID,
                    price: sellMinPx,
                    size: amount,
                    side: Side.SELL
                };
                logger.info(`SELL: ${leg} market GTC ~${amount.toFixed(4)} shares @ price ${sellMinPx.toFixed(4)}`);

                const response = await this.client.createAndPostOrder(
                    userOrder,
                    { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
                    OrderType.GTC,
                    false
                );

                const success = response?.success;
                const orderId = response?.orderID;
                if (!success && !orderId) {
                    logger.error(`SELL ${partialRound}/${MAX_FAK_PARTIAL_MARKET_ROUNDS} round ${leg} failed: ${JSON.stringify(response)}`);
                    continue;
                } else if (success && orderId) {
                    const filledRaw = parseFloat(String(response.makingAmount ?? "0.000000"));
                    logger.info(`SELL ${partialRound}/${MAX_FAK_PARTIAL_MARKET_ROUNDS} round ${leg} success: ${success} orderId: ${orderId} sold shares: ${filledRaw.toFixed(4)}`);
                    const takingAmount = parseFloat(String(response.takingAmount ?? "0.000000"));
                    return { ok: true, takingAmount: takingAmount };
                }
            }
            return { ok: false, takingAmount: 0.000000 };
        } catch (error) {
            logger.error(`SELL failed for ${leg}: ${error instanceof Error ? error.message : String(error)}`);
            return { ok: false, takingAmount: 0.000000 };
        }
    }

    private async buyOppositeShares(
        leg: "YES" | "NO",
        tokenID: string,
        shares: number,
        tickSize: string
    ): Promise<boolean> {
        logger.info(`Buy Opposite Shares: ${leg} ${shares} shares @ max price 0.99`);
        const userOrder: UserOrderV2 = {
            tokenID,
            price: 0.99,
            size: shares,
            side: Side.BUY
        }

        const response = await this.client.createAndPostOrder(
            userOrder,
            { tickSize: tickSize as TickSize, negRisk: this.cfg.negRisk },
            OrderType.GTC
        )

        logger.info('-------------------------------------------------------');
        logger.info(`🟦 BUY ${leg} response: ${JSON.stringify(response)}`);

        const success = response?.success;
        const orderId = response?.orderID;

        if (!success && !orderId) {
            logger.error(`🟠 BUY ${leg} failed: ${JSON.stringify(response)}`);
            return false;
        }

        const filledRaw = parseFloat(String(response.takingAmount ?? "0.000000"));
        const spentUSDC = parseFloat(String(response.makingAmount ?? "0.000000"));

        logger.info(`🟢 BUY ${leg} success: ${success} orderId: ${orderId} bought shares: ${filledRaw.toFixed(4)} spent USDC: ${spentUSDC.toFixed(4)}`);
        return true;
    }

    private async executeTrade(
        market: string,
        slug: string,
        upAsk: number,
        downAsk: number,
        upBid: number | null,
        downBid: number | null,
        upTickSize: string,
        downTickSize: string,
        tokenIds: { upTokenId: string; downTokenId: string; conditionId: string; upIdx: number; downIdx: number },
        timeRemainingSeconds: number,
    ): Promise<void> {
        const stateKey = market;
        if (this.orderInFlightByMarket.has(stateKey)) return;
        this.orderInFlightByMarket.add(stateKey);

        try {
            // Action points + rapid reverse: market FAK via createAndPostMarketOrder.
            const row: SimpleStateRow = this.state[stateKey] ?? emptyRow();
            const commitPrevAsks = () => {
                row.prevUpAsk = Number.isFinite(upAsk) ? upAsk : row.prevUpAsk ?? null;
                row.prevDownAsk = Number.isFinite(downAsk) ? downAsk : row.prevDownAsk ?? null;
            };
            const commitPrevBids = () => {
                row.prevUpBid = upBid != null && Number.isFinite(upBid) ? upBid : row.prevUpBid ?? null;
                row.prevDownBid = downBid != null && Number.isFinite(downBid) ? downBid : row.prevDownBid ?? null;
            };
            const commitPrevPrices = () => {
                commitPrevAsks();
                commitPrevBids();
            };

            const cycleStartUnix = cycleStartUnixFromSlug(slug);
            const secondsSinceStart =
                cycleStartUnix != null && Number.isFinite(cycleStartUnix)
                    ? Math.max(0, Math.floor(Date.now() / 1000) - cycleStartUnix)
                    : null;
            
            // Reset per-cycle state when slug changes (new market window)
            if (row.slug !== slug) {
                // Before resetting state for the new cycle, enqueue the previous cycle's last action point number.
                if (row.slug != null) {
                    const priorPointCount = Number.isFinite(Number(row.pointCount)) ? Number(row.pointCount) : 0;
                    this.enqueuePriorCycleActionPoints(market, priorPointCount);
                    logger.info(
                        `📌 Prior cycle action points [${market}] slug=${row.slug} | lastPoint=${priorPointCount} | history=${JSON.stringify(
                            this.getActionPointHistoryQueue(market)
                        )}`
                    );
                }

                row.slug = slug;
                row.market = market;
                row.conditionId = tokenIds.conditionId;
                row.upIdx = tokenIds.upIdx;
                row.downIdx = tokenIds.downIdx;
                row.pointCount = 0;
                row.currentHoldingSide = undefined;
                row.cycleShares = 0;
                // Timeline gating is set once at cycle start (JST).
                const tlKey = getCurrentTimeLine();
                row.timeLineKey = tlKey;
                row.timeLineLabel = getCurrentTimeLineLabel();
                const tlKeys = ["GOLDERN_TIME", "GOOD_TIME", "MIDDLE_TIME", "POOR_TIME"] as const;
                const idx = Math.max(0, tlKeys.indexOf(tlKey));
                const cfg = ENV.TIME_LINE_CONFIG?.[idx] ?? [0, ACTION_LIMIT, ACTION_MULTIPLIER];
                const delayMinutes = Number(cfg?.[0]);
                const perTimelineLimit = Number(cfg?.[1]);
                const perTimelineMultiplier = Number(cfg?.[2]);
                row.actionPointResumeAfterSeconds =
                    Number.isFinite(delayMinutes) ? Math.max(0, Math.floor(delayMinutes)) * 60 : 0;
                row.actionLimit =
                    Number.isFinite(perTimelineLimit)
                        ? Math.max(0, Math.floor(perTimelineLimit))
                        : ACTION_LIMIT;
                row.actionMultiplier =
                    Number.isFinite(perTimelineMultiplier) && perTimelineMultiplier > 0
                        ? perTimelineMultiplier
                        : ACTION_MULTIPLIER;

                // If any of the last 5 cycles hit the current actionLimit exactly, add 30s delay for this cycle.
                const currentLimit = row.actionLimit ?? ACTION_LIMIT;
                const history = this.getActionPointHistoryQueue(market);
                if (history.some((v) => Number.isFinite(v) && v === currentLimit)) {
                    row.actionPointResumeAfterSeconds = Number(row.actionPointResumeAfterSeconds ?? 0) + 30;
                    logger.info(
                        `⏱️  Delay bumped +30s [${market}] slug=${slug} | reason=recentHitActionLimit actionLimit=${currentLimit} history=${JSON.stringify(
                            history
                        )}`
                    );
                }
                row.lastIdleCountdownLogMs = undefined;
                row.lastUpdatedIso = new Date().toISOString();
                row.actionPointBought = false;
                row.prevUpAsk = null;
                row.prevDownAsk = null;
                row.prevUpBid = null;
                row.prevDownBid = null;
                row.instantShares = 0;

                logger.info(`🆕 New cycle state reset [${market}] slug=${slug}`);
                logger.info(
                    `🕒 Cycle timeline (JST) [${market}] slug=${slug} | timeLine=${row.timeLineKey} (${row.timeLineLabel})`
                );
                logger.info(
                    `⚙️  Cycle config [${market}] slug=${slug} | delay=${Math.floor((row.actionPointResumeAfterSeconds ?? 0) / 60)}m actionLimit=${row.actionLimit ?? ACTION_LIMIT} actionMultiplier=${(row.actionMultiplier ?? ACTION_MULTIPLIER).toFixed(4)}`
                );

                // Record cycle start immediately so users can redeem even if the bot is stopped mid-cycle.
                // Fire-and-forget: never blocks trading loop.
                const cid = row.conditionId;
                if (typeof cid === "string" && /^0x[a-fA-F0-9]{64}$/.test(cid)) {
                    setImmediate(() => {
                        recordCycleStartedForRedeemTracking({ conditionId: cid, slug, market });
                    });
                }
            }

            const pointCount = Number.isFinite(Number(row.pointCount)) ? Number(row.pointCount) : 0;
            const cycleActionLimit =
                Number.isFinite(Number(row.actionLimit)) && Number(row.actionLimit) > 0
                    ? Number(row.actionLimit)
                    : ACTION_LIMIT;
            const cycleActionMultiplier =
                Number.isFinite(Number(row.actionMultiplier)) && Number(row.actionMultiplier) > 0
                    ? Number(row.actionMultiplier)
                    : ACTION_MULTIPLIER;

            // Timeline delay is applied at the cycle level: during the first N seconds of a new cycle,
            // we do nothing and simply wait (prevents any action-point logic from running early).
            const resumeAfter = Number(row.actionPointResumeAfterSeconds ?? 0);
            if (resumeAfter > 0 && secondsSinceStart != null && secondsSinceStart < resumeAfter) {
                const remain = resumeAfter - secondsSinceStart;
                const now = Date.now();
                const last = row.lastIdleCountdownLogMs ?? 0;
                if (now - last >= IDLE_COUNTDOWN_LOG_MS) {
                    row.lastIdleCountdownLogMs = now;
                    logger.info(
                        `⏳ Delaying cycle actions [${market}] slug=${slug} timeLine=${row.timeLineKey} | resumeIn=${remain}s`
                    );
                }
                commitPrevPrices();
                this.state[stateKey] = row;
                return;
            }

            /**
             * Action-point trigger should fire even if price skips the action band due to a fast jump.
             * We treat "hit" as crossing from below ACTION_POINT to >= ACTION_POINT while rising.
             *
             * Special case: if we have no `prev` yet (first observed tick this cycle), allow a single
             * trigger when price is already >= ACTION_POINT so we don't miss the whole cycle.
             * Because we require `prev < ACTION_POINT` on subsequent ticks, this does NOT cause
             * repeated buys when price stays above (e.g. ACTION_POINT=0.7/0.9 scenarios).
             */
            const crossedActionPointWhileRising = (
                prev: number | null | undefined,
                now: number,
                allowInitialWhenPrevMissing: boolean
            ): boolean => {
                if (!Number.isFinite(now)) return false;
                if (prev == null || !Number.isFinite(prev)) {
                    return allowInitialWhenPrevMissing && now >= ACTION_POINT;
                }
                // Rising through the threshold from below.
                return now > prev && prev < ACTION_POINT && now >= ACTION_POINT;
            };

            /**
             * Reversal-guard trigger should fire even if bid skips the band due to a fast drop.
             * Treat "hit" as crossing from above REVERSAL_GUARD_THRESHOLD to <= REVERSAL_GUARD_THRESHOLD while falling.
             *
             * Special case: if we have no `prev` bid yet (rare, e.g. first tick after buy where bestBid was null),
             * allow a single trigger when bid is already <= threshold to avoid missing protection entirely.
             * Subsequent ticks won't re-trigger unless bid goes back above the threshold and falls again.
             */
            const crossedReversalGuardWhileFalling = (
                prev: number | null | undefined,
                now: number | null,
                allowInitialWhenPrevMissing: boolean
            ): boolean => {
                if (now == null || !Number.isFinite(now)) return false;
                if (prev == null || !Number.isFinite(prev)) {
                    return allowInitialWhenPrevMissing && now <= REVERSAL_GUARD_THRESHOLD;
                }
                return prev > now && prev > REVERSAL_GUARD_THRESHOLD && now <= REVERSAL_GUARD_THRESHOLD;
            };

            const logPoint = (args: {
                pointNumber: number;
                side: "UP" | "DOWN";
                usd: number;
                execAsk: number;
                /** Points 2+: trigger when this side's best bid is in ACTION_POINT band */
                triggerBid?: number;
                note?: string;
            }) => {
                const shares = args.execAsk > 0 ? args.usd / args.execAsk : 0;
                const apHi = ACTION_POINT + actionPointDelta;
                const triggerPart =
                    args.triggerBid != null
                        ? `trigger=bid bid=${args.triggerBid.toFixed(4)} execAsk=${args.execAsk.toFixed(4)}`
                        : `trigger=ask ask=${args.execAsk.toFixed(4)}`;
                logger.info(
                    [
                        `🟦 ACTION POINT #${args.pointNumber}/${cycleActionLimit}`,
                        `[${market}] slug=${slug}`,
                        `side=${args.side}`,
                        `usd=$${(args.usd * cycleActionMultiplier).toFixed(2)}`,
                        triggerPart,
                        `shares≈${shares.toFixed(4)}`,
                        `band=[${ACTION_POINT.toFixed(2)}..${apHi.toFixed(2)}]`,
                        `tRem=${Math.max(0, Math.floor(timeRemainingSeconds))}s`,
                        args.note ? `note=${args.note}` : undefined,
                        `order=FAK market`,
                    ].filter(Boolean).join(" | ")
                );
            };

            const leg = (s: "UP" | "DOWN"): "YES" | "NO" => (s === "UP" ? "YES" : "NO");
            const tokenIdFor = (s: "UP" | "DOWN") => (s === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId);

            const usdForActionPoint = (pointNumber: number): number => {
                if (!Number.isFinite(pointNumber) || pointNumber <= 0) return 0;
                // 1,2,4,8,16,32 then +8 each time: 40,48,56,...
                if (pointNumber <= 5) return Math.pow(2, pointNumber - 1);
                return 24 + 8 * (pointNumber - 5);
            };

            /** Market FAK buy: spend `usd` USDC with max price = ACTION_POINT (tick ceiling). */
            const placeBuyNotional = async (
                side: "UP" | "DOWN",
                usd: number,
                _execAsk: number
            ): Promise<{ ok: boolean; limitPx: number; takingAmount: number }> => {
                const tick = side === "UP" ? upTickSize : downTickSize;
                const priceCap = ceilPriceToTick(Math.min(0.99, ACTION_POINT), tick);
                const usdMultiplied = usd * cycleActionMultiplier;
                if (usdMultiplied < MIN_ORDER_USDC) {
                    logger.error(`ACTION POINT buy skipped [${market}]: USDC ${usdMultiplied} below minimum`);
                    return { ok: false, limitPx: priceCap, takingAmount: 0.000000 };
                }
                const buyLeg = leg(side);
                const buyTokenId = tokenIdFor(side);

                const division = 4;

                if (
                    usdMultiplied >= BUY_DIVISION_START_USD &&
                    usdMultiplied >= MIN_ORDER_USDC * division
                ) {
                    const per = roundUsdDown(usdMultiplied / division);
                    const chunks: number[] = [];
                    for (let i = 0; i < division; i++) chunks.push(per);
                    const sumFirst = per * (division - 1);
                    chunks[division - 1] = Math.max(0, roundUsdDown(usdMultiplied - sumFirst));

                    if (chunks.every((u) => u >= MIN_ORDER_USDC)) {
                        const results = await Promise.all(
                            chunks.map((u) => this.buyShares(buyLeg, buyTokenId, u, priceCap, tick))
                        );
                        const ok = results.every((r) => r.ok);
                        const takingAmount = results.reduce((s, r) => s + (r.takingAmount ?? 0), 0);
                        logger.info(`Taking Amount = ${takingAmount}`);
                        return { ok, limitPx: priceCap, takingAmount };
                    }
                }

                const result = await this.buyShares(buyLeg, buyTokenId, usdMultiplied, priceCap, tick);
                return { ok: result.ok, limitPx: priceCap, takingAmount: result.takingAmount };
            }

            const currentCycleShares = row.cycleShares ?? 0;
            const currentHoldingSide = row.currentHoldingSide ?? undefined;
            const hasHolding =
                currentHoldingSide != null &&
                (currentHoldingSide === "UP" || currentHoldingSide === "DOWN") &&
                currentCycleShares >= MIN_ORDER_SHARES;

            // Only BUY at action point when we are not currently holding shares.
            if ((!hasHolding && pointCount < cycleActionLimit)) {
                if (
                    Number.isFinite(timeRemainingSeconds) &&
                    timeRemainingSeconds <= ACTION_POINT_BUY_BLOCKED_LAST_SECONDS
                ) {
                    logger.info(`🟦 ACTION POINT buy blocked [${market}] slug=${slug} timeRemainingSeconds=${timeRemainingSeconds}`);
                    commitPrevPrices();
                    this.state[stateKey] = row;
                    return;
                }
                const allowInitial = pointCount === 0;
                const upRisingHit = crossedActionPointWhileRising(row.prevUpAsk, upAsk, allowInitial);
                const downRisingHit = crossedActionPointWhileRising(row.prevDownAsk, downAsk, allowInitial);
                const triggerAsk = upRisingHit ? upAsk : downRisingHit ? downAsk : undefined;
                if (!Number.isFinite(triggerAsk) || triggerAsk == null) {
                    commitPrevPrices();
                    this.state[stateKey] = row;
                    return;
                }

                const side: "UP" | "DOWN" = upRisingHit ? "UP" : "DOWN";
                const execAsk = side === "UP" ? upAsk : downAsk;
                if (!Number.isFinite(execAsk)) {
                    commitPrevPrices();
                    this.state[stateKey] = row;
                    return;
                }

                const pointNumber = pointCount + 1;
                const usd = usdForActionPoint(pointNumber);

                logPoint({ pointNumber, side, usd, execAsk, triggerBid: triggerAsk });
                const { ok, limitPx, takingAmount } = await placeBuyNotional(side, usd, execAsk);
                row.cycleShares = takingAmount;
                row.actionPointBought = true;
                row.pointCount = pointNumber;
                row.currentHoldingSide = side;
                row.lastUpdatedIso = new Date().toISOString();
                commitPrevPrices();
                this.state[stateKey] = row;
                return;
            }

            // If we are holding, evaluate reversal-guard sell regardless of pointCount.
            if (hasHolding) {
                const bidPx = currentHoldingSide === "UP" ? upBid : downBid;
                const prevBidPx =
                    currentHoldingSide === "UP" ? (row.prevUpBid ?? null) : (row.prevDownBid ?? null);

                const allowInitialReversalGuard = prevBidPx == null || !Number.isFinite(prevBidPx);
                if (crossedReversalGuardWhileFalling(prevBidPx, bidPx, allowInitialReversalGuard)) {
                    const tickSz = currentHoldingSide === "UP" ? upTickSize : downTickSize;
                    const limitPx = floorPriceToTick(
                        Math.max(0.01, Math.min(Number(bidPx), REVERSAL_GUARD_THRESHOLD)),
                        tickSz
                    );
                    const currentCycleShares = row.cycleShares ?? 0;

                    logger.warn(
                        [
                            `🟠 REVERSAL GUARD [${market}] slug=${slug}`,
                            `lastBuy=${currentHoldingSide}`,
                            `bid=${(bidPx ?? NaN).toFixed(4)}`,
                            `band(bid)=[${(REVERSAL_GUARD_THRESHOLD - reversalGuardDelta).toFixed(2)}..${REVERSAL_GUARD_THRESHOLD.toFixed(2)}]`,
                            `sellMinPx=${limitPx.toFixed(4)}`,
                            `shares≈${currentCycleShares.toFixed(4)}`,
                        ].join(" | ")
                    );

                    await this.client.updateBalanceAllowance({
                        asset_type: AssetType.CONDITIONAL,
                        token_id: currentHoldingSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId                   
                    });
                    const balanceResponse: BalanceAllowanceResponse = await this.client.getBalanceAllowance({
                        asset_type: AssetType.CONDITIONAL,
                        token_id: currentHoldingSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId,
                    });
                    logger.info('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@');
                    logger.info('balances: ', JSON.stringify(balanceResponse));

                    const instantShares = row.instantShares ?? 0;
                    const balance = (parseFloat(String(balanceResponse.balance ?? "0.000000")) / 1000000) - instantShares;
                    const checkInstantBalance = Math.max(0.0001, balance);

                    // Handling instant sell just after buy
                    if (currentCycleShares > 0 && (checkInstantBalance / currentCycleShares) < 0.1) {
                        commitPrevPrices();
                        this.state[stateKey] = row;
                        logger.error(`🟠 Instant Sell triggered: balance ${balance.toFixed(4)} < 0.1 of currentCycleShares ${currentCycleShares.toFixed(4)}`);
                        logger.info(`Buying opposite shares... Current Holding Share = ${currentHoldingSide} Opposite Share = ${currentHoldingSide === "UP" ? "DOWN" : "UP"}`);
                        const oppositeSide = currentHoldingSide === "UP" ? "NO" : "YES";
                        const oppositeTokenId = currentHoldingSide === "UP" ? tokenIds.downTokenId : tokenIds.upTokenId;

                        const maxAttempts = 3;
                        let ok = false;
                        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                            try {
                                ok = await this.buyOppositeShares(
                                    oppositeSide,
                                    oppositeTokenId,
                                    currentCycleShares,
                                    tickSz
                                );
                            } catch (e) {
                                ok = false;
                                logger.error(
                                    `🟠 REVERSAL GUARD — BUY opposite shares attempt ${attempt}/${maxAttempts} threw: ${e instanceof Error ? e.message : String(e)}`
                                );
                            }

                            if (ok) break;
                            if (attempt < maxAttempts) {
                                const backoffMs = 50 * attempt;
                                logger.warn(
                                    `🟠 REVERSAL GUARD — BUY opposite shares failed (attempt ${attempt}/${maxAttempts}); retrying in ${backoffMs}ms`
                                );
                                await new Promise((r) => setTimeout(r, backoffMs));
                            }
                        }
                        if (ok) {
                            row.instantShares = instantShares + currentCycleShares;
                            row.cycleShares = 0;
                            row.lastIdleCountdownLogMs = Date.now();
                            row.lastUpdatedIso = new Date().toISOString();
                            row.currentHoldingSide = undefined;
                            row.actionPointBought = false;
                            commitPrevPrices();
                            this.state[stateKey] = row;
                            return;
                        }
                        logger.error(`🟠 REVERSAL GUARD — BUY opposite shares failed; instant sell skipped [${market}] slug=${slug}`);
                        return;
                    }

                    const sellable = Math.min(balance, currentCycleShares);

                    let ok = false;
                    const usdSpent = usdForActionPoint(pointCount) * cycleActionMultiplier;
                    if (usdSpent < SELL_DIVISION_START_USD) {
                        const { ok, takingAmount } = await this.sellShares(
                            currentHoldingSide === "UP" ? "YES" : "NO",
                            currentHoldingSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId,
                            0.35,
                            sellable,
                            tickSz
                        );
                        logger.info(`SELL Taking Amount = ${takingAmount}`);
                    } else {
                        logger.info(`🟠 SELL Division Start Point: ${pointCount} USD Spent to buy shares: ${usdSpent.toFixed(2)}`);
                        const sellLeg = currentHoldingSide === "UP" ? "YES" : "NO";
                        const sellTokenId = currentHoldingSide === "UP" ? tokenIds.upTokenId : tokenIds.downTokenId;
                        const sellMinPx = 0.35;

                        // Division sell: split into 4 orders, executed concurrently (Promise.all),
                        // only when size is large enough to avoid sub-minimum orders.
                        const divisions = 4;
                        if (sellable >= MIN_ORDER_SHARES * divisions) {
                            const per = roundSizeDown(sellable / divisions);
                            const chunks: number[] = [];
                            for (let i = 0; i < divisions; i++) chunks.push(per);
                            // Put rounding remainder into the last chunk.
                            const sumFirst = per * (divisions - 1);
                            chunks[divisions - 1] = Math.max(0, roundSizeDown(sellable - sumFirst));

                            const sellPromises = chunks
                                .filter((s) => s >= MIN_ORDER_SHARES)
                                .map((s) => this.sellShares(sellLeg, sellTokenId, sellMinPx, s, tickSz));

                            const results = await Promise.all(sellPromises);
                            ok = results.length > 0 && results.every(Boolean);
                            const takingAmount = results.reduce((s, r) => s + (r.takingAmount ?? 0), 0);
                            logger.info(`SELL Taking Amount = ${takingAmount}`);
                        } else {
                            const { ok, takingAmount } = await this.sellShares(sellLeg, sellTokenId, sellMinPx, sellable, tickSz);
                            logger.info(`SELL Taking Amount = ${takingAmount}`);
                        }
                    }
                    row.cycleShares = 0;
                    row.currentHoldingSide = undefined;
                    if (ok) {
                        row.lastIdleCountdownLogMs = Date.now();
                        row.lastUpdatedIso = new Date().toISOString();
                        commitPrevPrices();
                        this.state[stateKey] = row;
                        return;
                    }
                    row.lastIdleCountdownLogMs = Date.now();
                    row.lastUpdatedIso = new Date().toISOString();
                    commitPrevPrices();
                    this.state[stateKey] = row;
                    logger.error(
                        `🟠 REVERSAL GUARD — SELL failed; virtual shares unchanged [${market}] slug=${slug}`
                    );
                }
            }
            commitPrevPrices();
        }
        finally {
            this.orderInFlightByMarket.delete(stateKey);
        }
    }

    // Derive seconds remaining until settlement from the slug timestamp.
    // Primary: `btc-updown-4h-{unix}`; legacy hourly ET + `5m` / `15m` interval slugs.
    private getTimeRemainingForSlug(slug: string): number {
        const startTs = cycleStartUnixFromSlug(slug);
        const durationSec = marketDurationSecondsFromSlug(slug);
        if (startTs == null || !Number.isFinite(startTs) || durationSec == null) return Infinity;
        return startTs + durationSec - Math.floor(Date.now() / 1000);
    }
}
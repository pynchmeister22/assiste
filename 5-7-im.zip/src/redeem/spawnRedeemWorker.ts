import { spawn } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Starts redemption in a separate OS process so RPC work, retries, and logging
 * cannot block the bot's event loop or be affected by the same unhandled rejection
 * stack as the main trader.
 */
export function spawnRedeemAutoWorker(conditionId: string, prevSlug: string): void {
    // Resolve relative to repo root, not `__dirname` (ESM/tsx may not define it).
    const cwd = process.cwd();
    const scriptBase = path.join(cwd, 'src', 'redeem', 'redeemAuto');
    const tsPath = `${scriptBase}.ts`;

    if (!fs.existsSync(tsPath)) {
        console.error(`[redeem] Worker script missing: ${tsPath}`);
        return;
    }

    const tsxCli = path.join(cwd, 'node_modules', 'tsx', 'dist', 'cli.mjs');

    let command: string;
    let args: string[];

    // Always run the TS source (never dist): package.json is "type":"module" and tsc may emit CJS.
    if (fs.existsSync(tsxCli)) {
        command = process.execPath;
        args = [tsxCli, tsPath, conditionId, prevSlug];
    } else {
        command = process.execPath;
        args = ['-r', 'ts-node/register', tsPath, conditionId, prevSlug];
    }

    const spawnOpts = {
        cwd,
        env: { ...process.env, POLYBOT_ROLE: 'redeem-worker' },
        stdio: 'inherit' as const,
        windowsHide: true,
    };

    try {
        const child = spawn(command, args, spawnOpts);
        child.on('error', (err) => {
            console.error(`[redeem] Failed to spawn worker: ${err.message}`);
        });
        child.on('exit', (code, signal) => {
            if (code !== 0 && code !== null) {
                console.warn(
                    `[redeem] Worker exited code=${code} signal=${signal ?? ''} conditionId=${conditionId.slice(0, 18)}…`,
                );
            }
        });
    } catch (e) {
        console.error(`[redeem] spawn: ${e instanceof Error ? e.message : String(e)}`);
    }
}

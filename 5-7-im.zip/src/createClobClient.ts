import * as fs from 'fs';
import * as path from 'path';
import { ethers } from 'ethers';
import { ClobClient, SignatureTypeV2 } from '@polymarket/clob-client-v2';
import { config } from './config.js';

const PRIVATE_KEY = config.privateKey;
const CLOB_HTTP_URL = 'https://clob.polymarket.com';
const RPC_URL = config.rpcUrl;

/** Same format as `generate-api-creds.ts` (dotenv-style lines). */
export const POLYMARKET_API_CREDS_FILE = path.join(process.cwd(), 'api-creds.polymarket-api-creds');

export type StoredApiCreds = { key: string; secret: string; passphrase: string };

function loadCredentialsFromFile(filePath: string): StoredApiCreds | null {
    try {
        if (!fs.existsSync(filePath)) {
            return null;
        }
        const raw = fs.readFileSync(filePath, { encoding: 'utf8' });
        const map: Record<string, string> = {};
        for (const line of raw.split(/\r?\n/)) {
            const t = line.trim();
            if (!t || t.startsWith('#')) continue;
            const eq = t.indexOf('=');
            if (eq === -1) continue;
            map[t.slice(0, eq).trim()] = t.slice(eq + 1).trim();
        }
        const key = map['POLYMARKET_USER_API_KEY'] ?? '';
        const secret = map['POLYMARKET_USER_SECRET'] ?? '';
        const passphrase = map['POLYMARKET_USER_PASSPHRASE'] ?? '';
        if (key && secret && passphrase) {
            return { key, secret, passphrase };
        }
    } catch {
        /* missing or unreadable file */
    }
    return null;
}

function saveCredentialsToFile(filePath: string, creds: { key?: string; apiKey?: string; secret?: string; passphrase?: string }): void {
    const apiKey = String(creds.key ?? (creds as { apiKey?: string }).apiKey ?? '');
    const secret = String(creds.secret ?? '');
    const passphrase = String(creds.passphrase ?? '');
    if (!apiKey || !secret || !passphrase) {
        return;
    }
    const content =
        `POLYMARKET_USER_API_KEY=${apiKey}\n` +
        `POLYMARKET_USER_SECRET=${secret}\n` +
        `POLYMARKET_USER_PASSPHRASE=${passphrase}\n`;
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, content, { encoding: 'utf8', mode: 0o600 });
}

// Check if the address is a Gnosis Safe
const isGnosisSafe = async (address: string): Promise<boolean> => {
    try {
        const provider = new ethers.providers.JsonRpcProvider(RPC_URL);
        const code = await provider.getCode(address);
        return code !== '0x';
    } catch (error) {
        console.error(`Error checking if ${address} is a Gnosis Safe: ${error}`);
        return false;
    }
};

const createClobClient = async (): Promise<ClobClient> => {
    const chainId = 137; // Polygon Mainnet
    const host = CLOB_HTTP_URL as string;
    const wallet = new ethers.Wallet(PRIVATE_KEY as string);
    const proxyWallet = await wallet.getAddress();

    const isProxySafe = await isGnosisSafe(proxyWallet);
    const signatureType = isProxySafe ? SignatureTypeV2.POLY_GNOSIS_SAFE : SignatureTypeV2.EOA;

    console.info(`Wallet type detected: ${isProxySafe ? 'Gnosis Safe' : 'EOA (Externally Owned Account)'}`);
    console.info(`Your address - ${proxyWallet}`);

    const credsPath = POLYMARKET_API_CREDS_FILE;
    let stored = loadCredentialsFromFile(credsPath);

    if (stored) {
        console.info(`Using API credentials from ${path.basename(credsPath)}`);
    } else {
        console.info(`No API credentials in ${path.basename(credsPath)} — creating new keys…`);

        let clobClient = new ClobClient({
            host,
            chain: chainId,
            signer: wallet,
            creds: undefined,
            signatureType: signatureType as SignatureTypeV2,
        });

        const originalConsoleLog = console.log;
        const originalConsoleError = console.error;
        console.log = function () {};
        console.error = function () {};

        let creds: { key?: string; apiKey?: string; secret?: string; passphrase?: string };
        try {
            creds = (await clobClient.createApiKey()) as typeof creds;
            if (!creds?.key) {
                creds = (await clobClient.deriveApiKey()) as typeof creds;
            }
        } finally {
            console.log = originalConsoleLog;
            console.error = originalConsoleError;
        }

        saveCredentialsToFile(credsPath, creds);
        console.info(`Saved new API credentials to ${path.basename(credsPath)}`);

        stored = loadCredentialsFromFile(credsPath);
        if (!stored) {
            throw new Error(`Failed to persist or reload API credentials from ${credsPath}`);
        }
    }

    const clobClient = new ClobClient({
        host,
        chain: chainId,
        signer: wallet,
        creds: stored,
        signatureType: signatureType as SignatureTypeV2,
        funderAddress: isProxySafe ? (proxyWallet as string) : undefined,
    });

    return clobClient;
};

export default createClobClient;

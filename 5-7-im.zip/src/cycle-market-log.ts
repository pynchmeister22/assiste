import * as fs from 'fs';
import * as path from 'path';

export type RedeemStatus = 'active_in_cycle' | 'not_redeemed' | 'nothing_to_redeem' | 'redeemed';

export type CycleMarketEntry = {
  conditionId: string;
  slug: string;
  market: string;
  cycleStartedAtIso?: string;
  cycleEndedAtIso?: string;
  redeemStatus: RedeemStatus | string;
  updatedAtIso: string;
  nothingToRedeemNote?: string;
  redeemedAtIso?: string;
  transactionHash?: string;
  balanceAfterUsdc?: string;
  redeemSource?: 'auto' | 'manual' | 'batch' | 'pnl_pending';
};

export type CycleMarketsFile = Record<string, CycleMarketEntry>;

function ensureDir(filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

export function cycleMapKey(conditionId: string): string {
  return conditionId.trim().toLowerCase();
}

export function readCycleMarketsMap(filePath: string): CycleMarketsFile {
  if (!fs.existsSync(filePath)) {
    return {};
  }
  try {
    const raw = JSON.parse(fs.readFileSync(filePath, { encoding: 'utf8' })) as unknown;
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      return raw as CycleMarketsFile;
    }
  } catch {
    // corrupt/empty: treat as empty (caller may overwrite on save)
  }
  return {};
}

export function writeCycleMarketsMap(map: CycleMarketsFile, filePath: string): void {
  ensureDir(filePath);
  fs.writeFileSync(filePath, JSON.stringify(map, null, 2), { encoding: 'utf8' });
}

export function mutateCycleMarketsFile(filePath: string, fn: (map: CycleMarketsFile) => void): void {
  for (let i = 0; i < 5; i++) {
    try {
      const map = readCycleMarketsMap(filePath);
      fn(map);
      writeCycleMarketsMap(map, filePath);
      return;
    } catch {
      /* retry — concurrent writers or transient FS errors */
    }
  }
}

/**
 * Derive a per-market log filename from the slug when it matches the common
 * `<asset>-updown-<Nm>-<cycleStartSec>` format.
 *
 * Examples:
 * - btc-updown-5m-1776117600  -> logs/btc-5m-markets.json
 * - eth-updown-5m-1776117600  -> logs/eth-5m-markets.json
 *
 * Fallback:
 * - logs/allowed-slug-markets.json
 */
export type CycleParser = (slug: string) => { startMs: number; endMs: number } | null;

const TERMINAL_REDEEM = new Set(['nothing_to_redeem', 'redeemed']);

function markOtherActiveCyclesAsNotRedeemed(map: CycleMarketsFile, exceptKey: string, nowMs: number): boolean {
  let changed = false;
  const nowIso = new Date(nowMs).toISOString();
  for (const k of Object.keys(map)) {
    if (k === exceptKey) continue;
    const e = map[k];
    if (!e) continue;
    if (e.redeemStatus !== 'active_in_cycle') continue;
    e.redeemStatus = 'not_redeemed';
    e.updatedAtIso = nowIso;
    delete e.nothingToRedeemNote;
    changed = true;
  }
  return changed;
}

/**
 * Insert or refresh a cycle market row from `conditionId` + `slug`.
 * - Uses `slugRegex` capture group 1 as unix start seconds.
 * - Writes to a log file derived from the slug (per asset+interval).
 */
export function upsertCycleMarketEntry(params: {
  conditionId: string;
  slug: string;
  parseCycle: CycleParser;
  market?: string;
  filePath: string;
}): { ok: boolean; created: boolean; filePath: string } {
  const empty = { ok: false, created: false, filePath: '' };
  const { conditionId, slug } = params;
  if (!conditionId || typeof slug !== 'string') return empty;

  const cycle = params.parseCycle(slug);
  if (!cycle) return empty;

  const filePath = params.filePath;
  const key = cycleMapKey(conditionId);
  const map = readCycleMarketsMap(filePath);

  const now = Date.now();
  const nowIso = new Date(now).toISOString();

  const market =
    params.market ||
    (slug.trim().match(/^([a-z0-9]+)-/i)?.[1]?.toLowerCase() ?? 'unknown');

  const startedIso = new Date(cycle.startMs).toISOString();
  const endedIso = new Date(cycle.endMs).toISOString();

  if (map[key]) {
    const prev = map[key];
    prev.slug = slug;
    prev.conditionId = conditionId;
    prev.market = market;
    prev.cycleStartedAtIso = startedIso;
    prev.cycleEndedAtIso = endedIso;
    prev.updatedAtIso = nowIso;
    writeCycleMarketsMap(map, filePath);
    return { ok: true, created: false, filePath };
  }

  markOtherActiveCyclesAsNotRedeemed(map, key, now);

  const redeemStatus: RedeemStatus = now < cycle.endMs ? 'active_in_cycle' : 'not_redeemed';
  map[key] = {
    conditionId,
    slug,
    market,
    cycleStartedAtIso: startedIso,
    cycleEndedAtIso: endedIso,
    redeemStatus,
    updatedAtIso: nowIso,
  };
  writeCycleMarketsMap(map, filePath);
  return { ok: true, created: true, filePath };
}

/**
 * Find the previous cycle row for a slug using time adjacency based on `slugRegex`.
 * - First tries strict adjacency: prev.end === next.start
 * - Else chooses the most recent cycle that ended before next.start
 */
export function findPreviousCycleForSlug(params: {
  map: CycleMarketsFile;
  newSlug: string;
  parseCycle: CycleParser;
}): { conditionId: string; slug: string } | null {
  const next = params.parseCycle(params.newSlug);
  if (!next) return null;

  let adjacent: { conditionId: string; slug: string } | null = null;
  let bestBefore: { conditionId: string; slug: string; endMs: number } | null = null;

  for (const e of Object.values(params.map)) {
    if (!e?.slug) continue;
    if (e.slug === params.newSlug) continue;
    const prev = params.parseCycle(e.slug);
    if (!prev) continue;

    if (prev.endMs === next.startMs) {
      adjacent = { conditionId: e.conditionId, slug: e.slug };
      break;
    }

    if (prev.endMs < next.startMs) {
      if (!bestBefore || prev.endMs > bestBefore.endMs) {
        bestBefore = { conditionId: e.conditionId, slug: e.slug, endMs: prev.endMs };
      }
    }
  }

  if (adjacent) return adjacent;
  if (bestBefore) return { conditionId: bestBefore.conditionId, slug: bestBefore.slug };
  return null;
}

/**
 * Time-based transition: after `cycleEndedAtIso`, move `active_in_cycle` (and legacy `cycle_ended`) to `not_redeemed`.
 */
export function advanceRedeemStatusesForTime(params: { filePath: string; nowMs?: number }): boolean {
  const { filePath } = params;
  const nowMs = params.nowMs ?? Date.now();
  const map = readCycleMarketsMap(filePath);
  let changed = false;
  for (const key of Object.keys(map)) {
    const e = map[key];
    if (!e?.cycleEndedAtIso) continue;
    const end = Date.parse(e.cycleEndedAtIso);
    if (!Number.isFinite(end)) continue;
    if (nowMs <= end) continue;
    if (TERMINAL_REDEEM.has(e.redeemStatus)) continue;
    if (e.redeemStatus === 'not_redeemed') continue;
    if (e.redeemStatus === 'active_in_cycle' || e.redeemStatus === 'cycle_ended') {
      e.redeemStatus = 'not_redeemed';
      e.updatedAtIso = new Date(nowMs).toISOString();
      delete e.nothingToRedeemNote;
      changed = true;
    }
  }
  if (changed) {
    writeCycleMarketsMap(map, filePath);
  }
  return changed;
}


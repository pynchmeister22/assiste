import * as path from 'path';

export type CycleWindow = { startMs: number; endMs: number };

export type MarketRule = {
  /** Key used in COPY_MARKETS, e.g. "btc-5m" */
  key: string;
  /** Human label for logs */
  label: string;
  /** Returns true if a slug belongs to this family */
  matchesSlug: (slug: string) => boolean;
  /**
   * If defined, enables cycle logging + "previous cycle" redeem spawning.
   * Should return the cycle window for the market slug.
   */
  parseCycle?: (slug: string) => CycleWindow | null;
  /** Log file path for this rule */
  logFile: (slug: string) => string;
};

function parseIntervalKey(key: string): { asset: string; n: number; unit: 'm' | 'h' } | null {
  const k = key.trim().toLowerCase();
  const m = k.match(/^([a-z0-9]+)-(\d+)(m|h)$/);
  if (!m) return null;
  const asset = m[1];
  const n = parseInt(m[2], 10);
  const unit = m[3] as 'm' | 'h';
  if (!asset || !Number.isFinite(n) || n <= 0) return null;
  return { asset, n, unit };
}

// ---- "bitcoin-up-or-down-may-7-2026-4am-et" parsing (America/New_York) ----

const MONTHS: Record<string, number> = {
  january: 1,
  february: 2,
  march: 3,
  april: 4,
  may: 5,
  june: 6,
  july: 7,
  august: 8,
  september: 9,
  october: 10,
  november: 11,
  december: 12,
};

function partsInTimeZone(date: Date, timeZone: string): { y: number; m: number; d: number; hh: number; mm: number; ss: number } {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
  const parts = fmt.formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '00';
  return {
    y: parseInt(get('year'), 10),
    m: parseInt(get('month'), 10),
    d: parseInt(get('day'), 10),
    hh: parseInt(get('hour'), 10),
    mm: parseInt(get('minute'), 10),
    ss: parseInt(get('second'), 10),
  };
}

/**
 * Convert a local time in `timeZone` to UTC ms.
 * Uses a small iterative correction using `Intl.DateTimeFormat`.
 */
function zonedTimeToUtcMs(args: { y: number; m: number; d: number; hh: number; mm: number; ss?: number; timeZone: string }): number {
  const { y, m, d, hh, mm, ss = 0, timeZone } = args;
  // Start with a UTC guess using the same clock components.
  let guess = Date.UTC(y, m - 1, d, hh, mm, ss);
  for (let i = 0; i < 2; i++) {
    const p = partsInTimeZone(new Date(guess), timeZone);
    // Difference between what the timezone says at `guess` and what we want.
    const want = Date.UTC(y, m - 1, d, hh, mm, ss);
    const got = Date.UTC(p.y, p.m - 1, p.d, p.hh, p.mm, p.ss);
    const delta = got - want;
    guess = guess - delta;
  }
  return guess;
}

function parseBitcoinUpOrDownHourlySlug(slug: string): CycleWindow | null {
  const s = slug.trim().toLowerCase();
  const m = s.match(/^bitcoin-up-or-down-([a-z]+)-(\d{1,2})-(\d{4})-(\d{1,2})(am|pm)-et$/);
  if (!m) return null;
  const monthName = m[1];
  const month = MONTHS[monthName];
  if (!month) return null;
  const day = parseInt(m[2], 10);
  const year = parseInt(m[3], 10);
  let hour = parseInt(m[4], 10);
  const ampm = m[5];
  if (!Number.isFinite(day) || !Number.isFinite(year) || !Number.isFinite(hour)) return null;
  if (hour < 1 || hour > 12) return null;
  if (ampm === 'pm' && hour !== 12) hour += 12;
  if (ampm === 'am' && hour === 12) hour = 0;

  const startMs = zonedTimeToUtcMs({ y: year, m: month, d: day, hh: hour, mm: 0, ss: 0, timeZone: 'America/New_York' });
  const endMs = startMs + 60 * 60_000;
  return { startMs, endMs };
}

// ---- rule registry ----

function buildUpdownRule(args: {
  key: string;
  assetSlugPrefix: string;
  label: string;
  defaultIntervalMs: number;
  /** If set, only match this interval (e.g. "5m", "15m", "4h") */
  fixedInterval?: { n: number; unit: 'm' | 'h' };
}): MarketRule {
  const intervalPart = args.fixedInterval ? `${args.fixedInterval.n}${args.fixedInterval.unit}` : `(\\d+)(m|h)`;
  const re = new RegExp(`^${args.assetSlugPrefix}-updown-${intervalPart}-(\\d+)$`, 'i');

  return {
    key: args.key,
    label: args.label,
    matchesSlug: (slug) => re.test(slug.trim()),
    parseCycle: (slug) => {
      const m = slug.trim().match(re);
      if (!m) return null;

      const startSec = parseInt(String(m[m.length - 1] ?? ''), 10);
      if (!Number.isFinite(startSec) || startSec <= 0) return null;
      const startMs = startSec * 1000;

      // Interval comes from slug; if fixedInterval is set, this is deterministic.
      const dm = slug.trim().match(/-updown-(\d+)(m|h)-\d+$/i);
      if (dm) {
        const n = parseInt(dm[1], 10);
        const unit = String(dm[2] ?? '').toLowerCase();
        if (Number.isFinite(n) && n > 0) {
          const cycleMs = unit === 'h' ? n * 60 * 60_000 : n * 60_000;
          return { startMs, endMs: startMs + cycleMs };
        }
      }
      return { startMs, endMs: startMs + args.defaultIntervalMs };
    },
    logFile: (slug) => {
      if (args.fixedInterval) {
        return path.join('logs', `${args.assetSlugPrefix.toLowerCase()}-${args.fixedInterval.n}${args.fixedInterval.unit}-markets.json`);
      }
      const dm = slug.trim().match(/-updown-(\d+)(m|h)-\d+$/i);
      if (dm) {
        const n = dm[1];
        const unit = String(dm[2] ?? '').toLowerCase();
        return path.join('logs', `${args.assetSlugPrefix.toLowerCase()}-${n}${unit}-markets.json`);
      }
      return path.join('logs', `${args.assetSlugPrefix.toLowerCase()}-markets.json`);
    },
  };
}

const BUILTIN_RULES: Record<string, MarketRule> = {
  // Special BTC hourly slug family: `bitcoin-up-or-down-may-7-2026-4am-et`
  'btc-1hr': {
    key: 'btc-1hr',
    label: 'Bitcoin up or down hourly (ET)',
    matchesSlug: (slug) => /^bitcoin-up-or-down-/i.test(slug.trim()),
    parseCycle: parseBitcoinUpOrDownHourlySlug,
    logFile: () => path.join('logs', `btc-1hr-markets.json`),
  },
};

export function resolveEnabledMarketRules(keys: string[]): MarketRule[] {
  const out: MarketRule[] = [];
  for (const k of keys) {
    const key = k.trim();
    if (!key) continue;

    // 1) Built-ins (special non-numeric slug families)
    const builtin = BUILTIN_RULES[key];
    if (builtin) {
      out.push(builtin);
      continue;
    }

    // 2) Generic numeric up/down markets: `<asset>-<N><m|h>` -> `<asset>-updown-<N><m|h>-<startSec>`
    const parsed = parseIntervalKey(key);
    if (parsed) {
      out.push(
        buildUpdownRule({
          key,
          assetSlugPrefix: parsed.asset,
          label: `${parsed.asset.toUpperCase()} up/down ${parsed.n}${parsed.unit} (numeric)`,
          defaultIntervalMs: parsed.unit === 'h' ? parsed.n * 60 * 60_000 : parsed.n * 60_000,
          fixedInterval: { n: parsed.n, unit: parsed.unit },
        }),
      );
      continue;
    }
  }
  return out;
}

export function findRuleForSlug(slug: unknown, rules: MarketRule[]): MarketRule | null {
  if (typeof slug !== 'string') return null;
  const s = slug.trim();
  if (!s) return null;
  for (const r of rules) {
    if (r.matchesSlug(s)) return r;
  }
  return null;
}


import offramp from "./offramp.js";

async function main(): Promise<void> {
    await offramp();
}

main().catch((e) => {
    console.error(`[offramp] ${e instanceof Error ? e.message : String(e)}`);
    process.exit(1);
});


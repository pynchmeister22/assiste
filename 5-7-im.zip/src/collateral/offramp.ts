import { Wallet, ethers } from "ethers";
import { parseUnits } from "@ethersproject/units";
import { config } from "../config";
import getMyBalance from "../utils/getMyBalance";

const PUSD_CONTRACT_ADDRESS = config.contracts.pusd;
const OFFRAMP_ADDRESS = config.offrampAddress;

const MIN_PUSD = 0.01;

// Offramp contract: unwrap(address _asset, address _to, uint256 _amount)
const offrampABI = ["function unwrap(address _asset, address _to, uint256 _amount)"];
const erc20ApproveABI = ["function approve(address spender, uint256 amount) returns (bool)"];

async function getGasOverrides(
    provider: ethers.providers.JsonRpcProvider
): Promise<ethers.providers.TransactionRequest> {
    const minPriorityGwei = parseFloat(process.env.MIN_PRIORITY_FEE_GWEI || "30");
    const minMaxFeeGwei = parseFloat(process.env.MIN_MAX_FEE_GWEI || "60");

    const feeData = await provider.getFeeData();
    const minPriority = ethers.utils.parseUnits(minPriorityGwei.toString(), "gwei");
    const minMaxFee = ethers.utils.parseUnits(minMaxFeeGwei.toString(), "gwei");

    let maxPriority = feeData.maxPriorityFeePerGas || feeData.gasPrice || minPriority;
    let maxFee = feeData.maxFeePerGas || feeData.gasPrice || minMaxFee;

    const latestBlock = await provider.getBlock("latest");
    const baseFee = latestBlock?.baseFeePerGas;
    if (baseFee) {
        const targetMaxFee = baseFee.mul(2).add(maxPriority);
        if (maxFee.lt(targetMaxFee)) maxFee = targetMaxFee;
    }

    if (maxPriority.lt(minPriority)) maxPriority = minPriority;
    if (maxFee.lt(minMaxFee)) maxFee = minMaxFee;
    if (maxFee.lt(maxPriority)) maxFee = maxPriority;

    return {
        maxPriorityFeePerGas: maxPriority,
        maxFeePerGas: maxFee,
    };
}

const offramp = async (): Promise<void> => {
    if (!PUSD_CONTRACT_ADDRESS || !/^0x[a-fA-F0-9]{40}$/.test(PUSD_CONTRACT_ADDRESS)) {
        console.warn("[offramp] Skip: missing/invalid PUSD_CONTRACT");
        return;
    }

    if (!OFFRAMP_ADDRESS || !/^0x[a-fA-F0-9]{40}$/.test(OFFRAMP_ADDRESS)) {
        console.warn("[offramp] Skip: missing/invalid OFFRAMP_ADDRESS");
        return;
    }

    const provider = new ethers.providers.JsonRpcProvider(config.rpcUrl);
    const wallet = new Wallet(config.privateKey, provider);
    const walletAddress = await wallet.getAddress();

    const pusdBalance = await getMyBalance(walletAddress);
    if (pusdBalance < MIN_PUSD) {
        console.info(`[offramp] Skip: pUSD balance ${pusdBalance.toFixed(6)} < ${MIN_PUSD}`);
        return;
    }

    const amount = parseUnits(pusdBalance.toFixed(6), 6);
    const gasOverrides = await getGasOverrides(provider);

    console.info(
        `[offramp] Start: wallet=${walletAddress} amount=${pusdBalance.toFixed(6)} pUSD offramp=${OFFRAMP_ADDRESS}`
    );

    // Approve offramp to spend pUSD
    const pusd = new ethers.Contract(PUSD_CONTRACT_ADDRESS, erc20ApproveABI, wallet);
    const approveTx = await pusd.approve(OFFRAMP_ADDRESS, amount, gasOverrides);
    console.info(`[offramp] Approve submitted: ${approveTx.hash}`);
    const approveReceipt = await approveTx.wait(1);
    console.info(`[offramp] Approve confirmed: block=${approveReceipt.blockNumber ?? "?"}`);

    // Unwrap pUSD -> USDC (offramp’s target) via the offramp contract
    const offrampContract = new ethers.Contract(OFFRAMP_ADDRESS, offrampABI, wallet);
    const unwrapTx = await offrampContract.unwrap(PUSD_CONTRACT_ADDRESS, walletAddress, amount, gasOverrides);
    console.info(`[offramp] Unwrap submitted: ${unwrapTx.hash}`);
    const unwrapReceipt = await unwrapTx.wait(1);
    console.info(`[offramp] Unwrap confirmed: block=${unwrapReceipt.blockNumber ?? "?"}`);
    console.info("[offramp] Done");
};

export default offramp;
import { Wallet, ethers } from "ethers";
import { parseUnits } from "@ethersproject/units";
import { config } from "../config";
import getUSDCBalance from "../utils/getUSDCBalance";

const USDC_CONTRACT_ADDRESS = config.usdcContract;

const MIN_USDC = 0.01;

const ONRAMP_ADDRESS = config.onrampAddress;

const onrampABI = ["function wrap(address _asset, address _to, uint256 _amount)"];
const erc20ApproveABI = ["function approve(address spender, uint256 amount) returns (bool)"];

async function getGasOverrides(
    provider: ethers.providers.JsonRpcProvider
): Promise<ethers.providers.TransactionRequest> {
    const minPriorityGwei = parseFloat(process.env.MIN_PRIORITY_FEE_GWEI || "30");
    const minMaxFeeGwei = parseFloat(process.env.MIN_MAX_FEE_GWEI || "60");

    const feeData = await provider.getFeeData();
    const minPriority = ethers.utils.parseUnits(minPriorityGwei.toString(), "gwei");
    const minMaxFee = ethers.utils.parseUnits(minMaxFeeGwei.toString(), "gwei");

    let maxPriority = feeData.maxPriorityFeePerGas || feeData.gasPrice || minPriority;
    let maxFee = feeData.maxFeePerGas || feeData.gasPrice || minMaxFee;

    const latestBlock = await provider.getBlock("latest");
    const baseFee = latestBlock?.baseFeePerGas;
    if (baseFee) {
        const targetMaxFee = baseFee.mul(2).add(maxPriority);
        if (maxFee.lt(targetMaxFee)) maxFee = targetMaxFee;
    }

    if (maxPriority.lt(minPriority)) maxPriority = minPriority;
    if (maxFee.lt(minMaxFee)) maxFee = minMaxFee;
    if (maxFee.lt(maxPriority)) maxFee = maxPriority;

    return {
        maxPriorityFeePerGas: maxPriority,
        maxFeePerGas: maxFee,
    };
}

const onramp = async () => {
    if (!USDC_CONTRACT_ADDRESS || !/^0x[a-fA-F0-9]{40}$/.test(USDC_CONTRACT_ADDRESS)) {
        console.warn("[onramp] Skip: missing/invalid USDC_CONTRACT");
        return;
    }

    if (!ONRAMP_ADDRESS || !/^0x[a-fA-F0-9]{40}$/.test(ONRAMP_ADDRESS)) {
        console.warn("[onramp] Skip: missing/invalid ONRAMP_ADDRESS");
        return;
    }

    const privateKey = config.privateKey;
    const provider = new ethers.providers.JsonRpcProvider(config.rpcUrl);
    const wallet = new Wallet(privateKey, provider);
    const walletAddress = await wallet.getAddress();

    const usdcBalance = await getUSDCBalance(walletAddress);
    if (usdcBalance < MIN_USDC) {
        console.info(`[onramp] Skip: USDC balance ${usdcBalance.toFixed(6)} < ${MIN_USDC}`);
        return;
    }

    // Amount in base units (USDC has 6 decimals on Polygon)
    const amount = parseUnits(usdcBalance.toFixed(6), 6);
    const gasOverrides = await getGasOverrides(provider);

    console.info(
        `[onramp] Start: wallet=${walletAddress} amount=${usdcBalance.toFixed(6)} USDC onramp=${ONRAMP_ADDRESS}`
    );

    // Approve ONRAMP to spend USDC
    const usdc = new ethers.Contract(USDC_CONTRACT_ADDRESS, erc20ApproveABI, wallet);
    const approveTx = await usdc.approve(ONRAMP_ADDRESS, amount, gasOverrides);
    console.info(`[onramp] Approve submitted: ${approveTx.hash}`);
    const approveReceipt = await approveTx.wait(1);
    console.info(`[onramp] Approve confirmed: block=${approveReceipt.blockNumber ?? "?"}`);

    // Wrap USDC -> pUSD (or onramp’s target) via the onramp contract
    const onrampContract = new ethers.Contract(ONRAMP_ADDRESS, onrampABI, wallet);
    const wrapTx = await onrampContract.wrap(USDC_CONTRACT_ADDRESS, walletAddress, amount, gasOverrides);
    console.info(`[onramp] Wrap submitted: ${wrapTx.hash}`);
    const wrapReceipt = await wrapTx.wait(1);
    console.info(`[onramp] Wrap confirmed: block=${wrapReceipt.blockNumber ?? "?"}`);
    console.info("[onramp] Done");
}

export default onramp;
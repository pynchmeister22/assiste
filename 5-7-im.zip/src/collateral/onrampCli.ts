import onramp from "./onramp.js";

async function main(): Promise<void> {
    await onramp();
}

main().catch((e) => {
    console.error(`[onramp] ${e instanceof Error ? e.message : String(e)}`);
    process.exit(1);
});

